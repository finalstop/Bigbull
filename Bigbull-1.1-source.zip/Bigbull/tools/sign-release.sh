#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_HOME:?Set ANDROID_HOME}"
: "${BIGBULL_KEYSTORE:?Set BIGBULL_KEYSTORE to the private release PKCS12 file}"
: "${BIGBULL_PASSWORD_FILE:?Set BIGBULL_PASSWORD_FILE to its password file}"
project_dir="$(cd -- "$(dirname -- "$0")/.." && pwd)"
unsigned_apk="${1:-$project_dir/app/build/outputs/apk/release/app-release-unsigned.apk}"
signed_apk="${2:-$project_dir/app/build/outputs/apk/release/Bigbull-1.1.apk}"
signer="$ANDROID_HOME/build-tools/34.0.0/lib/apksigner.jar"
java -jar "$signer" sign --ks "$BIGBULL_KEYSTORE" --ks-key-alias bigbullrelease --ks-pass "file:$BIGBULL_PASSWORD_FILE" \
 --lineage "$project_dir/signing/release.lineage" --rotation-min-sdk-version 28 --min-sdk-version 28 \
 --v1-signing-enabled false --v2-signing-enabled false --v3-signing-enabled true --v4-signing-enabled false \
 --out "$signed_apk" "$unsigned_apk"
java -jar "$signer" verify --min-sdk-version 28 --verbose --print-certs "$signed_apk"
