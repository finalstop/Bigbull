import java.io.File;
import java.security.MessageDigest;
import java.util.HexFormat;
import com.android.apksig.ApkVerifier;
import com.android.apksig.SigningCertificateLineage;

/** Run with Android build-tools lib/apksigner.jar on the classpath. */
public class VerifyRelease {
  public static void main(String[] args) throws Exception {
    File apk=new File(args[0]);
    for(int api=28;api<=37;api++) {
      var r=new ApkVerifier.Builder(apk).setMinCheckedPlatformVersion(api).setMaxCheckedPlatformVersion(api).build().verify();
      if(!r.isVerified())throw new IllegalStateException("API "+api+": "+r.getErrors());
      System.out.println("API "+api+": signature verified");
    }
    var l=SigningCertificateLineage.readFromApkFile(apk);
    if(l.size()!=2)throw new IllegalStateException("Missing upgrade lineage");
    var old=l.getCertificatesInLineage().get(0);
    String sha=HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(old.getEncoded()));
    if(!sha.equals("0615bf1a7e7264c3ed8d69cb2c4dfc98504dbabe24c0971e9712241145acf74c"))throw new IllegalStateException("Incorrect prior signer");
    var caps=l.getSignerCapabilities(old);
    if(!caps.hasInstalledData()||caps.hasRollback())throw new IllegalStateException("Unexpected upgrade capabilities");
    System.out.println("0.9 certificate lineage verified: installed-data capability true, rollback false");
  }
}
