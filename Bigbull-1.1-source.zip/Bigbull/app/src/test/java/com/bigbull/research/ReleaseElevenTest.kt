package com.bigbull.research
import org.junit.Test
import org.junit.Assert.*
class ReleaseElevenTest {
 @Test fun optionalDownloadedPublisherSample(){
  val path=System.getenv("BIGBULL_READER_HTML");org.junit.Assume.assumeTrue(path!=null)
  for(sample in java.io.File(path!!).parentFile!!.listFiles()!!.filter{it.name in setOf("ndtv.html","et.html")}) {
  val parsed=ReaderSource.parse(sample.readText(),if(sample.name=="et.html")"https://economictimes.indiatimes.com/" else "https://www.ndtvprofit.com/")
  assertTrue(parsed.blocks.sumOf{it.text.length}>500);assertTrue(parsed.blocks.any{it.image!=null})
  println("Publisher reader sample ${sample.name}: ${parsed.blocks.size} blocks, ${parsed.blocks.count{it.image!=null}} images")
  }
 }

 @Test fun barometerHasBullBearNeutralAndNoInventedMissingVotes(){
  fun candles(f:(Int)->Double)=(0..239).map{val x=f(it);Candle(java.time.LocalDate.of(2025,1,1).plusDays(it.toLong()).toString(),x,x+1,x-1,x,1000.0)}
  assertEquals("Strong buy",TechnicalRating.evaluate(candles{100.0+it}).label)
  assertEquals("Strong sell",TechnicalRating.evaluate(candles{500.0-it}).label)
  assertEquals("Neutral",TechnicalRating.evaluate(candles{100.0}).label)
  val short=TechnicalRating.evaluate(candles{100.0+it}.take(3));assertNull(short.score);assertEquals(0,short.available)
 }
 @Test fun etInlineProseIsNotLost(){
  val prose="The company reported results and published the full financial statements for investors. ".repeat(4)
  val parsed=ReaderSource.parse("<article class='artData'><div class='artText'>First paragraph: $prose<br><br>Second paragraph: $prose</div><div class='promo'>Workshop</div></article>","https://economictimes.indiatimes.com/test")
  assertTrue(parsed.blocks.sumOf{it.text.length}>500);assertFalse(parsed.blocks.any{it.text.contains("Workshop")})
 }
 @Test fun resizedEtImagesHaveOneIdentity(){assertEquals(ReaderImages.identity("https://img.etimg.com/thumb/msid-123456789,width-600/story.jpg"),ReaderImages.identity("https://economictimes.indiatimes.com/photo/123456789.cms"));assertEquals(ReaderImages.identity("https://img.etimg.com/photo/123456789.cms"),ReaderImages.identity("https://img.etimg.com/thumb/123456789.cms?width=200"))}
 @Test fun readerRemovesPromoAudioAndDuplicateHero(){val p="The company published its quarterly results with detailed financial statements and management commentary. ".repeat(4);val html="""<meta property='og:image' content='https://img.etimg.com/photo/123456789.cms'><article><p>$p</p><img src='https://img.etimg.com/thumb/msid-123456789,width-200/test.jpg'><p>Listen to this article in summarized format</p><div class='promo'><img src='https://example.com/workshop.jpg'><p>Register for our wealth workshop now and grow!</p></div><figure><img src='https://example.com/chart.jpg'></figure></article>""";val d=ReaderSource.parse(html,"https://economictimes.indiatimes.com/test");assertEquals(2,d.blocks.count{it.image!=null});assertFalse(d.blocks.any{it.text.contains("Listen")||it.text.contains("workshop")})}
 @Test fun thesisRoundTripRetainsEvidenceAndExport(){val t=Thesis("Thesis","Risk","https://example.com/report","2026-12-01","now");assertEquals(t,Thesis.parse(t.json()));assertTrue(t.export("ABC").contains("Risk"))}
}
