package com.bigbull.research
import org.junit.Test
import org.junit.Assert.*
import org.json.JSONObject
class ResearchUpgradeTest {
 private fun published()=JSONObject("""{"success":true,"data":{"date":"2024-01-03T07:00:00Z","indicator":41.2,"fii":-100,"vix":-15.0,"skew":-0.2,"momentum":-1.0,"trin":-0.3,"extrema":-0.1,"goldOnNifty":0.02}}""")
 @Test fun publishedMoodKeepsSixGroupsAndSource(){val m=MoodSource.parse(published().toString());assertEquals(6,m.factors.size);assertEquals("Tickertape",m.source);assertEquals(41.2,m.score,0.0);assertEquals("Fear",m.zone);assertTrue(m.factors.any{it.name=="Volatility & skew"});val j=published();j.getJSONObject("data").remove("skew");assertThrows(Exception::class.java){MoodSource.parse(j.toString())}}
 @Test fun invalidHeadlineAndIncompleteQuoteRejected(){val j=published();j.getJSONObject("data").put("indicator",110);assertThrows(IllegalArgumentException::class.java){MoodSource.parse(j.toString())};assertThrows(Exception::class.java){SameDaySource.parse("{}",Instrument("TEST","NSE"))}}
 @Test fun adBlockingAndUrlBoundaries(){assertTrue(ReaderPolicy.block("https://pagead2.googlesyndication.com/ads"));assertFalse(ReaderPolicy.block("https://example.org/story"));assertFalse(ReaderPolicy.safe("file:///etc/passwd"));assertFalse(ReaderPolicy.safe("javascript:alert(1)"));assertTrue(ReaderPolicy.safe("https://example.org/article"));assertFalse(ReaderPolicy.safe("https://user:password@example.org/"))}
 @Test fun financialGrowthUsesMatchingYearAndKeepsLosses(){val r=JSONObject("""{"income_statement":[{"fiscal_date":"2025-03-31","sales":120,"net_income":-10},{"fiscal_date":"2024-03-31","sales":100},{"fiscal_date":"2022-03-31","sales":60}]}""");val p=FinancialViewData.points(r,"income_statement","sales");assertEquals(20.0,FinancialViewData.growth(p)!!,1e-8);assertEquals(-10.0,FinancialViewData.points(r,"income_statement","net_income").single().value,0.0)}

 @Test fun currentSessionLabelsDoNotBorrowHistoricalDates(){
  val now=java.time.Instant.parse("2026-10-28T07:51:00Z")
  assertEquals("1:20 PM IST · may be delayed",MarketTime.quoteLabel("2026-10-28T07:50:00Z",now))
  assertEquals("27 Oct, 3:30 PM IST · may be delayed",MarketTime.quoteLabel("2026-10-27T10:00:00Z",now))
  assertEquals("09:15",MarketTime.barTime("2026-10-28 09:15"))
  assertEquals("13:20",MarketTime.barTime("2026-10-28 13:20:08"))
  val today=listOf(Candle("2026-10-28 09:15",100.0,101.0,99.0,100.0,10.0))
  assertEquals("Today · 5 min",MarketTime.sessionLabel(today,now))
  assertEquals("Session 2026-10-28 · 5 min",MarketTime.sessionLabel(today,java.time.Instant.parse("2026-10-29T07:00:00Z")))
 }
 @Test fun timestampUsesIndianDateAtMidnight(){
  val now=java.time.Instant.parse("2026-10-28T18:45:00Z")
  assertEquals("12:10 AM IST · may be delayed",MarketTime.quoteLabel("2026-10-28T18:40:00Z",now))
  assertTrue(MarketTime.quoteLabel("2026-10-28T18:20:00Z",now).startsWith("28 Oct"))
 }
}
