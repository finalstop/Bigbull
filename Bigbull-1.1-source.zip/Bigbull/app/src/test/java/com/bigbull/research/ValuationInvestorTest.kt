package com.bigbull.research
import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject
import java.time.LocalDate

class ValuationInvestorTest {
    private fun report(endpoint:String,currency:String="INR",date:String="2026-03-31",values:String)=JSONObject("""{"meta":{"currency":"$currency"},"$endpoint":[{"fiscal_date":"$date",$values}]}""")
    private fun facts(currency:String="INR",balanceDate:String="2026-03-31",eps:Double=10.0)=ValuationFacts(150.0,"2026-10-28",report("income_statement",currency,values="\"diluted_eps\":$eps,\"net_income\":1000,\"sales\":10000"),report("balance_sheet",currency,balanceDate,"\"stockholders_equity\":10000,\"ordinary_shares\":100,\"total_debt\":2000"),report("cash_flow",currency,values="\"free_cash_flow\":600,\"operating_cash_flow\":1200"))
    @Test fun multiplesAndPerShareUseActualShares(){val v=facts();assertEquals(15.0,v.pe!!,1e-8);assertEquals(1.5,v.pb!!,1e-8);assertEquals(150.0,v.graham!!,1e-8);assertEquals(6.0,v.fcfPerShare!!,1e-8)}
    @Test fun currencyAndPeriodMismatchesAreNeverCombined(){assertNull(facts("USD").pe);assertNull(facts("USD").fcfPerShare);assertNull(facts(balanceDate="2025-03-31").graham);assertNull(facts(balanceDate="2025-03-31").fcfPerShare);assertNull(facts(eps=-1.0).pe);assertNull(facts(eps=-1.0).graham)}
    @Test fun missingSharesAreNotDerivedFromRoundedEps(){val v=facts();v.b!!.remove("ordinary_shares");assertNull(v.fcfPerShare);assertNull(v.graham);assertNull(v.pb)}
    @Test fun equityCashFlowZeroGrowthIsPerpetuity(){assertEquals(100.0,EquityScenario.value(10.0,EquityScenario.Assumptions("test",0.0,.10,0.0)),1e-8)}
    @Test fun higherRequiredReturnLowersValue(){val low=EquityScenario.value(10.0,EquityScenario.Assumptions("a",.05,.10,.03));val high=EquityScenario.value(10.0,EquityScenario.Assumptions("b",.05,.15,.03));assertTrue(low>high)}
    @Test(expected=IllegalArgumentException::class) fun terminalRateCannotEqualDiscount(){EquityScenario.value(10.0,EquityScenario.Assumptions("bad",.05,.03,.03))}
    @Test fun unknownRulesCannotBecomeVerifiedMatches(){val v=ValuationFacts(null,"",null,null,null);InvestorScreens.methods.indices.forEach{i->val r=InvestorScreens.evaluate(i,v,emptyList());assertTrue(r.isNotEmpty());assertTrue(r.all{it.passed==null});assertFalse(r.all{it.passed==true})}}
    @Test fun minerviniUsesDailySmasAndNeverCallsRsiRelativeStrength(){val start=LocalDate.of(2024,1,1);val bars=(0..400).map{i->val p=100.0+i;Candle(start.plusDays(i.toLong()).toString(),p,p+1,p-1,p,1000.0)};val r=InvestorScreens.evaluate(0,facts(),bars);assertEquals(7,r.count{it.passed==true});assertNull(r.last().passed);assertTrue(r.last().reading.contains("not RSI"));assertFalse(r.all{it.passed==true})}
    @Test fun historicalPegUsesPercentagePoints(){val v=facts();val a=v.income!!.getJSONArray("income_statement");a.put(JSONObject("""{"fiscal_date":"2023-03-31","diluted_eps":5.0}"""));assertEquals(25.99,v.epsGrowth!!,.04);assertEquals(15.0/25.99,v.peg!!,.001)}
}
