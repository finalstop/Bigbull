package com.bigbull.research
import org.junit.Test
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class DirectoryReportTest {
    @Test fun catalogRejectsDerivativesDebtAndMalformedSymbols(){val json="""[{"segment":"BSE_EQ","name":"A","isin":"INE376L01013","instrument_type":"X","trading_symbol":"AAA","exchange_token":"514028"},{"segment":"BSE_FO","name":"Future","isin":"INE124B01018","instrument_type":"FUT","trading_symbol":"FUT"},{"segment":"BSE_EQ","name":"Bond","isin":"INE124B07018","instrument_type":"F","trading_symbol":"BOND"}]""";val rows=BseCatalog.parse(json.reader(),"BSE");assertEquals(1,rows.size);assertEquals("514028",rows.single().code)}
    @Test fun storageUpgradeKeepsHoldingsAndWatchlists(){val first=Storage(RuntimeEnvironment.getApplication());val db=first.writableDatabase;db.execSQL("INSERT INTO items VALUES(1,'RELIANCE','NSE','Reliance Industries')");db.execSQL("INSERT INTO trades(symbol,exchange,name,type,date,qty,price,fees) VALUES('RELIANCE','NSE','Reliance','BUY','2026-10-27','2','100','1')");db.execSQL("DROP TABLE public_cache");db.version=2;first.close();val next=Storage(RuntimeEnvironment.getApplication());assertEquals("RELIANCE",next.stocks(1).single().symbol);assertEquals(1,next.trades().size);next.savePublic("test","now","payload");assertEquals("payload",next.publicCache("test")!!.second);next.clearProviderCache();assertNull(next.publicCache("test"));assertEquals(1,next.trades().size);next.close()}
    @Test fun liveBseOnlyDirectoryAndOriginalAnnualPdf(){
        assumeTrue(System.getenv("BIGBULL_LIVE")=="true")
        val all=BseCatalog.load(false);val only=BseCatalog.load(true);assertTrue(all.size>3000);assertTrue(only.size>1000);assertFalse(only.any{it.symbol=="RELIANCE"});assertTrue(only.all{it.exchange=="BSE"});println("BSE supported equities ${all.size}; BSE-only by ISIN ${only.size}")
        val doc=AnnualReports.load(Instrument("RELIANCE","NSE")).first();assertTrue(doc.url.contains("nseindia.com"));val file=AnnualReports.download(doc,RuntimeEnvironment.getApplication().cacheDir)
        try {
            val bytes=file.readBytes()
            assertTrue(bytes.size>10000)
            assertEquals("%PDF-",bytes.copyOfRange(0,5).toString(Charsets.US_ASCII))
            assertTrue(bytes.takeLast(4096).toByteArray().toString(Charsets.ISO_8859_1).contains("%%EOF"))
            println("Original annual report ${doc.label}: ${bytes.size} bytes; PDF header and EOF verified")
        } finally { file.delete() }
    }
}
