package com.bigbull.research
import org.junit.Test
import org.junit.Assume.assumeTrue
import org.junit.Assert.*
class LiveReaderTest {
 @Test fun publicArticlesExtractAsNativeTextAndImageUrls(){
  assumeTrue(System.getenv("BIGBULL_LIVE")=="true")
  val batch=NewsFeed.loadAll();val sources=batch.items.map{it.source}.distinct();assertTrue("Expected at least two reachable publishers: ${batch.errors}",sources.size>=2)
  var readable=0;var images=0
  for(h in batch.items.distinctBy{it.source})try{val article=ReaderSource.load(h.url);readable++;images+=article.blocks.count{it.image!=null};println("Reader ${h.source}: ${article.blocks.size} native blocks, ${article.blocks.count{it.image!=null}} image URLs")}catch(e:Exception){println("Reader ${h.source}: ${e.message}")}
  assertTrue("No publisher supplied readable content",readable>0);assertTrue("No article image URLs extracted",images>0)
 }
}
