package com.bigbull.research
import org.junit.Test
import org.junit.Assume.assumeTrue
import org.junit.Assert.*
class LiveNewsMoodTest {
 @Test fun actualSourcesParseAndAlign(){assumeTrue(System.getenv("BIGBULL_LIVE")=="true");val batch=NewsFeed.loadAll();val news=batch.items;assertTrue(news.isNotEmpty());println("Sources: "+news.groupingBy{it.source}.eachCount()+"; warnings="+batch.errors);val mood=MoodSource.load();assertEquals(6,mood.factors.size);assertTrue(mood.score in 0.0..100.0);println("Validated ${news.size} headlines; mood ${mood.date}: ${mood.score} (${mood.zone}) with 6 published factor groups.")}
}
