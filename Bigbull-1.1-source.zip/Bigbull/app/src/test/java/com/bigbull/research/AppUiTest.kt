package com.bigbull.research

import androidx.compose.ui.test.*
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import android.graphics.Canvas
import android.graphics.Bitmap
import java.io.File
import java.time.LocalDate
import java.time.Instant
import org.junit.Assume.assumeTrue

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34],qualifiers="w393dp-h852dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class AppUiTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    @Test fun terminalNavigationAndNewsAreVisible(){
        compose.onNodeWithContentDescription("Bigbull").assertIsDisplayed()
        compose.onNodeWithText("Market breadth").assertIsDisplayed()
        compose.onNodeWithText("Research a stock").assertExists()
        val content=compose.onNodeWithTag("contentViewport").fetchSemanticsNode().boundsInRoot
        val nav=compose.onNodeWithTag("bottomNavigation").fetchSemanticsNode().boundsInRoot
        org.junit.Assert.assertTrue("Compact glass navigation stays inside the viewport",nav.bottom<=content.bottom && nav.height<240f)
        capture("terminal-home")
        compose.onNodeWithText("News",useUnmergedTree=true).performClick()
        compose.onNodeWithText("Market news").assertIsDisplayed()
        capture("news")
        compose.onNodeWithText("Portfolio",useUnmergedTree=true).performClick()
        compose.onNodeWithText("+ Entry").assertExists()
        compose.onNodeWithText("More",useUnmergedTree=true).performClick()
        compose.onNodeWithText("Public website data").assertIsDisplayed()
        compose.onNodeWithText("Created by Harsh Prashant Gattani").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Markets",useUnmergedTree=true).performClick()
        compose.onNodeWithText("Screener").performClick()
        compose.onNodeWithText("Mark Minervini").assertIsDisplayed()
        compose.onNodeWithText("Buffett").performClick()
        compose.onNodeWithText("Warren Buffett").assertIsDisplayed();capture("investor-playbooks")
    }
    @Test fun liveSentimentAndHeadlinesRender(){
        assumeTrue(System.getenv("BIGBULL_LIVE")=="true")
        val app=AppState(compose.activity)
        app.mood=MoodSource.load();app.headlines=NewsFeed.load();app.snapshot=FreeMarketData().snapshot()
        val starter=Instrument("RELIANCE","NSE","Reliance Industries");app.quotes[starter.id]=SameDaySource.load(starter);app.dark=false
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(false){BigbullApp(app)}}}
        compose.onNodeWithText("Latest headlines").assertExists();capture("markets-light")
        app.dark=true
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(true){BigbullApp(app)}}}
        capture("markets-dark");capture("terminal-live")
        compose.onAllNodesWithText("Fear & Greed").onFirst().performClick();compose.onNodeWithText(num(app.mood!!.score,1)).assertExists();capture("fear-greed")
        compose.onNodeWithText("Replay movement").performScrollTo().performClick();compose.onNodeWithText(num(app.mood!!.score,1)).assertExists()
        compose.onNodeWithText("News",useUnmergedTree=true).performClick()
        compose.onNodeWithText("Market news").assertIsDisplayed();capture("news-live")
        app.dispose()
    }
    @Test fun liveFinancialsAndSameDayQuoteRender(){
        assumeTrue(System.getenv("BIGBULL_LIVE")=="true")
        val app=AppState(compose.activity);val stock=Instrument("RELIANCE","NSE","Reliance Industries")
        val api=FreeMarketData();val report=api.report(stock,"income_statement","annual")
        app.db.saveStatement(stock,"income_statement","annual",report.first,report.second)
        app.db.saveSeries(api.candles(stock,"1day"))
        for(e in listOf("balance_sheet","cash_flow")){val r=api.report(stock,e,"annual");app.db.saveStatement(stock,e,"annual",r.first,r.second)}
        val quote=SameDaySource.load(stock);app.quotes[stock.id]=quote;app.selected=stock
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(false){BigbullApp(app)}}}
        compose.onNodeWithText("Today").assertIsDisplayed()
        compose.onAllNodesWithText("historical close",substring=true,ignoreCase=true).assertCountEquals(0)
        capture("same-day")
        compose.onNodeWithText("History").performClick()
        compose.onNodeWithText("History · completed",substring=true).assertIsDisplayed()
        compose.onNodeWithText("Today").performClick()
        compose.onAllNodesWithText("History · completed",substring=true).assertCountEquals(0)
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(true){BigbullApp(app)}}}
        capture("same-day-dark")
        compose.onNodeWithText("Research at a glance").performScrollTo()
        compose.onNodeWithText("Performance").performClick()
        compose.onNodeWithText("Return over the last 21",substring=true).assertIsDisplayed()
        capture("research-dark")
        compose.onNodeWithText("Financials",useUnmergedTree=true).performClick()
        compose.onNodeWithText("Financial performance").assertIsDisplayed();capture("fundamentals")
        compose.onNodeWithText("Valuation",useUnmergedTree=true).performScrollTo().performClick()
        compose.onNodeWithText("Intrinsic value scenarios").performScrollTo().assertIsDisplayed()
        compose.onNodeWithText("Use a cash-flow model for this non-financial business").performScrollTo()
        compose.onNode(isToggleable()).performClick()
        compose.onNodeWithText("Central").assertExists();capture("intrinsic-value")
        val peer=Instrument("ONGC","NSE")
        for(e in listOf("income_statement","balance_sheet")){val r=api.report(peer,e,"annual");app.db.saveStatement(peer,e,"annual",r.first,r.second)}
        app.quotes[peer.id]=SameDaySource.load(peer)
        compose.onNodeWithText("Peers",useUnmergedTree=true).performScrollTo().performClick()
        compose.waitForIdle()
        capture("peers");compose.onNodeWithText("Peers & comparison").assertIsDisplayed()
        compose.onNodeWithText("Checkpoint",useUnmergedTree=true).performScrollTo().performClick()
        compose.onNodeWithText("Save research checkpoint").performClick()
        compose.onNodeWithText("No source facts changed").assertExists();capture("checkpoint")
        println("Validated quote timestamp ${quote.asOf}, ${quote.bars.size} intraday bars and actual annual report.")
        app.dispose()
    }
    @Test fun nativeArticleShowsReadableContentAndRecoverableError(){
        val app=AppState(compose.activity)
        val h=Headline("Reader regression","https://example.org/story","28 Oct 2026","Test publisher")
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(true){ArticleReader(app,h){ReaderDocument("Readable article",listOf(ReaderBlock("Synthetic article body. ".repeat(25))),h.url)}}}}
        compose.waitUntil(5000){compose.onAllNodesWithText("Readable article").fetchSemanticsNodes().isNotEmpty()};compose.onNodeWithText("Readable article").assertIsDisplayed();capture("reader-native")
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(true){ArticleReader(app,h.copy(url="https://example.org/fail")){throw IllegalStateException("Publisher unavailable")}}}}
        compose.waitUntil(5000){compose.onAllNodesWithText("Couldn't load this article").fetchSemanticsNodes().isNotEmpty()};capture("reader-error");compose.onNodeWithText("Couldn't load this article").assertIsDisplayed();compose.onNodeWithText("Retry article").assertIsDisplayed();capture("reader-error")
        app.dispose()
    }
    @Test fun calendarUniverseAndReportsNavigation(){
        assumeTrue(System.getenv("BIGBULL_LIVE")=="true")
        val app=AppState(compose.activity)
        for(kind in listOf("results","dividend")){app.events[kind]=CorporateCalendar.parse(ReaderSource.bytes(CorporateCalendar.url(kind)).toString(Charsets.UTF_8),kind);app.eventFetched[kind]=Instant.now().toString()}
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(true){BigbullApp(app)}}}
        compose.onNodeWithText("Events",useUnmergedTree=true).performScrollTo().performClick();compose.onNodeWithText("Company calendar").assertIsDisplayed();capture("results-calendar")
        compose.onNodeWithText("Dividends").performClick();capture("dividend-calendar")
        compose.onNodeWithText("Screener",useUnmergedTree=true).performScrollTo().performClick();compose.onNodeWithText("NIFTY 500").assertIsDisplayed();capture("nifty500-screener")
        compose.onNodeWithText("NIFTY 500").performClick();compose.onNodeWithText("BSE only · not on NSE").performScrollTo().performClick();compose.onNodeWithText("BSE only · not on NSE").assertIsDisplayed()
        compose.onNodeWithText("Watchlist",useUnmergedTree=true).performClick();capture("watchlist-capsule")
        val stock=Instrument("RELIANCE","NSE","Reliance Industries");app.selected=stock
        compose.onNodeWithText("Annual reports",useUnmergedTree=true).performScrollTo().performClick()
        compose.waitUntil(20000){compose.onAllNodesWithText("Read PDF →").fetchSemanticsNodes().isNotEmpty()}
        capture("annual-reports");compose.onAllNodesWithText("Read PDF →").onFirst().performClick()
        compose.onNodeWithText("‹ Reports").assertIsDisplayed();app.dispose()
    }
    @Test fun technicalBarometerExplainsItsVotes(){
        val stock=Instrument("TEST","NSE","Synthetic test only")
        val bars=(0..239).map{val p=100.0+it;Candle(LocalDate.of(2025,1,1).plusDays(it.toLong()).toString(),p,p+1,p-1,p,1000.0)}
        val series=Series(stock,"1d",bars,"Synthetic unit-test fixture","",false)
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(true){Column(Modifier.verticalScroll(rememberScrollState())){TechnicalBarometer(series)}}}}
        compose.onNodeWithText("Strong buy").assertIsDisplayed()
        compose.onNodeWithText("Why this rating?").performClick()
        compose.onNodeWithText("Price / SMA 200: Bullish").assertExists()
        capture("technical-barometer-test-fixture")
    }
    @Test fun researchJournalPersistsPerStock(){
        val stock=Instrument("TEST","NSE","Synthetic test only")
        compose.runOnUiThread{compose.activity.setContent{BigbullTheme(true){ResearchJournal(stock)}}}
        compose.onNodeWithText("Why this company?").performTextInput("Review audited cash flows")
        compose.onNodeWithText("What would change my mind?").performTextInput("Cash conversion deteriorates")
        compose.onNodeWithText("Save journal").performScrollTo().performClick()
        org.junit.Assert.assertEquals("Review audited cash flows",ThesisStore(compose.activity).load(stock.id).reason)
        org.junit.Assert.assertEquals("Cash conversion deteriorates",ThesisStore(compose.activity).load(stock.id).risks)
        org.junit.Assert.assertEquals("",ThesisStore(compose.activity).load("OTHER").reason)
    }
    private fun capture(name:String){
        compose.waitForIdle()
        compose.runOnUiThread {
            val view=compose.activity.window.decorView
            val image=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
            view.draw(Canvas(image))
            val out=File("build/ui-checks/$name.png");out.parentFile?.mkdirs();out.outputStream().use{image.compress(Bitmap.CompressFormat.PNG,100,it)}
        }
    }
}
