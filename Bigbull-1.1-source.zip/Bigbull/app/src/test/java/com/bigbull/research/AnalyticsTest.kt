package com.bigbull.research

import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class AnalyticsTest {
    private val infy=Instrument("INFY","NSE")
    private fun bd(s:String)=BigDecimal(s)
    @Test fun csvAcceptsQuotedFieldsAndOrdersCandles() {
        val c=CsvCandles.parse("date,open,high,low,close,volume,note\r\n2024-01-03,101,105,100,103,\"1000\",\"hello, market\"\r\n2024-01-02,100,102,99,101,900,ok\r\n")
        assertEquals("2024-01-02",c.first().time); assertEquals(1000.0,c.last().volume,0.0)
    }
    @Test fun csvRejectsDuplicateOrInvalidDataWithoutPartialImport() {
        val cases=listOf(
            "date,open,high,low,close,volume\n2024-01-02,100,98,99,101,900",
            "date,open,high,low,close,volume\n2024-01-02,100,102,99,101,900\n2024-01-02,100,102,99,101,900",
            "date,open,high,low,close,volume\n2024-02-30,100,102,99,101,900",
            "date,open,high,low,close,volume\n2024-01-02,NaN,102,99,101,900",
            "date,open,high,low,close,volume\n2024-01-02,100,102,99,101,\"900"
        )
        cases.forEach { input -> try { CsvCandles.parse(input); fail("Accepted invalid CSV") } catch(_:Exception) {} }
    }
    @Test fun movingAveragesAndBandsUseExpectedSeeds() {
        val x=(1..20).map{it.toDouble()}; assertEquals(10.5,Indicators.sma(x,20).last()!!,1e-10); assertEquals(10.5,Indicators.ema(x,20).last()!!,1e-10)
        val b=Indicators.bands(x).last()!!; assertEquals(10.5,b.middle,1e-10); assertEquals(22.0325625947,b.upper,1e-8); assertEquals(-1.0325625947,b.lower,1e-8)
        assertNull(Indicators.sma(x,21).last())
    }
    @Test fun rsiMatchesWilderReferenceAndFlatSeries() {
        val prices=listOf(44.34,44.09,44.15,43.61,44.33,44.83,45.10,45.42,45.84,46.08,45.89,46.03,45.61,46.28,46.28,46.00,46.03,46.41,46.22,45.64,46.21)
        val r=Indicators.rsi(prices); assertEquals(70.464135,r[14]!!,1e-5); assertEquals(66.249619,r[15]!!,1e-5)
        assertEquals(50.0,Indicators.rsi(List(15){10.0}).last()!!,0.0);assertEquals(100.0,Indicators.rsi((1..15).map{it.toDouble()}).last()!!,0.0)
    }
    @Test fun volumeAndTrueRangeAreComputedOnOrderedCandles() {
        val candles=listOf(Candle("2024-01-01",10.0,11.0,9.0,10.0,100.0),Candle("2024-01-02",10.0,13.0,10.0,12.0,150.0),Candle("2024-01-03",12.0,12.0,9.0,10.0,120.0))
        assertEquals(listOf(0.0,150.0,30.0),Indicators.obv(candles));assertEquals(2.5,Indicators.atr(candles,2)[1]!!,1e-10);assertEquals(2.75,Indicators.atr(candles,2)[2]!!,1e-10)
    }
    @Test fun classicPivotsAnd52WeekRangeRespectRequiredWindow() {
        val a=Candle("2023-01-01",100.0,110.0,90.0,100.0,10.0)
        val b=Candle("2024-01-01",100.0,120.0,80.0,110.0,10.0)
        val p=Indicators.classicPivots(a)
        assertEquals(100.0,p.pivot,1e-10); assertEquals(110.0,p.resistance1,1e-10); assertEquals(90.0,p.support1,1e-10)
        assertEquals(120.0,Indicators.highLow52Weeks(listOf(a,b))!!.first,1e-10)
        assertNull(Indicators.highLow52Weeks(listOf(b)))
    }
    @Test fun portfolioUsesWeightedAverageIncludingFeesAndRejectsOversell() {
        fun t(id:Long,type:TradeType,date:String,q:String,p:String,fee:String)=Trade(id,infy,type,LocalDate.parse(date),bd(q),bd(p),bd(fee))
        val tx=listOf(t(1,TradeType.BUY,"2024-01-01","10","100","10"),t(2,TradeType.BUY,"2024-01-02","10","200","10"),t(3,TradeType.SELL,"2024-01-03","5","220","5"),t(4,TradeType.DIVIDEND,"2024-01-04","0","100","0"))
        val p=PortfolioMath.positions(tx).single();assertEquals(15.0,p.quantity.toDouble(),1e-10);assertEquals(151.0,p.avgCost.toDouble(),1e-10);assertEquals(340.0,p.realized.toDouble(),1e-10);assertEquals(100.0,p.dividends.toDouble(),1e-10)
        try { PortfolioMath.positions(tx+t(5,TradeType.SELL,"2024-01-05","16","200","0")); fail("Oversell accepted") } catch(_:IllegalArgumentException) {}
    }
    @Test fun dcfUsesConsistentDiscountingAndRejectsInvalidTerminalAssumptions() {
        val d=DcfCalculator.calculate(100.0,0.0,0.10,0.0,0.0,10.0)
        assertEquals(100.0,d.perShare,1e-8)
        try { DcfCalculator.calculate(100.0,0.0,0.05,0.05,0.0,10.0); fail("Invalid perpetuity accepted") } catch(_:IllegalArgumentException) {}
        try { DcfCalculator.calculate(100.0,0.0,0.10,0.0,0.0,0.0); fail("Zero shares accepted") } catch(_:IllegalArgumentException) {}
    }
    @Test fun xirrHandlesAnnualReturnsAndRejectsAmbiguousCashFlows() {
        fun f(date:String,amount:Double)=PortfolioMath.CashFlow(LocalDate.parse(date),amount)
        assertEquals(0.1,PortfolioMath.xirr(listOf(f("2023-01-01",-100.0),f("2024-01-01",110.0)))!!,1e-8)
        assertNull(PortfolioMath.xirr(listOf(f("2023-01-01",-100.0),f("2023-06-01",230.0),f("2024-01-01",-132.0))))
        assertNull(PortfolioMath.xirr(listOf(f("2023-01-01",-100.0),f("2023-01-01",110.0))))
    }
}
