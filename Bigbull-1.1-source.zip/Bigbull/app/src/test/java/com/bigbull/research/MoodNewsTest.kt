package com.bigbull.research
import org.junit.Test
import org.junit.Assert.*
import java.time.LocalDate
class MoodNewsTest {
 @Test fun percentileTiesAndDirection(){val h=List(120){10.0};assertEquals(50.0,MoodMath.percentile(10.0,h),0.0);assertEquals(100.0,MoodMath.percentile(11.0,h),0.0);assertEquals(0.0,MoodMath.percentile(9.0,h),0.0);assertThrows(IllegalArgumentException::class.java){MoodMath.percentile(1.0,listOf(1.0))}}
 @Test fun matchingSessionAndBreadthRequired(){val c=(0..299).map{val v=100.0+it;Candle(LocalDate.parse("2024-01-01").plusDays(it.toLong()).toString(),v,v,v,v,0.0)};val d=LocalDate.parse(c.last().time);val snapshot=MarketSnapshot(d,listOf(MarketEntry("A",110.0,100.0,10.0),MarketEntry("B",90.0,100.0,10.0)),"","");val m=MoodMath.calculate(c,c,snapshot);assertEquals(50.0,m.factors[2].score,0.0);assertTrue(m.score in 0.0..100.0);assertThrows(IllegalArgumentException::class.java){MoodMath.calculate(c,c.dropLast(1),snapshot)}}
 @Test fun zonesAreExplicit(){assertEquals("Extreme fear",MoodMath.zone(24.0));assertEquals("Fear",MoodMath.zone(44.0));assertEquals("Neutral",MoodMath.zone(50.0));assertEquals("Greed",MoodMath.zone(75.0));assertEquals("Extreme greed",MoodMath.zone(76.0))}
 @Test fun rssParsesAndRejectsUnsafeLinks(){val x="""<rss><channel><item><title>A &amp; B</title><link>https://economictimes.indiatimes.com/markets/test</link><pubDate>Today</pubDate></item><item><title>unsafe</title><link>javascript:alert(1)</link></item></channel></rss>""";val rows=NewsFeed.parse(x);assertEquals(1,rows.size);assertEquals("A & B",rows[0].title)}
 @Test fun rssRejectsExternalEntities(){assertThrows(Exception::class.java){NewsFeed.parse("""<!DOCTYPE rss [<!ENTITY e SYSTEM "file:///etc/passwd">]><rss><channel><item><title>&e;</title></item></channel></rss>""")}}
}
