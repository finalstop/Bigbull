package com.bigbull.research

import org.junit.Assert.*
import org.junit.Test
import java.time.*

/** Synthetic parser fixtures only. No sample quotes are shipped in the app. */
class PublicDataTest {
    private val stock=Instrument("TEST","NSE")
    private fun chart(symbol:String="TEST.NS",currency:String="INR",exchange:String="NSI",volume:String="10,20")="""{"chart":{"error":null,"result":[{"meta":{"symbol":"$symbol","currency":"$currency","exchangeName":"$exchange"},"timestamp":[1704186900,1704273300],"indicators":{"quote":[{"open":[100,101],"high":[102,103],"low":[99,100],"close":[101,102],"volume":[$volume]}]}}]}}"""
    @Test fun historyExcludesTodaysIncompleteBarAndValidatesIdentity(){
        val rows=YahooHistory.parse(chart(),stock,"1day",LocalDate.parse("2024-01-03"))
        assertEquals(1,rows.size);assertEquals("2024-01-02",rows.single().time)
        listOf(chart(symbol="OTHER.NS"),chart(currency="USD"),chart(exchange="NYQ")).forEach{body->assertThrows(IllegalArgumentException::class.java){YahooHistory.parse(body,stock,"1day",LocalDate.parse("2024-01-04"))}}
    }
    @Test fun historyDoesNotInventMissingVolumeOrKeepCurrentWeek(){
        val rows=YahooHistory.parse(chart(volume="null,20"),stock,"1day",LocalDate.parse("2024-01-04"));assertEquals(1,rows.size);assertEquals("2024-01-03",rows.single().time)
        assertThrows(IllegalArgumentException::class.java){YahooHistory.parse(chart(),stock,"1week",LocalDate.parse("2024-01-04"))}
        assertThrows(IllegalArgumentException::class.java){YahooHistory.parse(chart(),stock,"1month",LocalDate.parse("2024-01-04"))}
    }
    @Test fun nseBreadthExcludesOtherSeriesAndNewListings(){
        val text="SYMBOL, SERIES, DATE1, CLOSE_PRICE, PREV_CLOSE, TTL_TRD_QNTY\nUP, EQ, 02-Jan-2024,110,100,50\nDOWN, EQ, 02-Jan-2024,90,100,40\nFLAT, EQ, 02-Jan-2024,100,100,30\nOTHER, BE, 02-Jan-2024,99,100,20\nNEW, EQ, 02-Jan-2024,80,0,10"
        val date=LocalDate.parse("2024-01-02");val rows=NseCsv.parse(text,date);val snap=MarketSnapshot(date,rows,"test","test")
        assertEquals(3,rows.size);assertEquals(1,snap.advances);assertEquals(1,snap.declines);assertEquals(1,snap.unchanged);assertEquals(10.0,rows[0].change,1e-8)
        assertThrows(IllegalArgumentException::class.java){NseCsv.parse(text,date.plusDays(1))}
    }
    private fun financial(currency:String="USD",symbol:String="TEST.NS",period:String="12M")="""{"timeseries":{"error":null,"result":[{"meta":{"symbol":["$symbol"],"type":["annualTotalRevenue"]},"annualTotalRevenue":[{"asOfDate":"2024-03-31","periodType":"$period","currencyCode":"$currency","reportedValue":{"raw":1000}}]},{"meta":{"symbol":["$symbol"],"type":["annualNetIncome"]},"annualNetIncome":[{"asOfDate":"2024-03-31","periodType":"$period","currencyCode":"USD","reportedValue":{"raw":-10}}]}]}}"""
    @Test fun financialsPreserveCurrencyLossesAndMissingFields(){
        val j=FreeFinancials.parse(financial(),stock,"income_statement","annual");assertEquals("USD",j.getJSONObject("meta").getString("currency"));val latest=j.getJSONArray("income_statement").getJSONObject(0)
        assertEquals(-10.0,latest.getDouble("net_income"),0.0);assertFalse(latest.has("gross_profit"))
        listOf(financial(currency="INR"),financial(symbol="WRONG.NS"),financial(period="3M")).forEach{assertThrows(IllegalArgumentException::class.java){FreeFinancials.parse(it,stock,"income_statement","annual")}}
    }
    @Test fun researchVolumeExcludesCurrentBarAndSignalsNeedHistory(){
        val c=(1..21).map{Candle(LocalDate.parse("2024-01-01").plusDays(it.toLong()).toString(),100.0,101.0,99.0,100.0,if(it==21)200.0 else 100.0)}
        val signals=ResearchBrief.signals(c);assertEquals("Needs more history",signals.first().reading);assertTrue(signals[2].explanation.startsWith("2.00×"));assertEquals("Within its usual RSI range",signals[1].reading)
    }
}
