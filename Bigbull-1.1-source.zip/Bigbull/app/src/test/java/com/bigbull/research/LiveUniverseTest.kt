package com.bigbull.research
import org.junit.Test
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import java.util.concurrent.Executors
import java.util.concurrent.Callable
class LiveUniverseTest {
    @Test fun officialUniversesAndFullBenchmark(){assumeTrue(System.getenv("BIGBULL_FULL_SCAN")=="true");val benchmark=ScreenUniverses.load(ScreenUniverses.options.first());assertTrue(benchmark.stocks.size in 480..520)
        for(s in ScreenUniverses.options.filter{it.id !in listOf("500","bse","bseonly","watchlist")}){val u=ScreenUniverses.load(s);assertTrue(u.stocks.isNotEmpty());println("Universe ${s.title}: ${u.stocks.size}")}
        for(kind in listOf("results","dividend")){val rows=CorporateCalendar.parse(ReaderSource.bytes(CorporateCalendar.url(kind)).toString(Charsets.UTF_8),kind);assertTrue(rows.isNotEmpty());println("Official $kind: ${rows.size}")}
        val pool=Executors.newFixedThreadPool(3);try{val history=pool.invokeAll(benchmark.stocks.map{s->Callable{try{s.id to FreeMarketData().candles(s,"1day","2y").candles}catch(_:Exception){null}.also{Thread.sleep(100)}}}).mapNotNull{it.get()}.toMap();val r=RelativeStrength.rank(benchmark.stocks,history,benchmark.stocks.size-history.size);println("RS session ${r.session}: ${r.eligible}/${r.requested} eligible, ${r.failures} failures, ${r.excluded} short/out-of-session");assertTrue(r.usable);val facts=ValuationFacts(null,"",null,null,null);val matches=benchmark.stocks.count{InvestorScreens.evaluate(0,facts,history[it.id].orEmpty(),r.scores[it.id]).all{r->r.passed==true}};println("Strict matches $matches / ${benchmark.stocks.size}")}finally{pool.shutdownNow()}
    }
}
