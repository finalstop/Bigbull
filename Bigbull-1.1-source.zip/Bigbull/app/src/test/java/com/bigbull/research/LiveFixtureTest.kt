package com.bigbull.research

import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File
import java.time.LocalDate

/** Optional live-response validation. Files are fetched separately, never bundled as app data. */
class LiveFixtureTest {
    @Test fun validateDownloadedPublicResponses(){
        val path=System.getenv("BIGBULL_LIVE_FIXTURES");assumeTrue("No downloaded live response directory supplied",path!=null)
        val dir=File(path!!)
        val nse=NseCsv.parse(File(dir,"nse.csv").readText(),LocalDate.parse("2026-10-27"));assertTrue(nse.size>1000)
        val today=LocalDate.parse("2026-10-28")
        val nsePrices=YahooHistory.parse(File(dir,"reliance.json").readText(),Instrument("RELIANCE","NSE"),"1day",today);assertTrue(nsePrices.size>250)
        val bse=YahooHistory.parse(File(dir,"infy-bse.json").readText(),Instrument("INFY","BSE"),"1day",today);assertTrue(bse.isNotEmpty()) // Public BSE history may contain only one completed bar.
        val income=FreeFinancials.parse(File(dir,"income.json").readText(),Instrument("RELIANCE","NSE"),"income_statement","annual");assertTrue(income.getJSONArray("income_statement").length()>1)
        val balance=FreeFinancials.parse(File(dir,"balance.json").readText(),Instrument("INFY","NSE"),"balance_sheet","quarterly");assertTrue(balance.getJSONArray("balance_sheet").length()>1)
        val cash=FreeFinancials.parse(File(dir,"cash.json").readText(),Instrument("TCS","NSE"),"cash_flow","annual");assertTrue(cash.getJSONArray("cash_flow").length()>1)
        println("Live validation: ${nse.size} NSE entries, ${nsePrices.size} NSE bars, ${bse.size} BSE bars, annual income/cash-flow and quarterly balance-sheet data.")
    }
}
