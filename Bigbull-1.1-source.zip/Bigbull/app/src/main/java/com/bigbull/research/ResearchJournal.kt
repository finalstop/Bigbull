package com.bigbull.research

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.time.LocalDate
import java.time.Instant

data class Thesis(val reason:String="",val risks:String="",val evidence:String="",val review:String="",val updated:String="") {
 fun json()=JSONObject().put("reason",reason).put("risks",risks).put("evidence",evidence).put("review",review).put("updated",updated).toString()
 companion object {fun parse(raw:String?):Thesis=runCatching{val j=JSONObject(raw?:"{}");Thesis(j.optString("reason"),j.optString("risks"),j.optString("evidence"),j.optString("review"),j.optString("updated"))}.getOrDefault(Thesis())}
 fun export(symbol:String)="$symbol — Research journal\n\nThesis\n$reason\n\nWhat would change my mind\n$risks\n\nSources / evidence\n$evidence\n\nReview: $review\nSaved: $updated"
}
class ThesisStore(context:Context){private val prefs=context.getSharedPreferences("research_journal",Context.MODE_PRIVATE);fun load(id:String)=Thesis.parse(prefs.getString(id,null));fun save(id:String,t:Thesis):Boolean=prefs.edit().putString(id,t.json()).commit()}
@Composable fun ResearchJournal(stock:Instrument){
 val context=LocalContext.current;val store=remember{ThesisStore(context)};val initial=remember(stock.id){store.load(stock.id)}
 var reason by remember(stock.id){mutableStateOf(initial.reason)};var risks by remember(stock.id){mutableStateOf(initial.risks)};var evidence by remember(stock.id){mutableStateOf(initial.evidence)};var review by remember(stock.id){mutableStateOf(initial.review)};var status by remember(stock.id){mutableStateOf(initial.updated.takeIf{it.isNotBlank()}?.let{"Saved $it"}?:"Your private research, stored on this device.")}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
  Text("Research journal",style=MaterialTheme.typography.headlineMedium);Muted("${stock.symbol} · A one-page thesis you can revisit after results.")
  if(runCatching{review.isNotBlank()&&!LocalDate.parse(review).isAfter(LocalDate.now())}.getOrDefault(false))Text("Review due · revisit the evidence and your risks",color=MaterialTheme.colorScheme.primary)
  OutlinedTextField(reason,{reason=it.take(10000)},label={Text("Why this company?")},modifier=Modifier.fillMaxWidth(),minLines=3)
  OutlinedTextField(risks,{risks=it.take(10000)},label={Text("What would change my mind?")},modifier=Modifier.fillMaxWidth(),minLines=3)
  OutlinedTextField(evidence,{evidence=it.take(10000)},label={Text("Sources, links and evidence")},modifier=Modifier.fillMaxWidth(),minLines=3)
  OutlinedTextField(review,{review=it.take(10)},label={Text("Next review · YYYY-MM-DD")},modifier=Modifier.fillMaxWidth(),singleLine=true)
  Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){
   Button(onClick={if(review.isNotBlank()&&runCatching{LocalDate.parse(review)}.isFailure)status="Use a valid review date: YYYY-MM-DD." else {val t=Thesis(reason,risks,evidence,review,Instant.now().toString());status=if(store.save(stock.id,t))"Saved ${t.updated}" else "Could not save. Please retry."}}){Text("Save journal")}
   TextButton(onClick={runCatching{context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,Thesis(reason,risks,evidence,review).export(stock.symbol)),"Export research journal"))}.onFailure{status="No app available to export text."}}){Text("Export text")}
  }
  Muted(status);Muted("Save before leaving. Review dates are shown here, not sent as notifications. Your own notes are never used as reported company data.")
 }
}
