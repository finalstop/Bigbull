package com.bigbull.research

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import kotlin.math.abs

data class TechnicalVote(val name:String,val value:Double?,val direction:Int?,val rule:String)
data class TechnicalVerdict(val votes:List<TechnicalVote>) {
 val available get()=votes.count{it.direction!=null}
 val bulls get()=votes.count{it.direction==1}
 val bears get()=votes.count{it.direction== -1}
 val neutral get()=votes.count{it.direction==0}
 val score get()=if(available<4)null else 50.0+50.0*(bulls-bears)/available
 val label get()=score?.let{when{it>=80->"Strong buy";it>=60->"Can buy";it<=20->"Strong sell";it<=40->"Can sell";else->"Neutral"}}?:"Insufficient history"
}
object TechnicalRating {
 fun evaluate(c:List<Candle>):TechnicalVerdict {
  if(c.isEmpty()||c.any{!it.close.isFinite()||it.close<=0})return TechnicalVerdict(emptyList())
  val x=c.map{it.close};val price=x.last();val rows=mutableListOf<TechnicalVote>()
  fun compare(name:String,a:Double?,b:Double?,rule:String){val d=if(a==null||b==null||!a.isFinite()||!b.isFinite())null else if(abs(a-b)<=maxOf(abs(b)*.001,1e-9))0 else if(a>b)1 else -1;rows.add(TechnicalVote(name,a,d,rule))}
  for(p in listOf(20,50,200))compare("Price / SMA $p",price.takeIf{x.size>=p},Indicators.sma(x,p).lastOrNull(),"Bullish above SMA $p; bearish below; ±0.1% neutral.")
  compare("EMA 20 / 50",Indicators.ema(x,20).lastOrNull(),Indicators.ema(x,50).lastOrNull(),"Bullish when EMA20 exceeds EMA50; bearish below; ±0.1% neutral.")
  val macd=Indicators.macd(x).lastOrNull();compare("MACD / signal",macd?.line,macd?.signal,"Bullish MACD above its 9-bar signal; bearish below.")
  val rsi=Indicators.rsi(x).lastOrNull();rows.add(TechnicalVote("RSI 14",rsi,rsi?.let{if(it>55)1 else if(it<45)-1 else 0},"Momentum reading: >55 bullish, <45 bearish, otherwise neutral. Extremes can reverse."))
  val roc=if(x.size>20)(price/x[x.lastIndex-20]-1)*100 else null;rows.add(TechnicalVote("20-bar momentum",roc,roc?.let{if(it>1)1 else if(it< -1)-1 else 0},"Price change over 20 bars: >1% bullish, <−1% bearish, otherwise neutral."))
  return TechnicalVerdict(rows)
 }
}
@Composable fun TechnicalBarometer(series:Series){
 val result=remember(series){TechnicalRating.evaluate(series.candles)}
 val target=((result.score?:50.0)/100).toFloat();var entered by remember{mutableStateOf(false)};LaunchedEffect(result){entered=true}
 val position by animateFloatAsState(if(entered)target else .5f,tween(700),label="Technical barometer")
 val tone=when{(result.score?:50.0)>=60->Positive;(result.score?:50.0)<=40->Negative;else->MaterialTheme.colorScheme.onSurfaceVariant}
 Panel(Modifier.fillMaxWidth()){
  Kicker("TECHNICAL OUTLOOK");result.score?.let{Muted("Score ${it.toInt()} / 100")};Text(result.label,style=MaterialTheme.typography.headlineMedium,color=tone,fontWeight=FontWeight.SemiBold)
  Muted("${series.interval} · ${series.candles.lastOrNull()?.time?:"No history"} · ${result.available}/7 signals available")
  val neutral=MaterialTheme.colorScheme.onSurfaceVariant;val positive=Positive;val negative=Negative
  Canvas(Modifier.fillMaxWidth().height(86.dp).semantics{contentDescription="${result.label}. ${result.bears} bearish, ${result.neutral} neutral, ${result.bulls} bullish signals"}){
   val pad=8.dp.toPx();val w=size.width-2*pad
   for(i in 0..28){val f=i/28f;val color=if(f<.4f)negative else if(f>.6f)positive else neutral;drawLine(color.copy(alpha=if(abs(f-position)<.15f)1f else .35f),Offset(pad+w*f,15.dp.toPx()),Offset(pad+w*f,43.dp.toPx()),strokeWidth=4.dp.toPx(),cap=StrokeCap.Round)}
   if(result.score!=null){val px=pad+w*position;val y=54.dp.toPx();drawPath(Path().apply{moveTo(px,y);lineTo(px-6.dp.toPx(),y+10.dp.toPx());lineTo(px+6.dp.toPx(),y+10.dp.toPx());close()},tone)}
  }
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${result.bears} Bearish",color=Negative);Text("${result.neutral} Neutral");Text("${result.bulls} Bullish",color=Positive)}
  var details by remember{mutableStateOf(false)}
  TextButton(onClick={details=!details}){Text(if(details)"Hide signals" else "Why this rating?")}
  if(details){result.votes.forEach{v->Text("${v.name}: ${v.direction?.let{if(it>0)"Bullish" else if(it<0)"Bearish" else "Neutral"}?:"Unavailable"}",fontWeight=FontWeight.Medium);Muted(v.rule);Spacer(Modifier.height(8.dp))};Muted("Equal votes. Score = 50 + 50 × (bullish − bearish) / available. Strong buy ≥80; can buy ≥60; neutral 40–60; can sell ≤40; strong sell ≤20. At least four signals required. Correlated indicators are not independent evidence.")}
  Muted("Calculated from the completed ${series.interval} candles shown above.")
 }
}
