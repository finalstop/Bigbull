package com.bigbull.research

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import java.time.LocalDate

// Tri-state rules: unknown inputs are never equivalent to zero or a passing condition.
data class InvestorRule(val title:String,val formula:String,val passed:Boolean?,val reading:String)
data class InvestorMethod(val name:String,val subtitle:String,val note:String,val url:String)
object InvestorScreens {
    val methods=listOf(
        InvestorMethod("Mark Minervini","Trend Template","All eight rules must pass; missing data disqualifies. SMA200 must be higher than 21 sessions ago, not rise every day. Price must be 30% above its 52-week low and within 25% of its high. Bigbull RS is a 12-month price-return percentile against eligible NIFTY 500 members at the same completed session, with midpoint ties. It is not IBD's proprietary rating. At least 300 eligible members and ≤5% fetch failures are required; coverage is shown. This gate is not full SEPA or a VCP entry signal.","https://www.minervini.com/books"),
        InvestorMethod("Warren Buffett","Quality & cash generation","Bigbull's quantitative interpretation: ROE ≥15%, debt/equity ≤0.5, margin ≥10%, operating cash/profit ≥1. These thresholds are ours, not a formula published by Buffett. Moat, management, maintenance capex and durable economics need manual research. Owner earnings ≈ net income + depreciation and other non-cash charges − maintenance capex − necessary working-capital investment.","https://www.berkshirehathaway.com/letters/1986.html"),
        InvestorMethod("Benjamin Graham","Defensive value","Partial defensive-value screen: current ratio ≥2, annual P/E ≤15, P/B ≤1.5 and P/E × P/B ≤22.5. Annual diluted EPS replaces Graham's three-year average here. The full method also considers size, long earnings/dividend records and growth; these checks are not supplied.","https://www.aaii.com/stock-investor-pro/screens?sid=34"),
        InvestorMethod("Peter Lynch","Growth at a reasonable price","Lynch-inspired historical PEG screen. PEG = annual P/E ÷ historical EPS CAGR in percentage points; below 1 passes the PEG rule. Growth and debt thresholds shown below are Bigbull choices. This uses reported growth, not an estimate of future growth, and is not Lynch's entire stock-selection process.","https://www.fidelity.com/bin-public/060_www_fidelity_com/documents/learning-center/Presentation_Investing%20legends.pdf")
    )
    private fun rule(title:String,formula:String,value:Double?,test:(Double)->Boolean)=InvestorRule(title,formula,value?.let(test),value?.let{num(it)}?:"Unavailable")
    fun evaluate(index:Int,v:ValuationFacts,c:List<Candle>,rs:Double?=null):List<InvestorRule>{
        if(index==0){
            val sorted=c.sortedBy{it.time};val closes=sorted.map{it.close};val price=closes.lastOrNull()
            fun sma(n:Int)=closes.takeLast(n).takeIf{it.size==n}?.average()
            val m50=sma(50);val m150=sma(150);val m200=sma(200)
            fun comparison(t:String,f:String,a:Double?,b:Double?)=InvestorRule(t,f,if(a!=null&&b!=null)a>b else null,if(a!=null&&b!=null)"${num(a)} / ${num(b)}" else "Needs more daily history")
            val last=sorted.lastOrNull()?.time?.take(10)?.let{LocalDate.parse(it)}
            val cutoff=last?.minusWeeks(52)
            val year=if(cutoff!=null&&sorted.firstOrNull()?.time?.take(10)?.let{LocalDate.parse(it)<=cutoff}==true)sorted.filter{LocalDate.parse(it.time.take(10))>=cutoff} else emptyList()
            val low=year.minOfOrNull{it.low};val high=year.maxOfOrNull{it.high}
            val averages=Indicators.sma(closes,200).takeLast(22)
            val rising=if(averages.size==22&&averages.all{it!=null})averages.last()!!>averages.first()!! else null
            return listOf(
                InvestorRule("Price above long averages","Close > SMA150 and SMA200",if(price!=null&&m150!=null&&m200!=null)price>m150&&price>m200 else null,"Close ${price?.let{num(it)}?:"—"} · SMA150 ${m150?.let{num(it)}?:"—"} · SMA200 ${m200?.let{num(it)}?:"—"}"),
                comparison("Long averages aligned","SMA150 > SMA200",m150,m200),
                InvestorRule("Rising 200-day average","SMA200 now > SMA200 21 sessions ago",rising,if(rising==null)"Needs 221 daily bars" else if(rising)"Higher than 21 sessions ago" else "Not higher than 21 sessions ago"),
                InvestorRule("Short average leads","SMA50 > SMA150 and SMA200",if(m50!=null&&m150!=null&&m200!=null)m50>m150&&m50>m200 else null,"SMA50 ${m50?.let{num(it)}?:"—"}"),
                comparison("Price above SMA50","Close > SMA50",price,m50),
                rule("Off its 52-week low","Close / 52W low − 1 ≥ 30%",if(price!=null&&low!=null&&low>0)(price/low-1)*100 else null){it>=30},
                rule("Near its 52-week high","Close / 52W high ≥ 75%",if(price!=null&&high!=null&&high>0)price/high*100 else null){it>=75},
                InvestorRule("Relative strength rank","12M return percentile vs eligible NIFTY 500 ≥70",rs?.let{it>=70},rs?.let{num(it,1)+" / 100"}?:"Awaiting benchmark · not RSI")
            )
        }
        return when(index){
            1->listOf(rule("Return on equity","Net income / average equity ×100 ≥15%",v.roe){it>=15},rule("Conservative debt","Total debt / positive equity ≤0.5",v.debtEquity){it in 0.0..0.5},rule("Net margin","Net income / revenue ×100 ≥10%",PeerFacts.margin(v.i)){it>=10},rule("Cash backs earnings","Same-year operating cash / net income ≥1",v.earningsToCash()){it>=1})
            2->listOf(rule("Liquidity","Current assets / current liabilities ≥2",v.currentRatio){it>=2},rule("Earnings multiple","0 < annual P/E ≤15",v.pe){it>0&&it<=15},rule("Book multiple","0 < P/B ≤1.5",v.pb){it>0&&it<=1.5},rule("Combined valuation","P/E × P/B ≤22.5",v.pe?.let{pe->v.pb?.let{pe*it}}){it>0&&it<=22.5})
            else->listOf(rule("Historical PEG","0 < P/E / EPS CAGR(%) <1",v.peg){it>0&&it<1},rule("Earnings growth","3–5Y diluted EPS CAGR ≥10%",v.epsGrowth){it>=10},rule("Manageable debt","Total debt / positive equity ≤1",v.debtEquity){it in 0.0..1.0})
        }
    }
}
@Composable fun ScreenerPage(app:AppState){
    var legends by remember{mutableStateOf(true)}
    Column(Modifier.fillMaxSize()){
        Row(Modifier.padding(horizontal=20.dp,vertical=12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
            SmallChip("Investor playbooks",legends){legends=true};SmallChip("Custom filters",!legends){legends=false}
        }
        if(legends)InvestorScreenPage(app)else CustomScreenerPage(app)
    }
}
