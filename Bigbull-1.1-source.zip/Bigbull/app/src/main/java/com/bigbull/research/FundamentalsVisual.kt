package com.bigbull.research
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.json.JSONObject
import kotlin.math.abs

data class FinancialPoint(val date:String,val value:Double)
object FinancialViewData {
    fun points(report:JSONObject,endpoint:String,metric:String):List<FinancialPoint>{val a=report.optJSONArray(endpoint)?:return emptyList();return (0 until a.length()).mapNotNull{i->val row=a.getJSONObject(i);val date=row.optString("fiscal_date");val value=row.optString(metric).toDoubleOrNull();if(date.isBlank()||value==null||!value.isFinite())null else FinancialPoint(date,value)}.sortedBy{it.date}}
    fun growth(points:List<FinancialPoint>):Double?{if(points.size<2)return null;val latest=points.last();val prior=points.dropLast(1).lastOrNull{val days=java.time.temporal.ChronoUnit.DAYS.between(java.time.LocalDate.parse(it.date),java.time.LocalDate.parse(latest.date));days in 330..400}?:return null;return if(prior.value>0)(latest.value/prior.value-1)*100 else null}
}
@Composable fun FinancialsWorkspace(app:AppState,stock:Instrument){
    var endpoint by remember(stock.id){mutableStateOf("income_statement")};var period by remember(stock.id){mutableStateOf("annual")}
    val report=app.report(stock,endpoint,period);val parsed=remember(report){report?.let{JSONObject(it.second)}}
    val options=when(endpoint){"income_statement"->listOf("sales" to "Revenue","net_income" to "Net profit","operating_income" to "Operating profit","gross_profit" to "Gross profit");"balance_sheet"->listOf("total_assets" to "Assets","total_debt" to "Debt","stockholders_equity" to "Equity","cash_and_cash_equivalents" to "Cash");else->listOf("operating_cash_flow" to "Operating cash","free_cash_flow" to "Free cash flow","capital_expenditure" to "Capex")}
    var metric by remember(endpoint){mutableStateOf(options.first().first)}
    Text("Financial performance",fontSize=22.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Muted("Annual and quarterly reported results")
    Spacer(Modifier.height(16.dp));Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("income_statement" to "Income","balance_sheet" to "Balance sheet","cash_flow" to "Cash flow").forEach{(e,t)->SmallChip(t,endpoint==e){endpoint=e;if(app.report(stock,e,period)==null)app.loadReport(stock,e,period)}}}
    Spacer(Modifier.height(10.dp));Row(verticalAlignment=Alignment.CenterVertically){listOf("annual","quarterly").forEach{p->TextButton(onClick={period=p;if(app.report(stock,endpoint,p)==null)app.loadReport(stock,endpoint,p)}){Text(p.replaceFirstChar{it.uppercase()},fontWeight=if(p==period)FontWeight.Bold else FontWeight.Normal)}};Spacer(Modifier.weight(1f));TextButton(onClick={app.loadReport(stock,endpoint,period)},enabled=!app.isLoading){Text("Refresh")}}
    if(parsed==null){Spacer(Modifier.height(25.dp));Muted(if(app.isLoading)"Synchronizing financial statements…" else "Statement not available. Tap Refresh to retry the public source.");return}
    val currency=parsed.optJSONObject("meta")?.optString("currency","Unspecified") ?: "Unspecified"
    val divisor=if(currency=="INR")10_000_000.0 else 1_000_000.0;val unit=if(currency=="INR")"₹ crore" else "$currency million"
    Spacer(Modifier.height(10.dp));Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){options.forEach{(k,t)->SmallChip(t,metric==k){metric=k}}}
    val points=FinancialViewData.points(parsed,endpoint,metric);var chosen by remember(points){mutableIntStateOf(points.lastIndex)};val selected=points.getOrNull(chosen)
    Spacer(Modifier.height(22.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column{Muted(options.first{it.first==metric}.second);Text(selected?.let{num(it.value/divisor,1)}?:"—",fontSize=27.sp,fontWeight=FontWeight.Bold);Muted("$unit · ${selected?.date ?: "Unavailable"}")};Column(horizontalAlignment=Alignment.End){Muted("Year-on-year");val growth=FinancialViewData.growth(points);Text(growth?.let{relative(it)}?:"—",fontSize=20.sp,fontWeight=FontWeight.SemiBold,color=if((growth?:0.0)>=0)Positive else Negative)}}
    Spacer(Modifier.height(18.dp))
    if(points.isEmpty())Muted("The source has not supplied this metric.")else{
        val min=minOf(0.0,points.minOf{it.value});val max=maxOf(0.0,points.maxOf{it.value});val range=(max-min).takeIf{it>0}?:1.0
        val zero=(max/range).toFloat();val blue=MaterialTheme.colorScheme.primary;val loss=Negative
        Canvas(Modifier.fillMaxWidth().height(150.dp)){
            val slot=size.width/points.size
            drawLine(Color(0xFFDCE2E8),Offset(0f,size.height*zero),Offset(size.width,size.height*zero),1.dp.toPx())
            points.forEachIndexed{i,p->val y=((max-p.value)/range*size.height).toFloat();val z=size.height*zero;drawRoundRect(if(p.value<0)loss else blue.copy(alpha=if(i==chosen)1f else .42f),Offset(slot*i+slot*.2f,minOf(y,z)),Size(slot*.6f,abs(y-z).coerceAtLeast(1f)),androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))}
        }
        Row(Modifier.fillMaxWidth()){points.forEachIndexed{i,p->Column(Modifier.weight(1f).clickable{chosen=i}.padding(vertical=10.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(if(period=="annual")"FY"+p.date.take(4).takeLast(2)else p.date.substring(2,7),fontSize=11.sp,color=if(chosen==i)blue else MaterialTheme.colorScheme.onSurfaceVariant);Text(num(p.value/divisor,0),fontSize=10.sp)}}}
        Muted("Tap a period for its value · bars share one scale · missing values are omitted")
    }
    Spacer(Modifier.height(22.dp));Text("Statement comparison",fontSize=17.sp,fontWeight=FontWeight.SemiBold)
    val a=parsed.optJSONArray(endpoint);if(a!=null)Row(Modifier.horizontalScroll(rememberScrollState())){Column{Row{Text("$unit",Modifier.width(125.dp).padding(vertical=12.dp),fontSize=12.sp);for(i in 0 until minOf(a.length(),6))Text(a.getJSONObject(i).optString("fiscal_date"),Modifier.width(105.dp).padding(vertical=12.dp),fontSize=12.sp,fontWeight=FontWeight.SemiBold)};options.forEach{(key,title)->HorizontalDivider();Row{Text(title,Modifier.width(125.dp).padding(vertical=12.dp),fontSize=13.sp);for(i in 0 until minOf(a.length(),6)){val value=a.getJSONObject(i).optString(key).toDoubleOrNull();Text(value?.let{num(it/divisor,1)}?:"—",Modifier.width(105.dp).padding(vertical=12.dp),fontSize=13.sp)}}}}}
    Spacer(Modifier.height(15.dp));var detail by remember{mutableStateOf(false)};TextButton(onClick={detail=!detail},contentPadding=PaddingValues(0.dp)){Text("ⓘ Source & calculations")};if(detail){Muted("Yahoo Finance financial timeseries · fetched ${report?.first}. Figures retain the report currency. FY labels use fiscal end years, not calendar-year estimates. Growth compares a period approximately one year earlier with a positive denominator. Missing dates and metrics are not interpolated.");SourceLink("Company research","https://www.screener.in/company/${stock.symbol}/");JsonRows(parsed,0)}
}
