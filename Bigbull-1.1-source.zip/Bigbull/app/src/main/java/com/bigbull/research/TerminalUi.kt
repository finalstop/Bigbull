package com.bigbull.research

import androidx.compose.foundation.*
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.json.JSONObject

private val Ink=Color(0xFF1B1E22)
private val starterStocks=listOf(Instrument("RELIANCE","NSE","Reliance Industries"),Instrument("INFY","NSE","Infosys"),Instrument("SWIGGY","NSE","Swiggy"),Instrument("TCS","NSE","Tata Consultancy Services"))
@Composable fun TerminalTabs(tabs:List<String>,selected:Int,onSelect:(Int)->Unit){
    ScrollableTabRow(selectedTabIndex=selected,edgePadding=12.dp,containerColor=MaterialTheme.colorScheme.background){tabs.forEachIndexed{i,t->Tab(selected==i,onClick={onSelect(i)},selectedContentColor=MaterialTheme.colorScheme.primary,unselectedContentColor=MaterialTheme.colorScheme.onSurfaceVariant,text={Text(t,fontWeight=FontWeight.SemiBold)})}}
}
@Composable fun TerminalHome(app:AppState)=PremiumMarkets(app)
@Composable private fun Metric(label:String,value:String,color:Color=MaterialTheme.colorScheme.onSurface){Column{Text(value,fontWeight=FontWeight.Bold,fontSize=21.sp,color=color);Muted(label)}}
@Composable fun MoodPanel(app:AppState){
    LaunchedEffect(Unit){if(app.mood==null)app.loadMood()}
    SectionTitle("Fear & Greed"){TextButton(onClick={app.loadMood()},enabled=!app.moodLoading){Text(if(app.moodLoading)"Loading…" else "Refresh")}}
    Muted("Market Mood Index · Indian equities")
    val m=app.mood
    if(m==null){Spacer(Modifier.height(18.dp));Muted(app.moodError ?: "Loading NIFTY, India VIX and market breadth…")}else{
        AnimatedMoodGauge(m)
        Muted("Session ${m.date} · updated ${displayTime(m.fetched)}")
        if(m.comparisons.isNotEmpty())Row(Modifier.fillMaxWidth().padding(vertical=12.dp),horizontalArrangement=Arrangement.SpaceBetween){m.comparisons.forEach{(label,value)->Column{Muted(label);Text(num(value,1),fontWeight=FontWeight.SemiBold)}}}
        m.factors.forEach{f->AnalysisRow(f.name,f.display ?: num(f.score,1),f.detail)}
    }
    app.moodError?.let{Text(it,color=MaterialTheme.colorScheme.error,fontSize=12.sp)}
    var info by remember{mutableStateOf(false)}
    TextButton(onClick={info=!info},contentPadding=PaddingValues(0.dp)){Text("ⓘ Methodology & source")}
    if(info){Muted("Published Tickertape MMI with all six factor groups. The headline is the source’s published indicator; raw inputs are not independent 0–100 scores. Source date appears above. Zones: below30 extreme fear,30–50 fear,50–70 greed,70+ extreme greed. No prediction or accuracy claim. Availability depends on the source.");SourceLink("Source and methodology","https://www.tickertape.in/market-mood-index")}

}
@Composable fun NewsPage(app:AppState,stock:Instrument?=null){
    LaunchedEffect(Unit){if(app.headlines.isEmpty())app.loadNews()}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).glassClearance().padding(16.dp)){
        PageHeader(if(stock==null)"Market news" else "${stock.symbol} news",action={TextButton(onClick={app.loadNews()},enabled=!app.newsLoading){Text(if(app.newsLoading)"Loading…" else "Refresh")}})
        Muted("Independent reporting. Ad-free reading.")
        var publisher by remember{mutableStateOf("All")}
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)){(listOf("All")+NewsFeed.sources.map{it.name}).forEach{source->SmallChip(source,publisher==source){publisher=source}}}
        app.newsFetched?.let{Muted("Updated ${displayTime(it)}")};Spacer(Modifier.height(16.dp))
        val terms=if(stock==null)emptyList() else listOf(stock.symbol,stock.name.substringBefore(" ")).filter{it.length>=3}
        val items=app.headlines.filter{h->(publisher=="All" || h.source==publisher) && (stock==null || terms.any{Regex("(?i)\\b"+Regex.escape(it)+"\\b").containsMatchIn(h.title)})}
        if(items.isEmpty()&&!app.newsLoading)Muted(app.newsError ?: "No matching headlines in the current publisher feed. Coverage is limited to recent feed items.")
        items.forEach{h->Text(h.title,Modifier.clickable{app.article=h},fontSize=16.sp,fontWeight=FontWeight.Medium,lineHeight=23.sp);Spacer(Modifier.height(6.dp));Muted("${h.source} · ${displayTime(h.published)}");TextButton(onClick={app.article=h},contentPadding=PaddingValues(0.dp)){Text("Read article →")};HorizontalDivider(Modifier.padding(vertical=14.dp))}
        app.newsError?.let{Text(it,color=MaterialTheme.colorScheme.error)}
        Muted("Articles open inside Bigbull with ad/tracker filtering and reader mode. Publisher access restrictions still apply.")
    }
}
@Composable fun AnalysisRow(title:String,badge:String,explanation:String){
    var expanded by remember(title){mutableStateOf(false)}
    Column(Modifier.fillMaxWidth().animateContentSize().clickable{expanded=!expanded}.padding(vertical=18.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){Text(title,Modifier.weight(1f),fontWeight=FontWeight.SemiBold,fontSize=17.sp);Text(badge,color=MaterialTheme.colorScheme.primary,style=MaterialTheme.typography.labelLarge);Spacer(Modifier.width(12.dp));Text(if(expanded)"−" else "⌄")}
        if(expanded){Spacer(Modifier.height(8.dp));Text(explanation,fontSize=14.sp,lineHeight=21.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}
    };HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.3f))
}
private fun reportJson(app:AppState,s:Instrument,e:String)=try{app.report(s,e,"annual")?.second?.let{JSONObject(it)}}catch(_:Exception){null}
@Composable fun StockPage(app:AppState,stock:Instrument){
    var tab by remember(stock.id){mutableIntStateOf(0)};var intraday by remember(stock.id){mutableStateOf(true)};val quote=app.quotes[stock.id];val series=app.series(stock,app.interval);val c=series?.candles;val last=c?.lastOrNull();val previous=c?.dropLast(1)?.lastOrNull()
    val workspaceScroll=rememberScrollState()
    LaunchedEffect(tab){workspaceScroll.scrollTo(0)}
    Column(Modifier.fillMaxSize()){
        Surface(color=MaterialTheme.colorScheme.surface){Column(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=8.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){
                TextButton(onClick={app.selected=null},contentPadding=PaddingValues(0.dp),modifier=Modifier.width(40.dp)){Text("‹",color=MaterialTheme.colorScheme.onSurface,fontSize=28.sp)}
                Column(Modifier.weight(1f)){Text(stock.name.ifBlank{stock.symbol},color=MaterialTheme.colorScheme.onSurface,fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("${stock.symbol}  ·  ${stock.exchange}",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=11.sp,maxLines=1)}
                TextButton(onClick={app.addStock(stock);app.message="Added to watchlist"}){Text("+ Watch",color=MaterialTheme.colorScheme.primary,fontSize=12.sp)}
            }
            val change=quote?.previousClose?.let{(quote.price/it-1)*100} ?: if(quote==null&&last!=null&&previous!=null)(last.close/previous.close-1)*100 else null
            Row(Modifier.fillMaxWidth().padding(top=4.dp),verticalAlignment=Alignment.CenterVertically){
                Text(quote?.let{money(it.price)} ?: last?.let{money(it.close)} ?: "Loading…",color=MaterialTheme.colorScheme.onSurface,fontSize=30.sp,fontWeight=FontWeight.SemiBold,letterSpacing=(-.6).sp)
                Spacer(Modifier.width(12.dp));change?.let{val tone=if(it>=0)Positive else Negative;Surface(color=tone.copy(alpha=.10f),shape=RoundedCornerShape(6.dp)){Text(relative(it),Modifier.padding(horizontal=10.dp,vertical=6.dp),color=tone,fontSize=14.sp,fontWeight=FontWeight.Medium)}}
            }
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                Text(quote?.let{MarketTime.quoteLabel(it.asOf)} ?: last?.let{"Historical close · ${it.time.take(10)}"} ?: "Loading quote…",Modifier.weight(1f),color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=11.sp)
                TextButton(onClick={app.loadQuote(stock)},contentPadding=PaddingValues(0.dp),modifier=Modifier.width(40.dp)){Text("↻",color=MaterialTheme.colorScheme.primary)}
            }
        }}
        TerminalTabs(listOf("Overview","Technicals","Financials","Valuation","News","Peers","Checkpoint","Annual reports","Journal"),tab){tab=it}
        if(tab==4){NewsPage(app,stock);return@Column}
        if(tab==5){PeerPage(app,stock);return@Column}
        if(tab==6){CheckpointPage(app,stock);return@Column}
        if(tab==8){ResearchJournal(stock);return@Column}
        if(tab==7){AnnualReportsPage(app,stock);return@Column}
        Column(Modifier.verticalScroll(workspaceScroll).padding(16.dp)){
            if(tab==0){
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
                    SmallChip("Today",intraday){intraday=true;app.loadQuote(stock)}
                    Spacer(Modifier.width(8.dp));SmallChip("History",!intraday){intraday=false}
                    Spacer(Modifier.weight(1f));TextButton(onClick={app.openStock(stock)},enabled=!app.isLoading){Text(if(app.isLoading)"Updating…" else "Refresh",fontSize=12.sp)}
                }
                Spacer(Modifier.height(8.dp))
                if(intraday){
                    if(quote!=null&&quote.bars.isNotEmpty()){
                        Muted(MarketTime.sessionLabel(quote.bars));Spacer(Modifier.height(8.dp))
                        PriceChart(Series(stock,"5min",quote.bars,"Yahoo Finance",quote.fetched,false))
                    }else Muted(app.quoteErrors[stock.id] ?: "Loading intraday chart…")
                }else if(series!=null){
                    Muted("History · completed ${series.interval} bars · through ${series.candles.lastOrNull()?.time?.take(10)}")
                    Spacer(Modifier.height(8.dp));PriceChart(series)
                }else Muted("Historical chart unavailable.")
                Spacer(Modifier.height(20.dp));ValuationQuickFacts(app,stock);Spacer(Modifier.height(20.dp));SectionTitle("Research at a glance")
                val income=reportJson(app,stock,"income_statement");val arr=income?.optJSONArray("income_statement");val latest=arr?.optJSONObject(0);val old=arr?.optJSONObject(1)
                fun n(j:JSONObject?,k:String)=j?.optString(k)?.toDoubleOrNull()
                val sales=n(latest,"sales");val net=n(latest,"net_income");val oldSales=n(old,"sales")
                ResearchReading("Performance","21 completed bars",if(c!=null&&c.size>21)relative((c.last().close/c[c.lastIndex-21].close-1)*100) else "Unavailable","Return over the last 21 completed bars, through ${last?.time?.take(10) ?: "unavailable"}. No peer rank is implied.")
                ResearchReading("Revenue growth","Annual reported",if(sales!=null&&oldSales!=null&&oldSales>0)relative((sales/oldSales-1)*100) else "Unavailable","Latest two reported annual revenue periods. Fiscal dates: ${latest?.optString("fiscal_date")} and ${old?.optString("fiscal_date")}. Report currency: ${income?.optJSONObject("meta")?.optString("currency")}.")
                ResearchReading("Net margin","Annual reported",if(net!=null&&sales!=null&&sales>0)num(net/sales*100)+"%" else "Unavailable","Net profit margin = reported net income / revenue. This is not a sector-relative score.")
                Spacer(Modifier.height(12.dp));TextButton(onClick={tab=2},contentPadding=PaddingValues(0.dp)){Text("Explore financials →",fontWeight=FontWeight.SemiBold)}
                HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.2f))
                if(c!=null){var signals by remember{mutableStateOf(false)};TextButton(onClick={signals=!signals},contentPadding=PaddingValues(0.dp)){Text(if(signals)"Hide technical readings" else "Technical readings →")};if(signals)ResearchBrief.signals(c).forEach{AnalysisRow(it.title,it.reading,it.explanation)}}
                TextButton(onClick={tab=4},contentPadding=PaddingValues(0.dp)){Text("Company news →")}

                Muted("Missing inputs are unavailable, never paywalled. Analyst forecasts and peer rankings are not supplied by this free source.")
            }else if(tab==1){
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("1day","1week","1month").forEach{i->SmallChip(i,app.interval==i){app.interval=i;app.sync(stock,i)}}};Spacer(Modifier.height(14.dp));if(series!=null){TechnicalBarometer(series);Spacer(Modifier.height(16.dp));PriceChart(series);TechnicalPanel(series)}else Muted("Waiting for source history.")
            }else if(tab==2){FinancialsWorkspace(app,stock)}else{AutomaticValuation(app,stock)}
        }
    }
}
@Composable fun AutomaticValuation(app:AppState,stock:Instrument) = IntrinsicValuePanel(app,stock)

private fun displayTime(value:String):String=try {
    val instant=try{java.time.Instant.parse(value)}catch(_:Exception){java.time.ZonedDateTime.parse(value,java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME).toInstant()}
    java.time.format.DateTimeFormatter.ofPattern("d MMM, h:mm a",java.util.Locale.ENGLISH).withZone(java.time.ZoneId.of("Asia/Kolkata")).format(instant)+" IST"
}catch(_:Exception){value}
