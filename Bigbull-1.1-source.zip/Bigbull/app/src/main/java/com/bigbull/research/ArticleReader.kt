package com.bigbull.research

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import java.net.HttpURLConnection
import java.net.URL

object ReaderPolicy {
    private val blocked=setOf("doubleclick.net","googlesyndication.com","googleadservices.com","googletagmanager.com","google-analytics.com","taboola.com","outbrain.com","adnxs.com","criteo.com","pubmatic.com","rubiconproject.com","amazon-adsystem.com","scorecardresearch.com","adsrvr.org","moatads.com","zedo.com","adsafeprotected.com")
    fun safe(url:String)=try{val u=java.net.URI(url);u.scheme=="https" && !u.host.isNullOrBlank() && u.rawUserInfo==null}catch(_:Exception){false}
    fun block(url:String)=try{val h=java.net.URI(url).host?.lowercase().orEmpty();blocked.any{h==it||h.endsWith(".$it")}}catch(_:Exception){true}
}
data class ReaderBlock(val text:String="",val image:String?=null,val heading:Boolean=false)
data class ReaderDocument(val title:String,val blocks:List<ReaderBlock>,val url:String)
object ReaderSource {
    fun bytes(url:String,cap:Int=5_000_000):ByteArray {
        var current=url
        repeat(6){
            require(ReaderPolicy.safe(current)&&!ReaderPolicy.block(current)){"Unsupported or blocked URL"}
            val c=(URL(current).openConnection() as HttpURLConnection).apply{instanceFollowRedirects=false;connectTimeout=10000;readTimeout=12000;setRequestProperty("User-Agent","Mozilla/5.0 (Android) Bigbull/1.1 PersonalReader");setRequestProperty("Accept","text/html,image/*;q=0.8,*/*;q=0.5")}
            try{val code=c.responseCode
                if(code in 300..399){current=URL(URL(current),c.getHeaderField("Location")?:error("Missing redirect")).toString()}
                else {require(code in 200..299){"Publisher returned HTTP $code"};return c.inputStream.use{val out=java.io.ByteArrayOutputStream();val buffer=ByteArray(8192);var total=0;while(true){val n=it.read(buffer);if(n<0)break;total+=n;require(total<=cap){"Article or image is too large"};out.write(buffer,0,n)};out.toByteArray()}}
            }finally{c.disconnect()}
        };error("Too many redirects")
    }
    fun parse(html:String,url:String):ReaderDocument {
        val doc=Jsoup.parse(html,url)
        require(!doc.select("script[type=application/ld+json]").any{Regex("\"isAccessibleForFree\"\\s*:\\s*(false|\"false\")",RegexOption.IGNORE_CASE).containsMatchIn(it.data())}){"Publisher subscription required. Open the publisher to continue."}
        val title=doc.selectFirst("meta[property=og:title]")?.attr("content")?.takeIf{it.isNotBlank()}?:doc.selectFirst("h1")?.text()?:doc.title()
        val hero=doc.selectFirst("meta[property=og:image]")?.absUrl("content")
        doc.select("script,style,nav,header,footer,aside,form,iframe,button,svg,[class*=advert],[class*=social],[class*=related],[id*=advert]").remove()
        val candidates=doc.select("article,[itemprop=articleBody],[class*=articleBody],[class*=article-body],[class*=storyBody],[class*=story-content],main")
        val body=(doc.selectFirst("[itemprop=articleBody]") ?: doc.selectFirst(".artText") ?: doc.selectFirst(".artData,.story_details,.story__content")) ?: candidates.maxByOrNull{it.select("p").sumOf{p->p.text().length}}?:doc.body()
        body.select("[class*=promo],[class*=banner],[class*=widget],[class*=newsletter],[class*=subscribe],[class*=audio],[class*=listen],[class*=ad-container],[class*=adslot],[id*=adslot],a:has(img)").remove()
        // ET publishes prose as inline nodes separated by <br>, without paragraph tags.
        // Normalize only that known article container, retaining inline links and real images.
        if(body.hasClass("artText")) body.html("<p>"+body.html().replace(Regex("<br\\s*/?>",RegexOption.IGNORE_CASE),"</p><p>")+"</p>")
        val blocks=mutableListOf<ReaderBlock>();val seen=mutableSetOf<String>()
        fun image(raw:String?){if(raw!=null&&ReaderPolicy.safe(raw)&&!ReaderPolicy.block(raw)&&seen.add(ReaderImages.identity(raw))&&seen.size<=8)blocks.add(ReaderBlock(image=raw))}
        image(hero)
        for(e in body.select("h2,h3,p,figure img,img,figcaption,li")){
            if(e.tagName()=="img"){
                val width=e.attr("width").toIntOrNull();val height=e.attr("height").toIntOrNull()
                if((width!=null&&width<100)||(height!=null&&height<60))continue
                val key=listOf("data-src","data-original","src").firstOrNull{e.attr(it).isNotBlank()&&!e.attr(it).startsWith("data:")}
                if(key!=null){val raw=e.absUrl(key);val context=e.attr("alt")+" "+raw
                    if(!Regex("banner|advert|promotion|workshop|wealth.*elite|spacer|tracking|logo|subscribe",RegexOption.IGNORE_CASE).containsMatchIn(context))image(raw)}
            }else{val t=e.text().trim();if(t.length>=25&&!Regex("^(listen to this article|read also|also read|subscribe|follow us|download.*app)",RegexOption.IGNORE_CASE).containsMatchIn(t)&&blocks.lastOrNull()?.text!=t)blocks.add(ReaderBlock(t,heading=e.tagName() in listOf("h2","h3")))}
        }
        require(blocks.sumOf{it.text.length}>200){"This publisher did not supply readable article text. Open the publisher or try another story."}
        return ReaderDocument(title,blocks.take(180),url)
    }
    fun load(url:String)=parse(bytes(url).toString(Charsets.UTF_8),url)
}
@Composable fun ArticleReader(app:AppState,article:Headline,loader:(String)->ReaderDocument=ReaderSource::load){
    var attempt by remember(article.url){mutableIntStateOf(0)};var document by remember(article.url){mutableStateOf<ReaderDocument?>(null)};var error by remember(article.url){mutableStateOf<String?>(null)}
    LaunchedEffect(article.url,attempt){document=null;error=null;try{document=withContext(Dispatchers.IO){loader(article.url)}}catch(e:Exception){error=e.message?:"The publisher could not be reached."}}
    val context=LocalContext.current
    Surface(color=MaterialTheme.colorScheme.background,contentColor=MaterialTheme.colorScheme.onSurface){Column(Modifier.fillMaxSize()){
        Surface(color=MaterialTheme.colorScheme.surface){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){TextButton(onClick={app.article=null}){Text("‹ News")};Text("Reader",Modifier.weight(1f),fontWeight=FontWeight.SemiBold);TextButton(onClick={try{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(article.url)))}catch(_:Exception){error="No browser available"}}){Text("Publisher ↗")}}}
        when {
            error!=null->Column(Modifier.padding(24.dp)){Text("Couldn't load this article",fontSize=23.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(12.dp));Text(error!!);Spacer(Modifier.height(20.dp));Button(onClick={attempt++}){Text("Retry article")};Muted("Your news feed is still available. Publisher access restrictions are respected.")}
            document==null->Column(Modifier.padding(24.dp)){LinearProgressIndicator(Modifier.fillMaxWidth());Spacer(Modifier.height(20.dp));Text("Loading article…",fontSize=20.sp);Spacer(Modifier.height(12.dp));Text(article.title);Muted(article.source)}
            else->ReaderBody(document!!,article)
        }
    }}
}
@Composable fun ReaderBody(document:ReaderDocument,article:Headline){
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(22.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
        item{Text(article.source.uppercase(),fontSize=11.sp,letterSpacing=1.sp,color=MaterialTheme.colorScheme.primary);Spacer(Modifier.height(10.dp));Text(document.title,fontSize=27.sp,lineHeight=33.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));Muted(article.published);Muted("Reader · article text and images")}
        items(document.blocks){b->if(b.image!=null)ReaderImage(b.image) else Text(b.text,fontSize=if(b.heading)21.sp else 18.sp,lineHeight=if(b.heading)28.sp else 29.sp,fontFamily=if(b.heading)FontFamily.SansSerif else FontFamily.Serif,fontWeight=if(b.heading)FontWeight.SemiBold else FontWeight.Normal)}
        item{HorizontalDivider();Muted("Source: ${Uri.parse(document.url).host} · personal reading view")}
    }
}
@Composable fun ReaderImage(url:String){
    val bitmap by produceState<Bitmap?>(null,url){value=withContext(Dispatchers.IO){try{val raw=ReaderSource.bytes(url,4_000_000);val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(raw,0,raw.size,bounds);var sample=1;while(bounds.outWidth/sample>1600||bounds.outHeight/sample>1600)sample*=2;BitmapFactory.decodeByteArray(raw,0,raw.size,BitmapFactory.Options().apply{inSampleSize=sample})}catch(_:Exception){null}}}
    if(bitmap!=null)Image(bitmap!!.asImageBitmap(),"Publisher article image",Modifier.fillMaxWidth().heightIn(max=340.dp),contentScale=ContentScale.Fit) else Muted("Publisher image loading or unavailable")
}
