package com.bigbull.research
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
object CompanyLogos {
    private val images=object:LruCache<String,Bitmap>(2_000_000){override fun sizeOf(k:String,v:Bitmap)=v.byteCount}
    private val failed=java.util.concurrent.ConcurrentHashMap<String,Long>();private val gate=Semaphore(4)
    fun url(s:Instrument):String? {if(!s.symbol.matches(Regex("[A-Z0-9&._-]{1,30}")))return null;val symbol=java.net.URLEncoder.encode(s.symbol,"UTF-8");return if(s.exchange=="BSE"&&(s.symbol.matches(Regex("[0-9]{6}"))||BseCatalog.code(s)!=null))"https://assets-netstorage.groww.in/stock-assets/logos/GSTK${BseCatalog.code(s)?:symbol}.png" else "https://assets-netstorage.groww.in/stock-assets/logos2/$symbol.png"}
    suspend fun get(s:Instrument):Bitmap?=withContext(Dispatchers.IO){
        images.get(s.id)?.let{return@withContext it};if(System.currentTimeMillis()-(failed[s.id]?:0)<3_600_000)return@withContext null
        gate.withPermit{try{val bytes=ReaderSource.bytes(url(s)?:return@withPermit null,500_000);val b=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(bytes,0,bytes.size,b);var sample=1;while(b.outWidth/sample>160||b.outHeight/sample>160)sample*=2
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,BitmapFactory.Options().apply{inSampleSize=sample})?.also{images.put(s.id,it)}
        }catch(_:Exception){failed[s.id]=System.currentTimeMillis();null}}
    }
}
@Composable fun CompanyLogo(stock:Instrument,size:Dp=34.dp){
    val bitmap by produceState<Bitmap?>(null,stock.id){value=CompanyLogos.get(stock)}
    Box(Modifier.size(size).clip(RoundedCornerShape(9.dp)).background(if(bitmap!=null)Color.White else MaterialTheme.colorScheme.surfaceVariant),contentAlignment=Alignment.Center){
        if(bitmap!=null)Image(bitmap!!.asImageBitmap(),"${stock.name.ifBlank{stock.symbol}} logo",Modifier.fillMaxSize().padding(4.dp),contentScale=ContentScale.Fit)
        else Text(stock.symbol.filter{it.isLetterOrDigit()}.take(2),fontSize=(size.value*.32f).sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
