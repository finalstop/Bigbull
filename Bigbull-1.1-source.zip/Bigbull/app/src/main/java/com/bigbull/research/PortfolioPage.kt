package com.bigbull.research

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import java.math.BigDecimal
import java.time.LocalDate

private fun csvField(s:String)="\""+s.replace("\"","\"\"")+"\""
private fun exportTrades(trades:List<Trade>):String = buildString {
    append("date,exchange,symbol,name,type,quantity,price_or_dividend,fees\n")
    trades.forEach { t -> append(listOf(t.date.toString(),t.instrument.exchange,t.instrument.symbol,t.instrument.name,t.type.name,t.quantity.toPlainString(),t.price.toPlainString(),t.fees.toPlainString()).joinToString(","){csvField(it)}).append('\n') }
}
@Composable fun PortfolioPage(app:AppState) {
    var add by remember { mutableStateOf(false) }; val context=LocalContext.current
    val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if(uri!=null) try { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(exportTrades(app.trades))} ?: error("Could not open the destination."); app.message="Transactions exported." } catch(e:Exception){app.message=e.message ?: "Export failed."}
    }
    val positions=try { PortfolioMath.positions(app.trades) } catch(_:Exception) { emptyList() }
    val openPositions=positions.filter{it.quantity.signum()>0}
    val priced=openPositions.mapNotNull { p -> app.series(p.instrument)?.candles?.lastOrNull()?.let { p to it } }
    val allPriced=priced.size==openPositions.size; val value=priced.sumOf { (p,c)->p.quantity.toDouble()*c.close }; val cost=openPositions.sumOf{it.cost.toDouble()}
    val realized=positions.sumOf{it.realized.toDouble()}; val dividends=positions.sumOf{it.dividends.toDouble()}
    val dates=priced.map{it.second.time.take(10)}.distinct()
    val valuationDate=when { openPositions.isEmpty() -> app.trades.maxOfOrNull{it.date}; allPriced && dates.size==1 -> try { LocalDate.parse(dates.single()) } catch(_:Exception){null}; else -> null }
    val xirr=if(valuationDate!=null && app.trades.none{it.date>valuationDate}) {
        val flows=app.trades.map { t -> val cash=when(t.type) { TradeType.BUY -> -(t.quantity*t.price+t.fees).toDouble(); TradeType.SELL -> (t.quantity*t.price-t.fees).toDouble(); TradeType.DIVIDEND -> (t.price-t.fees).toDouble() }; PortfolioMath.CashFlow(t.date,cash) }.toMutableList()
        if(openPositions.isNotEmpty()) flows.add(PortfolioMath.CashFlow(valuationDate,value)); PortfolioMath.xirr(flows)
    } else null
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).glassClearance().padding(horizontal=20.dp,vertical=22.dp)) {
        PageHeader("Portfolio","A private, on-device ledger",action={ TextButton(onClick={add=true}){Text("+ Entry")} })
        Panel(Modifier.fillMaxWidth()) {
            Kicker(if(allPriced) "HOLDINGS VALUE" else "PRICED HOLDINGS VALUE")
            Spacer(Modifier.height(8.dp)); Text(if(app.trades.isEmpty()) "—" else money(value),style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp)); Muted(if(openPositions.isEmpty()) "No open positions." else if(allPriced) "${priced.size} of ${openPositions.size} positions priced · Latest available closes" else "${openPositions.size-priced.size} position(s) have no loaded daily price; total value is incomplete.")
            Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Column { Muted("Open cost"); Text(money(cost),fontWeight=FontWeight.SemiBold) }
                Column(horizontalAlignment=Alignment.End) { Muted("Unrealized P&L"); Text(if(allPriced) money(value-cost) else "Unavailable",fontWeight=FontWeight.SemiBold) }
            }
            Spacer(Modifier.height(14.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                Column { Muted("Realized P&L"); Text(money(realized),fontWeight=FontWeight.SemiBold) }
                Column(horizontalAlignment=Alignment.End) { Muted("Dividends"); Text(money(dividends),fontWeight=FontWeight.SemiBold) }
            }
            Spacer(Modifier.height(14.dp)); Muted(if(xirr!=null) "XIRR ${relative(xirr*100)} annualized · as of $valuationDate" else "XIRR unavailable until cash flows and comparable dated prices support it.")
        }
        Spacer(Modifier.height(20.dp)); SectionTitle("Holdings")
        Spacer(Modifier.height(8.dp))
        if(openPositions.isEmpty()) EmptyPanel("No holdings yet","Add a buy transaction to start tracking your portfolio.") else Panel {
            openPositions.forEach { p ->
                val last=app.series(p.instrument)?.candles?.lastOrNull(); Row(Modifier.fillMaxWidth().clickable { app.selected=p.instrument;app.interval="1day" }.padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("${p.instrument.symbol} · ${p.instrument.exchange}",fontWeight=FontWeight.SemiBold);Muted("${p.quantity.stripTrailingZeros().toPlainString()} shares · avg ${money(p.avgCost.toDouble())}") }
                    Column(horizontalAlignment=Alignment.End){Text(last?.let{money(p.quantity.toDouble()*it.close)}?:"—",fontWeight=FontWeight.SemiBold);Muted(last?.let{"Close ${it.time.take(10)}"}?:"No price")}
                }
            }
        }
        Spacer(Modifier.height(20.dp)); SectionTitle("Transactions") { if(app.trades.isNotEmpty()) TextButton(onClick={export.launch("bigbull-transactions.csv")}) {Text("Export CSV")} }
        Spacer(Modifier.height(8.dp)); if(app.trades.isEmpty()) EmptyPanel("No entries","Buys, sells and dividends are entered manually and stored on this device.") else Panel {
            app.trades.asReversed().forEach { t -> Row(Modifier.fillMaxWidth().padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {Text("${t.type.name} · ${t.instrument.symbol}",fontWeight=FontWeight.SemiBold);Muted("${t.date} · ${if(t.type==TradeType.DIVIDEND) money(t.price.toDouble()) else "${t.quantity.stripTrailingZeros().toPlainString()} × ${money(t.price.toDouble())}"} · fees ${money(t.fees.toDouble())}")}
                TextButton(onClick={app.deleteTrade(t.id)}){Text("Delete",style=MaterialTheme.typography.labelSmall)}
            } }
        }
        Spacer(Modifier.height(20.dp)); Muted("Cost basis uses weighted average purchase cost including buy fees. Sells include sale fees. Corporate actions, taxes and brokerage are not applied automatically; enter accurate transactions and fees. XIRR is withheld for mixed price dates or ambiguous cash flows.")
    }
    if(add) TradeDialog(app,onDismiss={add=false})
}
@Composable fun TradeDialog(app:AppState,onDismiss:()->Unit) {
    var symbol by remember { mutableStateOf(app.stocks.firstOrNull()?.symbol ?: "") }; var exchange by remember { mutableStateOf(app.stocks.firstOrNull()?.exchange ?: "NSE") }
    var type by remember { mutableStateOf(TradeType.BUY) }; var date by remember { mutableStateOf(LocalDate.now().toString()) }; var quantity by remember { mutableStateOf("") }; var price by remember { mutableStateOf("") }; var fees by remember { mutableStateOf("0") }; var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("New transaction")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { TradeType.entries.forEach { t->SmallChip(t.name.lowercase().replaceFirstChar{it.uppercase()},type==t){type=t} } }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("NSE","BSE").forEach { e->SmallChip(e,exchange==e){exchange=e} } }
        OutlinedTextField(symbol,{symbol=it.uppercase().trim()},label={Text("Symbol")},singleLine=true)
        OutlinedTextField(date,{date=it},label={Text("Date (YYYY-MM-DD)")},singleLine=true)
        if(type!=TradeType.DIVIDEND) OutlinedTextField(quantity,{quantity=it},label={Text("Quantity")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        OutlinedTextField(price,{price=it},label={Text(if(type==TradeType.DIVIDEND) "Total dividend received (₹)" else "Price per share (₹)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        OutlinedTextField(fees,{fees=it},label={Text("Fees (₹)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        if(error.isNotEmpty()) Text(error,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)
    }},confirmButton={TextButton(onClick={ try {
        require(symbol.matches(Regex("[A-Z0-9&._-]{1,30}"))) { "Enter a valid symbol." }
        val d=LocalDate.parse(date); require(!d.isAfter(LocalDate.now())) { "Date cannot be in the future." }
        val stock=app.stocks.firstOrNull { it.symbol==symbol && it.exchange==exchange } ?: Instrument(symbol,exchange)
        val t=Trade(instrument=stock,type=type,date=d,quantity=if(type==TradeType.DIVIDEND) BigDecimal.ZERO else BigDecimal(quantity),price=BigDecimal(price),fees=BigDecimal(fees))
        PortfolioMath.positions(app.trades+t.copy(id=(app.trades.maxOfOrNull{it.id}?:0)+1)); app.addTrade(t); onDismiss()
    } catch(e:Exception) { error=e.message ?: "Check the values." } }) {Text("Save")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}
