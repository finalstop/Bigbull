package com.bigbull.research
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.json.JSONObject

object PeerUniverse {
    private val groups=listOf(listOf("INFY","TCS","HCLTECH","WIPRO"),listOf("SWIGGY","ETERNAL"),listOf("HDFCBANK","ICICIBANK","AXISBANK","KOTAKBANK"),listOf("RELIANCE","ONGC","BPCL","IOC"),listOf("TATAMOTORS","M&M","MARUTI"),listOf("BHARTIARTL","IDEA"),listOf("SUNPHARMA","CIPLA","DRREDDY"))
    fun peers(stock:Instrument)=if(stock.exchange!="NSE")emptyList() else groups.firstOrNull{stock.symbol in it}.orEmpty().filter{it!=stock.symbol}.take(3).map{Instrument(it,"NSE")}
}
object PeerFacts {
    fun report(app:AppState,s:Instrument,e:String)=app.report(s,e,"annual")?.second?.let{JSONObject(it)}
    fun first(j:JSONObject?,e:String)=j?.optJSONArray(e)?.optJSONObject(0)
    fun number(j:JSONObject?,k:String)=j?.optString(k)?.toDoubleOrNull()?.takeIf{it.isFinite()}
    fun margin(i:JSONObject?):Double?{val n=number(i,"net_income");val revenue=number(i,"sales");return if(n!=null&&revenue!=null&&revenue>0)n/revenue*100 else null}
    fun debtEquity(b:JSONObject?):Double?{val debt=number(b,"total_debt");val equity=number(b,"stockholders_equity");return if(debt!=null&&equity!=null&&equity>0)debt/equity else null}
}
@Composable fun PeerPage(app:AppState,stock:Instrument){
    val group=remember(stock.id){listOf(stock)+PeerUniverse.peers(stock)}
    var custom by remember(stock.id){mutableStateOf<Instrument?>(null)}
    val members=(group+listOfNotNull(custom)).distinctBy{it.id}
    LaunchedEffect(members.map{it.id}){members.forEach{if(app.report(it,"income_statement","annual")==null)app.loadPeer(it)else if(app.quotes[it.id]==null)app.loadQuote(it)}}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){
        SectionTitle("Peers & comparison"){TextButton(onClick={members.forEach{app.loadPeer(it)}}){Text("Refresh")}}
        Muted("Curated business groups, not algorithmic peer rankings. Reliance's energy comparators cover only part of its diversified business. Fiscal dates and currencies can differ.")
        Spacer(Modifier.height(14.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){app.stocks.filter{it.id!=stock.id}.take(10).forEach{s->SmallChip("+ "+s.symbol,custom?.id==s.id){custom=s}}}
        if(group.size==1)Muted("No curated group for this symbol. Add a company from your watchlist above.")
        Spacer(Modifier.height(18.dp))
        Row(Modifier.horizontalScroll(rememberScrollState())){
            Column{
                Row{Text("Annual metrics",Modifier.width(130.dp).padding(10.dp),fontWeight=FontWeight.SemiBold);members.forEach{s->Column(Modifier.width(140.dp).padding(10.dp)){Text(s.symbol,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);val i=PeerFacts.first(PeerFacts.report(app,s,"income_statement"),"income_statement");Muted(i?.optString("fiscal_date")?:"Loading / unavailable")}}}
                val labels=listOf("Quote (INR)","Quote timestamp","Revenue growth YoY","Net margin","Debt / equity","P/E · annual","P/B","Report currency")
                labels.forEachIndexed{index,label->HorizontalDivider();Row{Text(label,Modifier.width(130.dp).padding(10.dp),fontSize=13.sp);members.forEach{s->val inc=PeerFacts.report(app,s,"income_statement");val i=PeerFacts.first(inc,"income_statement");val b=PeerFacts.first(PeerFacts.report(app,s,"balance_sheet"),"balance_sheet");val q=app.quotes[s.id]
                    val value=when(index){0->q?.let{money(it.price)};1->q?.let{MarketTime.quoteLabel(it.asOf)};2->inc?.let{FinancialViewData.growth(FinancialViewData.points(it,"income_statement","sales"))}?.let{relative(it)};3->PeerFacts.margin(i)?.let{num(it)+"%"};4->PeerFacts.debtEquity(b)?.let{num(it)+"×"};5->ValuationFacts.from(app,s).pe?.let{num(it)+"×"};6->ValuationFacts.from(app,s).pb?.let{num(it)+"×"};else->inc?.optJSONObject("meta")?.optString("currency")}
                    Text(value?:"—",Modifier.width(140.dp).padding(10.dp),fontSize=13.sp)
                }}}
            }
        }
        Spacer(Modifier.height(16.dp));members.forEach{s->app.peerErrors[s.id]?.let{Muted(s.symbol+": "+it)}}
        Muted("— means missing or invalid inputs. Growth uses matching fiscal periods. Ratios are not valuation recommendations; debt/equity is not a sufficient banking metric. Source: Yahoo Finance public timeseries and quotes.")
    }
}
object CheckpointFacts {
    fun stamp(value:String)=runCatching{java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy, h:mm a",java.util.Locale.ENGLISH).withZone(java.time.ZoneId.of("Asia/Kolkata")).format(java.time.Instant.parse(value))+" IST"}.getOrDefault(value)
    fun display(j:JSONObject,key:String):String {
        if(j.isNull(key))return "Unavailable"
        val value=j.opt(key)
        if(key=="quote" && value is Number)return money(value.toDouble())
        if(key=="quoteTime")return stamp(j.optString(key))
        if(key in listOf("revenue","netIncome") && value is Number){val currency=j.optString("currency");return if(currency=="INR")"₹"+num(value.toDouble()/10_000_000,2)+" crore" else num(value.toDouble()/1_000_000,2)+" "+currency+" million"}
        return value?.toString()?:"Unavailable"
    }
    fun capture(app:AppState,s:Instrument):JSONObject {
        val income=PeerFacts.report(app,s,"income_statement");val row=PeerFacts.first(income,"income_statement")
        return JSONObject().put("captured",java.time.Instant.now().toString()).put("quote",app.quotes[s.id]?.price?:JSONObject.NULL).put("quoteTime",app.quotes[s.id]?.asOf?:JSONObject.NULL).put("fiscalDate",row?.optString("fiscal_date")?:JSONObject.NULL).put("currency",income?.optJSONObject("meta")?.optString("currency")?:JSONObject.NULL).put("revenue",PeerFacts.number(row,"sales")?:JSONObject.NULL).put("netIncome",PeerFacts.number(row,"net_income")?:JSONObject.NULL)
    }
    fun changes(before:JSONObject,after:JSONObject)=listOf("quote","quoteTime","fiscalDate","currency","revenue","netIncome").filter{key->val a=before.opt(key);val b=after.opt(key);if(a is Number && b is Number)runCatching{java.math.BigDecimal(a.toString()).compareTo(java.math.BigDecimal(b.toString()))!=0}.getOrDefault(true)else a?.toString()!=b?.toString()}
}
@Composable fun CheckpointPage(app:AppState,s:Instrument){
    var saved by remember(s.id){mutableStateOf(app.vault.checkpoint(s.id)?.let{runCatching{JSONObject(it)}.getOrNull()})}
    val current=CheckpointFacts.capture(app,s)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)){
        Text("Research Checkpoint",fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));Text("Know what changed before changing your mind.",fontSize=17.sp);Spacer(Modifier.height(10.dp));Muted("Save source facts, refresh later, and see exactly what changed. New financial reports stay separate from price movement.")
        Spacer(Modifier.height(18.dp));Button(onClick={app.vault.saveCheckpoint(s.id,current.toString());saved=JSONObject(current.toString())},enabled=!current.isNull("quote")||!current.isNull("revenue")){Text(if(saved==null)"Save research checkpoint" else "Replace checkpoint")}
        TextButton(onClick={app.loadPeer(s)}){Text("Refresh source facts")}
        val old=saved
        if(old==null)Muted("No checkpoint yet. Load the stock's quote or statements first.")else{
            Muted("Saved ${CheckpointFacts.stamp(old.optString("captured"))}")
            val changed=CheckpointFacts.changes(old,current)
            Spacer(Modifier.height(14.dp));Text(if(changed.isEmpty())"No source facts changed" else "${changed.size} source fields changed",fontWeight=FontWeight.SemiBold)
            for(k in listOf("quote","quoteTime","fiscalDate","currency","revenue","netIncome")){
                HorizontalDivider(Modifier.padding(vertical=12.dp));Text(k.replace(Regex("([a-z])([A-Z])"),"$1 $2").replaceFirstChar{it.uppercase()},fontWeight=FontWeight.Medium,color=if(k in changed)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                fun display(j:JSONObject)=CheckpointFacts.display(j,k)
                Text("Saved: ${display(old)}",fontSize=13.sp);Text("Now: ${display(current)}",fontSize=13.sp)
            }
            Spacer(Modifier.height(12.dp));Muted("Financial amounts retain their reporting currency. Missing values are never treated as zero. A changed fiscal period is a new report, not like-for-like growth. A changed quote timestamp alone does not mean price changed. Stored only on this device.")
        }
    }
}
