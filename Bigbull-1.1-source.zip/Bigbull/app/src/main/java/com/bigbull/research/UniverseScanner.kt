package com.bigbull.research
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.time.Instant

data class ScreenStock(val stock:Instrument,val rules:List<InvestorRule>,val date:String,val price:Double?,val extra:List<InvestorRule> = emptyList()){val qualifies get()=rules.isNotEmpty()&&rules.all{it.passed==true}&&extra.all{it.passed==true}}
class UniverseScanner(private val app:AppState,private val scope:CoroutineScope){
    var running by mutableStateOf(false);private set
    var progress by mutableStateOf("");private set
    var done by mutableIntStateOf(0);private set
    var total by mutableIntStateOf(0);private set
    var result by mutableStateOf<List<ScreenStock>>(emptyList());private set
    var universe by mutableStateOf<UniverseSnapshot?>(null);private set
    var rank by mutableStateOf<RelativeStrengthResult?>(null);private set
    var error by mutableStateOf<String?>(null);private set
    var method by mutableIntStateOf(0);private set
    var includesSepa by mutableStateOf(false);private set
    val failures=mutableStateMapOf<String,String>();private var job:Job?=null;private val api=FreeMarketData()
    private fun fresh(s:String)=runCatching{java.time.Duration.between(Instant.parse(s),Instant.now()).seconds in 0..21600}.getOrDefault(false)
    fun cancel(){job?.cancel();progress="Stopping; downloaded data is reusable."}
    private suspend fun constituents(spec:UniverseSpec):UniverseSnapshot{
        if(spec.id=="watchlist")return UniverseSnapshot(spec,app.stocks.toList(),Instant.now().toString(),"")
        if(spec.id in listOf("bse","bseonly"))return withContext(Dispatchers.IO){ScreenUniverses.load(spec)}
        val cache=if(app.cache)app.db.publicCache("universe:${spec.id}")else null
        if(cache!=null&&fresh(cache.first))return UniverseSnapshot(spec,ScreenUniverses.parse(cache.second),cache.first,ScreenUniverses.url(spec))
        val raw=withContext(Dispatchers.IO){ReaderSource.bytes(ScreenUniverses.url(spec)).toString(Charsets.UTF_8)};val now=Instant.now().toString();val members=ScreenUniverses.parse(raw);if(app.cache)app.db.savePublic("universe:${spec.id}",now,raw);return UniverseSnapshot(spec,members,now,ScreenUniverses.url(spec))
    }
    private suspend fun history(s:Instrument):List<Candle>{val saved=app.series(s);if(saved!=null&&saved.source!="User CSV"&&fresh(saved.fetchedAt)&&saved.candles.size>=220)return saved.candles;val series=withContext(Dispatchers.IO){api.candles(s,"1day","2y")};app.acceptSeries(series);return series.candles}
    private suspend fun report(s:Instrument,e:String,period:String="annual"){if(app.report(s,e,period)?.first?.let{fresh(it)}==true)return;app.acceptReport(s,e,period,withContext(Dispatchers.IO){api.report(s,e,period)})}
    fun browse(spec:UniverseSpec){if(running)return;running=true;job=scope.launch{try{universe=constituents(spec);progress="${universe!!.stocks.size} companies loaded"}catch(e:Exception){error=e.message}finally{running=false}}}
    fun run(spec:UniverseSpec,index:Int,sepa:Boolean=false){
        if(running)return;running=true;method=index;includesSepa=index==0&&sepa;result=emptyList();error=null;failures.clear();rank=null;done=0;total=0
        job=scope.launch{try{
            progress="Loading constituents…";val selected=constituents(spec);universe=selected;require(selected.stocks.isNotEmpty()){"Your watchlist is empty."}
            val benchmark=if(index==0)constituents(ScreenUniverses.options.first()).stocks else emptyList();val targets=(benchmark+selected.stocks).distinctBy{it.id};total=targets.size
            val gate=Semaphore(3);val histories=mutableMapOf<String,List<Candle>>();val historyFailures=mutableSetOf<String>();val benchmarkIds=benchmark.map{it.id}.toSet();val cards=mutableMapOf<String,ScreenStock>();val annuals=mutableMapOf<String,Pair<String,Double>>()
            val prices=if(index!=0)try{withContext(Dispatchers.IO){api.snapshot()}}catch(_:Exception){app.snapshot}else null;val priceMap=prices?.entries?.associateBy{it.symbol}.orEmpty()
            coroutineScope{targets.map{s->launch{gate.withPermit{
                ensureActive();var c=emptyList<Candle>();try{if(index==0||s.exchange!="NSE"||priceMap[s.symbol]==null){c=history(s);if(s.id in benchmarkIds)histories[s.id]=c}
                    if(index==0)c.lastOrNull()?.time?.take(10)?.let{d->RelativeStrength.annualReturn(c,java.time.LocalDate.parse(d))?.let{annuals[s.id]=d to it}}
                    if(index!=0)for(e in if(index==1)listOf("income_statement","balance_sheet","cash_flow")else listOf("income_statement","balance_sheet"))report(s,e)
                }catch(e:CancellationException){throw e}catch(e:Exception){failures[s.id]=e.message?:"Unavailable";if(index==0)historyFailures.add(s.id)}finally{done++;progress="$done / $total · ${s.symbol}"}
                val current=ValuationFacts.from(app,s);val p=if(s.exchange=="NSE")priceMap[s.symbol]else null;val facts=if(index!=0&&p!=null)current.copy(price=p.close,priceDate=prices!!.date.toString())else current
                cards[s.id]=ScreenStock(s,InvestorScreens.evaluate(index,facts,c),if(index==0)c.lastOrNull()?.time.orEmpty()else "Price ${facts.priceDate} · reports ${facts.date(facts.i)}",if(index==0)c.lastOrNull()?.close else facts.price);delay(100)
            }}}.joinAll()}
            val ranked=if(index==0)withContext(Dispatchers.Default){RelativeStrength.rank(benchmark,histories,benchmark.count{it.id in historyFailures})}else null;rank=ranked
            val benchmarkReturns=ranked?.session?.let{d->benchmark.mapNotNull{histories[it.id]?.let{c->RelativeStrength.annualReturn(c,java.time.LocalDate.parse(d))}}}.orEmpty()
            val base=selected.stocks.map{s->val card=cards[s.id]?:ScreenStock(s,InvestorScreens.evaluate(index,ValuationFacts(null,"",null,null,null),emptyList()),"",null)
                if(index!=0)card else {val rs=if(ranked?.usable==true)annuals[s.id]?.takeIf{it.first==ranked.session}?.second?.let{RelativeStrength.percentile(it,benchmarkReturns)}else null
                    card.copy(rules=card.rules.mapIndexed{i,r->if(i==7)r.copy(passed=rs?.let{it>=70},reading=rs?.let{num(it,1)+" / 100"}?:"Awaiting benchmark · not RSI")else r})}
            }
            if(index==0&&sepa){val candidates=base.filter{it.qualifies};done=0;total=candidates.size;val extra=mutableMapOf<String,List<InvestorRule>>()
                coroutineScope{candidates.map{x->launch{gate.withPermit{try{report(x.stock,"income_statement","quarterly");report(x.stock,"income_statement");report(x.stock,"balance_sheet");extra[x.stock.id]=SepaFilters.evaluate(app.report(x.stock,"income_statement","quarterly")?.second?.let{JSONObject(it)},ValuationFacts.from(app,x.stock))}catch(e:CancellationException){throw e}catch(e:Exception){failures[x.stock.id]=e.message?:"Quarterly data unavailable";extra[x.stock.id]=SepaFilters.evaluate(null,ValuationFacts.from(app,x.stock))}finally{done++;progress="Fundamentals $done / $total"}}}}.joinAll()}
                result=base.map{if(it.qualifies)it.copy(extra=extra[it.stock.id].orEmpty())else it}
            }else result=base
            progress="Complete · ${result.count{it.qualifies}} matches / ${selected.stocks.size} companies";if(index==0&&ranked?.usable!=true)error="Insufficient RS benchmark coverage. No eight-rule matches can be verified. Retry."
        }catch(e:CancellationException){progress="Stopped. Downloaded data is reusable."}catch(e:Exception){error=e.message?:"Scan failed"}finally{running=false}}
    }
}
object SepaFilters {
    fun evaluate(q:JSONObject?,v:ValuationFacts):List<InvestorRule>{val rows=v.rows(q,"income_statement");val latest=rows.firstOrNull();val prev=rows.firstOrNull{ValuationFacts.yearApart(v.date(it),v.date(latest))}
        fun growth(k:String):Double?{val a=v.number(latest,k);val b=v.number(prev,k);return if(a!=null&&b!=null&&b>0)(a/b-1)*100 else null}
        fun rule(t:String,f:String,n:Double?,p:(Double)->Boolean)=InvestorRule(t,f,n?.let(p),n?.let{num(it)+"%"}?:"Unavailable")
        val m=PeerFacts.margin(latest);val old=PeerFacts.margin(prev)
        return listOf(rule("Quarterly EPS growth","Diluted EPS YoY ≥25%",growth("diluted_eps")){it>=25},rule("Quarterly revenue growth","Revenue YoY ≥20%",growth("sales")){it>=20},rule("Margin expansion","Net margin minus year-ago margin >0 percentage points",if(m!=null&&old!=null)m-old else null){it>0},rule("Return on equity","Annual net income / average equity ≥17%",v.roe){it>=17})
    }
}
