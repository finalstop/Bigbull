package com.bigbull.research

import java.math.BigDecimal
import java.math.MathContext
import java.time.LocalDate
import java.time.LocalDateTime
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

data class Instrument(val symbol: String, val exchange: String, val name: String = "") {
    val id: String get() = "$exchange:$symbol"
}
data class Candle(val time: String, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double) {
    fun validate() {
        require(open.isFinite() && high.isFinite() && low.isFinite() && close.isFinite() && volume.isFinite()) { "Non-finite number at $time" }
        require(open > 0 && high > 0 && low > 0 && close > 0 && volume >= 0) { "Invalid price or volume at $time" }
        require(high >= maxOf(open, close, low) && low <= minOf(open, close, high)) { "Inconsistent high/low at $time" }
        val timestamp = time.replace('T', ' ')
        if (timestamp.length == 10) LocalDate.parse(timestamp) else LocalDateTime.parse(timestamp.replace(' ', 'T'))
    }
}
data class Series(val stock: Instrument, val interval: String, val candles: List<Candle>, val source: String, val fetchedAt: String, val persisted: Boolean)

object CsvCandles {
    // Parses quoted RFC-4180 fields, including commas, quotes, CRLF and newlines.
    fun rows(input: String): List<List<String>> {
        val out = mutableListOf<List<String>>(); var row = mutableListOf<String>(); val field = StringBuilder()
        var quoted = false; var i = 0; var afterQuote = false
        fun endField() { row.add(field.toString()); field.setLength(0); afterQuote = false }
        fun endRow() { endField(); if (row.any { it.isNotBlank() }) out.add(row); row = mutableListOf() }
        while (i < input.length) {
            val c = input[i]
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < input.length && input[i + 1] == '"') { field.append('"'); i++ }
                    else { quoted = false; afterQuote = true }
                } else field.append(c)
            } else when (c) {
                '"' -> { require(field.isEmpty() && !afterQuote) { "Unexpected quote in CSV" }; quoted = true }
                ',' -> endField()
                '\n' -> endRow()
                '\r' -> { if (i + 1 < input.length && input[i + 1] == '\n') i++; endRow() }
                else -> { require(!afterQuote || c.isWhitespace()) { "Unexpected text after quoted field" }; if (!afterQuote) field.append(c) }
            }
            i++
        }
        require(!quoted) { "Unclosed quoted CSV field" }
        if (field.isNotEmpty() || row.isNotEmpty()) endRow()
        return out
    }
    fun parse(input: String): List<Candle> {
        require(input.length <= 5_000_000) { "CSV is too large (maximum 5 MB)." }
        val rows = rows(input.removePrefix("\uFEFF"))
        require(rows.size >= 2) { "CSV must have a header and at least one candle." }
        val headers = rows[0].map { it.trim().lowercase() }
        require(headers.distinct().size == headers.size) { "Duplicate column names." }
        fun index(vararg names: String): Int = headers.indexOfFirst { it in names }.also { require(it >= 0) { "Missing column: ${names[0]}" } }
        val date = index("date", "datetime", "timestamp"); val o = index("open"); val h = index("high"); val l = index("low"); val c = index("close"); val v = index("volume")
        val result = rows.drop(1).mapIndexed { i, r ->
            require(r.size == headers.size) { "Row ${i + 2}: wrong number of columns." }
            fun number(n: Int): Double = r[n].trim().toDoubleOrNull() ?: throw IllegalArgumentException("Row ${i + 2}: invalid number in ${headers[n]}.")
            Candle(r[date].trim().replace('T', ' '), number(o), number(h), number(l), number(c), number(v)).also { it.validate() }
        }.sortedBy { it.time }
        require(result.map { it.time }.distinct().size == result.size) { "Duplicate timestamps are not allowed." }
        return result
    }
}

object Indicators {
    data class Pivots(val pivot: Double, val resistance1: Double, val support1: Double)
    fun classicPivots(previous: Candle): Pivots {
        val p=(previous.high+previous.low+previous.close)/3.0
        return Pivots(p,2*p-previous.low,2*p-previous.high)
    }
    fun highLow52Weeks(c: List<Candle>): Pair<Double,Double>? {
        if(c.isEmpty()) return null
        val cutoff=LocalDate.parse(c.last().time.take(10)).minusWeeks(52)
        if(LocalDate.parse(c.first().time.take(10)) > cutoff) return null
        val window=c.filter{ LocalDate.parse(it.time.take(10)) >= cutoff }
        return window.maxOf { it.high } to window.minOf { it.low }
    }
    fun sma(x: List<Double>, p: Int): List<Double?> {
        require(p > 0); var sum = 0.0
        return x.indices.map { i -> sum += x[i]; if (i >= p) sum -= x[i-p]; if (i >= p-1) sum/p else null }
    }
    fun ema(x: List<Double>, p: Int): List<Double?> {
        require(p > 0); val out = MutableList<Double?>(x.size) { null }; if (x.size < p) return out
        var e = x.take(p).average(); out[p-1] = e; val a = 2.0/(p+1)
        for (i in p until x.size) { e = a*x[i] + (1-a)*e; out[i] = e }
        return out
    }
    fun rsi(x: List<Double>, p: Int = 14): List<Double?> {
        require(p > 0); val out = MutableList<Double?>(x.size) { null }; if (x.size <= p) return out
        var gain = 0.0; var loss = 0.0
        for (i in 1..p) { val d = x[i]-x[i-1]; if (d > 0) gain += d else loss -= d }
        gain /= p; loss /= p
        fun value(): Double = if (loss == 0.0) { if (gain == 0.0) 50.0 else 100.0 } else 100.0 - 100.0/(1+gain/loss)
        out[p] = value()
        for (i in p+1 until x.size) { val d=x[i]-x[i-1]; gain=(gain*(p-1)+maxOf(d,0.0))/p; loss=(loss*(p-1)+maxOf(-d,0.0))/p; out[i]=value() }
        return out
    }
    data class Bands(val middle: Double, val upper: Double, val lower: Double)
    fun bands(x: List<Double>, p: Int = 20): List<Bands?> = x.indices.map { i ->
        if (i < p-1) null else { val w=x.subList(i-p+1, i+1); val m=w.average(); val sd=sqrt(w.sumOf { (it-m)*(it-m) }/p); Bands(m,m+2*sd,m-2*sd) }
    }
    data class Macd(val line: Double?, val signal: Double?, val histogram: Double?)
    fun macd(x: List<Double>): List<Macd> {
        val fast=ema(x,12); val slow=ema(x,26); val diffs=x.indices.map { i -> if (fast[i] != null && slow[i] != null) fast[i]!!-slow[i]!! else null }
        val valid=diffs.filterNotNull(); val sig=ema(valid,9); val offset=diffs.indexOfFirst { it != null }
        return x.indices.map { i -> val s=if(offset >= 0 && i>=offset) sig[i-offset] else null; Macd(diffs[i],s,if(diffs[i]!=null && s!=null) diffs[i]!!-s else null) }
    }
    fun atr(c: List<Candle>, p: Int = 14): List<Double?> {
        require(p > 0); val out=MutableList<Double?>(c.size) { null }; if(c.size < p) return out
        val tr=c.indices.map { i -> if(i==0) c[i].high-c[i].low else maxOf(c[i].high-c[i].low,abs(c[i].high-c[i-1].close),abs(c[i].low-c[i-1].close)) }
        var a=tr.take(p).average(); out[p-1]=a
        for(i in p until c.size) { a=(a*(p-1)+tr[i])/p; out[i]=a }; return out
    }
    fun obv(c: List<Candle>): List<Double> {
        var value=0.0; return c.indices.map { i -> if(i>0) value += when { c[i].close > c[i-1].close -> c[i].volume; c[i].close < c[i-1].close -> -c[i].volume; else -> 0.0 }; value }
    }
    fun mfi(c: List<Candle>, p: Int = 14): List<Double?> {
        val out=MutableList<Double?>(c.size){null}; if(c.size <= p) return out
        val typical=c.map{(it.high+it.low+it.close)/3}; for(i in p until c.size) {
            var pos=0.0; var neg=0.0; for(j in i-p+1..i) { val f=typical[j]*c[j].volume; if(typical[j]>typical[j-1]) pos+=f else if(typical[j]<typical[j-1]) neg+=f }
            out[i]=if(neg==0.0) { if(pos==0.0) 50.0 else 100.0 } else 100-100/(1+pos/neg)
        }; return out
    }
}

enum class TradeType { BUY, SELL, DIVIDEND }
data class Trade(val id: Long = 0, val instrument: Instrument, val type: TradeType, val date: LocalDate, val quantity: BigDecimal, val price: BigDecimal, val fees: BigDecimal)
data class Position(val instrument: Instrument, val quantity: BigDecimal, val cost: BigDecimal, val realized: BigDecimal, val dividends: BigDecimal) {
    val avgCost: BigDecimal get() = if (quantity.signum() == 0) BigDecimal.ZERO else cost.divide(quantity, MathContext.DECIMAL128)
}
object PortfolioMath {
    private val mc = MathContext.DECIMAL128
    fun positions(trades: List<Trade>): List<Position> = trades.groupBy { it.instrument.id }.values.map { ts ->
        val sorted = ts.sortedWith(compareBy<Trade> { it.date }.thenBy { it.id }); var qty=BigDecimal.ZERO; var cost=BigDecimal.ZERO; var realized=BigDecimal.ZERO; var dividends=BigDecimal.ZERO
        for(t in sorted) {
            require(t.fees.signum() >= 0 && t.price.signum() > 0) { "Amounts must be positive, and fees cannot be negative." }
            when(t.type) {
                TradeType.BUY -> { require(t.quantity.signum()>0); qty=qty.add(t.quantity); cost=cost.add(t.quantity.multiply(t.price).add(t.fees)) }
                TradeType.SELL -> { require(t.quantity.signum()>0 && qty >= t.quantity) { "A sale exceeds the shares held on ${t.date}." }; val part=if(t.quantity.compareTo(qty)==0) cost else cost.multiply(t.quantity,mc).divide(qty,mc); cost=cost.subtract(part,mc); qty=qty.subtract(t.quantity); realized=realized.add(t.quantity.multiply(t.price).subtract(t.fees).subtract(part),mc) }
                TradeType.DIVIDEND -> { require(t.quantity.signum()==0); require(t.price >= t.fees) { "Dividend fees cannot exceed the amount." }; dividends=dividends.add(t.price.subtract(t.fees)) }
            }
        }
        Position(sorted.last().instrument,qty,cost,realized,dividends)
    }
    data class CashFlow(val date: LocalDate, val amount: Double)
    fun xirr(flows: List<CashFlow>): Double? {
        val grouped=flows.groupBy { it.date }.map { (d, fs) -> CashFlow(d,fs.sumOf { it.amount }) }.filter { abs(it.amount)>1e-12 }.sortedBy{it.date}
        if(grouped.size<2 || grouped.first().date==grouped.last().date) return null
        if(grouped.zipWithNext().count{(a,b)-> a.amount*b.amount<0} != 1) return null // multiple roots can be ambiguous
        val start=grouped.first().date; fun npv(r: Double)=grouped.sumOf { it.amount/(1+r).pow(java.time.temporal.ChronoUnit.DAYS.between(start,it.date)/365.0) }
        var lo=-0.9999; var hi=1.0; var a=npv(lo); var b=npv(hi)
        while(a*b>0 && hi<1e6) { hi=hi*2+1; b=npv(hi) }; if(!a.isFinite() || !b.isFinite() || a*b>0) return null
        repeat(200) { val mid=(lo+hi)/2; val v=npv(mid); if(a*v<=0) { hi=mid; b=v } else { lo=mid; a=v } }
        return (lo+hi)/2
    }
}

object DcfCalculator {
    data class Result(val forecastPresentValue: Double, val terminalPresentValue: Double, val equityValue: Double, val perShare: Double)
    fun calculate(freeCashFlow: Double, growth: Double, discount: Double, terminalGrowth: Double, netDebt: Double, shares: Double): Result {
        require(listOf(freeCashFlow,growth,discount,terminalGrowth,netDebt,shares).all { it.isFinite() }) { "All inputs must be finite numbers." }
        require(shares>0) { "Diluted shares must be greater than zero." }
        require(growth > -1 && terminalGrowth > -1 && discount > -1) { "Rates must be greater than -100%." }
        require(discount>terminalGrowth) { "Discount rate must exceed terminal growth." }
        var fcf=freeCashFlow;var pv=0.0
        for(year in 1..5) { fcf *= 1+growth; pv += fcf/(1+discount).pow(year) }
        val terminal=fcf*(1+terminalGrowth)/(discount-terminalGrowth)/(1+discount).pow(5)
        val equity=pv+terminal-netDebt; val result=Result(pv,terminal,equity,equity/shares)
        require(listOf(result.forecastPresentValue,result.terminalPresentValue,result.equityValue,result.perShare).all{it.isFinite()}) { "These inputs exceed the calculator's range." }
        return result
    }
}
