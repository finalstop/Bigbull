package com.bigbull.research

import dev.chrisbanes.haze.haze
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.Crossfade
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import java.text.NumberFormat
import java.util.Locale

val Positive:Color @Composable get()=if(MaterialTheme.colorScheme.background.luminance()<.3f)Color(0xFF53BA8E) else Color(0xFF137552)
val Negative:Color @Composable get()=if(MaterialTheme.colorScheme.background.luminance()<.3f)Color(0xFFF0808C) else Color(0xFFB73145)
private val darkPalette=darkColorScheme(primary=Color(0xFFA8BFFF),onPrimary=Color(0xFF172547),background=Color(0xFF111315),onBackground=Color(0xFFF2F2F4),surface=Color(0xFF1B1E22),surfaceVariant=Color(0xFF262A30),onSurface=Color(0xFFF2F2F4),onSurfaceVariant=Color(0xFF989EA8),outline=Color(0xFF3B4048),secondary=Color(0xFFA8BFFF),error=Color(0xFFFF929A))
private val lightPalette=lightColorScheme(primary=Color(0xFF345EDB),onPrimary=Color.White,background=Color(0xFFF6F7F9),onBackground=Color(0xFF17191D),surface=Color.White,surfaceVariant=Color(0xFFEBEEF4),onSurface=Color(0xFF17191D),onSurfaceVariant=Color(0xFF69707C),outline=Color(0xFFD9DDE4),secondary=Color(0xFF345EDB),error=Color(0xFFBD3348))
private val editorialType=Typography(
    headlineLarge=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=30.sp,lineHeight=36.sp,fontWeight=FontWeight.SemiBold,letterSpacing=(-.7).sp),
    headlineMedium=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=26.sp,lineHeight=32.sp,fontWeight=FontWeight.SemiBold,letterSpacing=(-.5).sp),
    titleLarge=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=21.sp,lineHeight=28.sp,fontWeight=FontWeight.SemiBold),
    titleMedium=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=16.sp,lineHeight=22.sp,fontWeight=FontWeight.SemiBold),
    bodyLarge=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=16.sp,lineHeight=24.sp),
    bodyMedium=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=14.sp,lineHeight=21.sp),
    bodySmall=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=12.sp,lineHeight=18.sp),
    labelLarge=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=13.sp,lineHeight=18.sp,fontWeight=FontWeight.Medium),
    labelMedium=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=12.sp,lineHeight=16.sp,fontWeight=FontWeight.Medium),
    labelSmall=TextStyle(fontFamily=FontFamily.SansSerif,fontSize=10.sp,lineHeight=14.sp,fontWeight=FontWeight.Medium)
)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); enableEdgeToEdge(); setContent {
        val app=remember { AppState(applicationContext) }; DisposableEffect(Unit) { onDispose { app.dispose() } }
        BigbullTheme(app.dark) { BigbullApp(app) }
    } }
}
@Composable fun BigbullTheme(dark:Boolean,content: @Composable () -> Unit){
    val view=LocalView.current
    SideEffect{(view.context as? android.app.Activity)?.let{a->WindowInsetsControllerCompat(a.window,view).apply{isAppearanceLightStatusBars=!dark;isAppearanceLightNavigationBars=!dark}}}
    MaterialTheme(colorScheme=if(dark)darkPalette else lightPalette,typography=editorialType,content=content)
}
fun money(n: Double): String = "₹"+NumberFormat.getNumberInstance(Locale("en","IN")).apply{minimumFractionDigits=2; maximumFractionDigits=2}.format(n)
fun num(n: Double, digits: Int = 2): String = NumberFormat.getNumberInstance(Locale("en","IN")).apply{minimumFractionDigits=digits;maximumFractionDigits=digits}.format(n)
fun relative(n: Double): String = (if(n>=0) "+" else "")+num(n)+"%"

@Composable fun BigbullApp(app: AppState) {
    var page by remember { mutableIntStateOf(0) }; val snackbar=remember { SnackbarHostState() }; val selected=app.selected
    LaunchedEffect(app.message) { app.message?.let { snackbar.showSnackbar(it); app.message=null } }
    BackHandler(enabled=selected!=null || app.article!=null || app.annualDocument!=null) { if(app.annualDocument!=null)app.annualDocument=null else if(app.article!=null)app.article=null else app.selected=null }
    val haze=remember { dev.chrisbanes.haze.HazeState() }
    val showNav=selected==null && app.article==null && app.annualDocument==null
    Scaffold(containerColor=MaterialTheme.colorScheme.background,snackbarHost={ SnackbarHost(snackbar,Modifier.padding(bottom=if(showNav) 88.dp else 0.dp)) }) { padding ->
        Box(Modifier.padding(top=padding.calculateTopPadding()).fillMaxSize()) {
            CompositionLocalProvider(LocalGlassInset provides if(showNav) 88.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() else 0.dp) {
                Column(Modifier.fillMaxSize()){
                    if(showNav && page==0) BrandHeader(app)
                Box(Modifier.weight(1f).fillMaxWidth().then(if(showNav) Modifier.haze(haze) else Modifier).testTag("contentViewport")) {
                    if(app.annualDocument!=null) Box(Modifier.navigationBarsPadding()){AnnualPdfReader(app,app.annualDocument!!)} else if(app.article!=null) Box(Modifier.navigationBarsPadding()){ArticleReader(app,app.article!!)} else if(selected!=null) Box(Modifier.navigationBarsPadding()){StockPage(app,selected)} else Crossfade(targetState=page,label="Navigation"){destination->when(destination) {
                        0 -> TerminalHome(app)
                        1 -> WatchlistPage(app)
                        2 -> NewsPage(app)
                        3 -> PortfolioPage(app)
                        else -> SettingsPage(app)
                    }}
                    if(app.isLoading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
                }
                }
            }
            if(showNav) GlassNavigation(page,{page=it},haze,Modifier.align(Alignment.BottomCenter))
        }
    }
}

@Composable fun PageHeader(title:String,subtitle:String="",back:(()->Unit)?=null, action:@Composable (()->Unit)?=null) {
    Row(Modifier.fillMaxWidth().padding(bottom=20.dp),verticalAlignment=Alignment.CenterVertically) {
        if(back!=null) { Text("‹",Modifier.clickable { back() }.padding(end=14.dp),fontSize=32.sp,color=MaterialTheme.colorScheme.primary) }
        Column(Modifier.weight(1f)) {
            Text(title,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.SemiBold,letterSpacing=(-0.7).sp)
            if(subtitle.isNotBlank()) Text(subtitle,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
        }; if(action!=null) action()
    }
}
@Composable fun Kicker(text:String) { Text(text.uppercase(),style=MaterialTheme.typography.labelSmall,letterSpacing=1.6.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.secondary) }
@Composable fun Panel(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit) {
    Surface(modifier=modifier,shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.surface,border=BorderStroke(1.dp,MaterialTheme.colorScheme.outline.copy(alpha=.25f))) {
        Column(Modifier.animateContentSize().padding(18.dp),content=content)
    }
}
@Composable fun Muted(s:String,modifier:Modifier=Modifier) { Text(s,modifier,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant,lineHeight=18.sp) }
@Composable fun SectionTitle(title:String, trailing:@Composable (()->Unit)?=null) { Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Text(title,Modifier.weight(1f),style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.SemiBold); if(trailing!=null) trailing() } }
@Composable fun SmallChip(text:String,active:Boolean=false,onClick:()->Unit) { Surface(onClick=onClick,color=if(active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(8.dp)) { Text(text,Modifier.padding(horizontal=12.dp,vertical=8.dp),color=if(active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.labelMedium,fontWeight=FontWeight.SemiBold) } }
@Composable fun PrimaryButton(text:String,onClick:()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true) { Button(onClick=onClick,modifier=modifier,enabled=enabled,shape=RoundedCornerShape(12.dp),contentPadding=PaddingValues(horizontal=16.dp,vertical=10.dp)) { Text(text,fontWeight=FontWeight.SemiBold) } }
@Composable fun EmptyPanel(title:String,body:String) { Panel(Modifier.fillMaxWidth()) { Text(title,fontWeight=FontWeight.SemiBold); Spacer(Modifier.height(7.dp)); Muted(body) } }
@Composable fun StockRow(app:AppState,stock:Instrument,onClick:()->Unit) {
    val series=app.series(stock); val last=series?.candles?.lastOrNull(); val prev=series?.candles?.dropLast(1)?.lastOrNull(); val change=if(last!=null&&prev!=null&&prev.close!=0.0) (last.close/prev.close-1)*100 else null
    val quote=app.quotes[stock.id];val displayedChange=quote?.previousClose?.let{(quote.price/it-1)*100} ?: change
    Row(Modifier.fillMaxWidth().clickable(onClick=onClick).padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
        CompanyLogo(stock);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)) { Text(stock.symbol,fontWeight=FontWeight.SemiBold,fontSize=15.sp); Muted((if(stock.name.isNotBlank()) "${stock.exchange} · ${stock.name}" else stock.exchange),Modifier.padding(top=2.dp)) }
        if(quote!=null&&quote.bars.size>2){val bars=quote.bars.takeLast(40);val tone=if(bars.last().close>=bars.first().close)Positive else Negative;Canvas(Modifier.width(52.dp).height(25.dp).padding(end=10.dp)){val low=bars.minOf{it.close};val span=(bars.maxOf{it.close}-low).coerceAtLeast(.001);val path=androidx.compose.ui.graphics.Path();bars.forEachIndexed{i,b->val x=i.toFloat()/(bars.size-1)*size.width;val y=((1-(b.close-low)/span)*size.height).toFloat();if(i==0)path.moveTo(x,y)else path.lineTo(x,y)};drawPath(path,tone,style=Stroke(1.5.dp.toPx()))}}
        Column(horizontalAlignment=Alignment.End) { Text(quote?.let{money(it.price)} ?: last?.let{money(it.close)} ?: "—",fontWeight=FontWeight.SemiBold); if(displayedChange!=null) Text(relative(displayedChange),fontSize=12.sp,color=if(displayedChange>=0) Positive else Negative) else Muted(if(app.quoteErrors.containsKey(stock.id))"Quote unavailable" else "Loading quote…") }
    }
    HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.2f))
}
