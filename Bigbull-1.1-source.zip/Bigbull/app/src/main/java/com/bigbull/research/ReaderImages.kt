package com.bigbull.research
import java.net.URI
import java.net.URLDecoder
object ReaderImages {
    fun identity(url:String):String=runCatching {
        val u=URI(url);val h=u.host.lowercase();var p=u.path
        if(h=="indiatimes.com"||h.endsWith(".indiatimes.com")||h=="etimg.com"||h.endsWith(".etimg.com")) {
            Regex("(?:msid[-=/]|/(?:photo|thumb|photoimg|img|images)/)([0-9]{6,})").find(p)?.groupValues?.get(1)?.let{return "indiatimes:$it"}
        }
        p=p.replace(Regex("/alternates/[^/]+/"),"/alternates/").replace(Regex("/w[0-9]+(?:h[0-9]+)?/"),"/").replace(Regex("-[0-9]{2,4}x[0-9]{2,4}(?=\\.(?:jpg|jpeg|png|webp)$)",RegexOption.IGNORE_CASE),"")
        if(h.endsWith("indiatimes.com")||h.endsWith("etimg.com")) {
            Regex("(?:^|[,&?])msid[=,-]([0-9]{6,})").find(url)?.groupValues?.get(1)?.let{return "indiatimes:$it"}
            Regex("/([0-9]{6,})(?:[.,/]|$)").find(p)?.groupValues?.get(1)?.let{return "indiatimes:$it"}
        }
        val ignore=setOf("w","h","width","height","quality","q","resize","fit","crop","format","auto","dpr","imwidth","imheight")
        val q=u.rawQuery.orEmpty().split('&').filter{it.isNotBlank()&&URLDecoder.decode(it.substringBefore('='),"UTF-8").lowercase() !in ignore}.sorted().joinToString("&")
        h+p+if(q.isBlank())"" else "?$q"
    }.getOrDefault(url)
}
