package com.bigbull.research

import org.json.JSONObject
import java.time.*
import java.net.URLEncoder
import javax.xml.parsers.DocumentBuilderFactory
import org.xml.sax.InputSource
import java.io.StringReader

data class Headline(val title:String,val url:String,val published:String,val source:String)
data class NewsSource(val name:String,val url:String,val host:String)
data class NewsBatch(val items:List<Headline>,val errors:List<String>)
object NewsFeed {
    const val url="https://economictimes.indiatimes.com/markets/stocks/rssfeeds/2146842.cms"
    val sources=listOf(NewsSource("The Economic Times",url,"economictimes.indiatimes.com"),NewsSource("Mint","https://www.livemint.com/rss/markets","livemint.com"),NewsSource("India Today","https://www.indiatoday.in/rss/1206574","indiatoday.in"),NewsSource("NDTV.com / NDTV Profit","https://feeds.feedburner.com/ndtvprofit-latest","ndtvprofit.com"))
    fun parse(xml:String,source:NewsSource=sources.first()):List<Headline>{
        require(!xml.contains("<!DOCTYPE",true) && !xml.contains("<!ENTITY",true)){"Document declarations are not allowed in RSS."}
        val f=DocumentBuilderFactory.newInstance();f.isNamespaceAware=false;f.isExpandEntityReferences=false
        val items=f.newDocumentBuilder().parse(InputSource(StringReader(xml))).getElementsByTagName("item")
        return buildList {for(i in 0 until items.length){val e=items.item(i) as org.w3c.dom.Element
            fun field(k:String)=e.getElementsByTagName(k).item(0)?.textContent?.trim().orEmpty()
            val link=field("link");val uri=try{java.net.URI(link)}catch(_:Exception){null};val h=uri?.host.orEmpty()
            if(!Regex("sponsored|brandwire|brandpost",RegexOption.IGNORE_CASE).containsMatchIn(link) && ReaderPolicy.safe(link) && (h==source.host || h.endsWith("."+source.host)) && field("title").isNotBlank())add(Headline(field("title"),link,field("pubDate"),source.name))}}.distinctBy{it.url}.take(50)
    }
    fun loadAll():NewsBatch {
        val pool=java.util.concurrent.Executors.newFixedThreadPool(sources.size)
        try {
            val tasks=sources.map{source->java.util.concurrent.Callable{parse(if(source.host=="economictimes.indiatimes.com")PublicHttp.get(source.url)else ReaderSource.bytes(source.url).toString(Charsets.UTF_8),source)}}
            val futures=pool.invokeAll(tasks,25,java.util.concurrent.TimeUnit.SECONDS);val errors=mutableListOf<String>();val items=mutableListOf<Headline>()
            futures.forEachIndexed{i,f->try{val rows=f.get();if(rows.isEmpty())errors.add(sources[i].name+": empty feed")else items.addAll(rows)}catch(_:Exception){errors.add(sources[i].name+": unavailable")}}
            fun epoch(h:Headline)=try{ZonedDateTime.parse(h.published,java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME).toEpochSecond()}catch(_:Exception){try{Instant.parse(h.published).epochSecond}catch(_:Exception){0L}}
            require(items.isNotEmpty()){errors.joinToString(" · ")}
            return NewsBatch(items.distinctBy{it.url}.sortedByDescending{epoch(it)}.take(120),errors)
        }finally{pool.shutdownNow()}
    }
    fun load()=loadAll().items
}
data class MoodFactor(val name:String,val score:Double,val detail:String,val display:String?=null)
data class MoodReading(val date:String,val score:Double,val factors:List<MoodFactor>,val fetched:String,val source:String="Bigbull",val comparisons:List<Pair<String,Double>> = emptyList()){
    val zone get()=if(source=="Tickertape") when{score<30->"Extreme fear";score<50->"Fear";score<70->"Greed";else->"Extreme greed"} else MoodMath.zone(score)
}
object MoodMath {
    fun zone(score:Double)=when{score<25->"Extreme fear";score<45->"Fear";score<=55->"Neutral";score<=75->"Greed";else->"Extreme greed"}
    fun percentile(value:Double,history:List<Double>):Double {require(history.size>=120 && history.all{it.isFinite()} && value.isFinite());return (history.count{it<value}+history.count{it==value}*.5)/history.size*100}
    fun calculate(nifty:List<Candle>,vix:List<Candle>,snapshot:MarketSnapshot):MoodReading {
        val date=snapshot.date.toString();val n=nifty.filter{it.time<=date};val v=vix.filter{it.time<=date}
        require(n.lastOrNull()?.time==date && v.lastOrNull()?.time==date){"Market inputs have different session dates. A combined reading cannot be published."}
        val close=n.map{it.close};val fast=Indicators.ema(close,30);val slow=Indicators.ema(close,90)
        val momentum=close.indices.mapNotNull{i->if(fast[i]!=null && slow[i]!=null)(fast[i]!!/slow[i]!!-1)*100 else null}.takeLast(252)
        require(momentum.size>=120 && v.size>=120){"Insufficient index history for a reliable percentile baseline."}
        val factors=listOf(MoodFactor("NIFTY momentum",percentile(momentum.last(),momentum),"EMA30 / EMA90 − 1, ranked against up to 252 sessions. Higher means stronger momentum."),MoodFactor("India VIX",100-percentile(v.last().close,v.takeLast(252).map{it.close}),"Inverse percentile of India VIX over up to 252 sessions. Higher volatility lowers the score."),MoodFactor("Market participation",(snapshot.advances+.5*snapshot.unchanged)/snapshot.entries.size*100,"Advances plus half of unchanged securities, divided by eligible NSE EQ securities. Same-session breadth."))
        return MoodReading(date,factors.map{it.score}.average(),factors,Instant.now().toString())
    }
}
object MoodSource {
    private fun history(symbol:String):List<Candle>{
        val j=JSONObject(PublicHttp.get("https://query1.finance.yahoo.com/v8/finance/chart/${URLEncoder.encode(symbol,"UTF-8")}?range=5y&interval=1d")).getJSONObject("chart")
        require(j.isNull("error")){"Index source unavailable."};val r=j.getJSONArray("result").getJSONObject(0);require(r.getJSONObject("meta").getString("symbol")==symbol){"Index identity mismatch."}
        val t=r.getJSONArray("timestamp");val q=r.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);val today=LocalDate.now(ZoneId.of("Asia/Kolkata"))
        return buildList{for(i in 0 until t.length()){val date=Instant.ofEpochSecond(t.getLong(i)).atZone(ZoneId.of("Asia/Kolkata")).toLocalDate();if(!date.isBefore(today))continue;val c=q.getJSONArray("close");if(c.isNull(i))continue;val x=c.getDouble(i);require(x.isFinite()&&x>0);add(Candle(date.toString(),x,x,x,x,0.0))}}.sortedBy{it.time}
    }
    const val endpoint="https://api.tickertape.in/mmi/now"
    fun parse(body:String):MoodReading {
        val root=JSONObject(body);require(root.optBoolean("success")){"Market mood source unavailable."}
        val d=root.getJSONObject("data");val published=Instant.parse(d.getString("date"))
        require(!published.isAfter(Instant.now().plusSeconds(600))){"Source timestamp is in the future."}
        fun value(k:String)=d.getDouble(k).also{require(it.isFinite()){"Missing or invalid $k in mood source."}}
        val score=value("indicator");require(score in 0.0..100.0)
        val factors=listOf(
            MoodFactor("FII activity",value("fii"),"Published FII index-futures net positioning input. Not FII cash-market inflows.","%,.0f contracts".format(java.util.Locale.ENGLISH,value("fii"))),
            MoodFactor("Volatility & skew",value("vix"),"Published signed VIX input and put/call volatility skew. Raw values, not normalized contributions.","VIX %.2f · skew %.2f".format(java.util.Locale.ENGLISH,kotlin.math.abs(value("vix")),value("skew"))),
            MoodFactor("Momentum",value("momentum"),"Published difference between fast and slow NIFTY moving averages relative to the slow average.","%.2f%%".format(java.util.Locale.ENGLISH,value("momentum"))),
            MoodFactor("Market breadth",value("trin"),"Published transformed Modified Arms Index input. The signed source value is retained; it is not presented as an unsigned raw TRIN.","%.3f".format(java.util.Locale.ENGLISH,value("trin"))),
            MoodFactor("Price strength",value("extrema"),"Published net proportion near 52-week extremes. Displayed as percentage points.","%.1f pp".format(java.util.Locale.ENGLISH,value("extrema")*100)),
            MoodFactor("Demand for gold",value("goldOnNifty"),"Published relative gold-versus-NIFTY return input. A relative return, not a ratio of their index levels.","%.2f%%".format(java.util.Locale.ENGLISH,value("goldOnNifty")*100))
        )
        val comparisons=listOf("lastDay" to "Previous session","lastWeek" to "Week ago","lastMonth" to "Month ago").mapNotNull{(k,label)->d.optJSONObject(k)?.let{j->j.optDouble("indicator").takeIf{it.isFinite()&&it in 0.0..100.0}?.let{label to it}}}
        return MoodReading(published.atZone(ZoneId.of("Asia/Kolkata")).toLocalDate().toString(),score,factors,published.toString(),"Tickertape",comparisons)
    }
    fun load():MoodReading = parse(PublicHttp.get(endpoint))
}
