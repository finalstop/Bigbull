package com.bigbull.research
import org.json.JSONObject
import java.time.*
import java.net.URLEncoder

data class SessionQuote(val stock:Instrument,val price:Double,val previousClose:Double?,val asOf:String,val fetched:String,val bars:List<Candle>)
object SameDaySource {
    fun parse(body:String,stock:Instrument):SessionQuote {
        val chart=JSONObject(body).getJSONObject("chart");require(chart.isNull("error")){"Same-day quote unavailable."}
        val r=chart.getJSONArray("result").getJSONObject(0);val m=r.getJSONObject("meta")
        require(m.getString("symbol").equals(YahooHistory.ticker(stock),true) && m.optString("currency")=="INR"){"Quote instrument or currency mismatch."}
        require(m.optString("exchangeName") in if(stock.exchange=="NSE")listOf("NSI","NSE")else listOf("BSE","BOM")){"Quote exchange mismatch."}
        val price=m.getDouble("regularMarketPrice");require(price.isFinite()&&price>0)
        val at=Instant.ofEpochSecond(m.getLong("regularMarketTime"));require(!at.isAfter(Instant.now().plusSeconds(600))){"Quote timestamp is invalid."}
        val previous=m.optDouble("previousClose").takeIf{it.isFinite()&&it>0} ?: if(m.optString("range")=="1d")m.optDouble("chartPreviousClose").takeIf{it.isFinite()&&it>0}else null
        val times=r.optJSONArray("timestamp");val q=r.optJSONObject("indicators")?.optJSONArray("quote")?.optJSONObject(0)
        val bars=buildList{if(times!=null&&q!=null)for(i in 0 until times.length()){
            if(times.isNull(i)||listOf("open","high","low","close","volume").any{q.optJSONArray(it)?.isNull(i)!=false})continue
            val date=Instant.ofEpochSecond(times.getLong(i)).atZone(ZoneId.of("Asia/Kolkata")).toLocalDateTime().toString().replace('T',' ')
            fun v(k:String)=q.getJSONArray(k).getDouble(i)
            add(Candle(date,v("open"),v("high"),v("low"),v("close"),v("volume")).also{it.validate()})
        }}.sortedBy{it.time}
        require(bars.map{it.time}.distinct().size==bars.size){"Duplicate intraday timestamps."}
        return SessionQuote(stock,price,previous,at.toString(),Instant.now().toString(),bars)
    }
    fun load(stock:Instrument):SessionQuote {
        val symbol=URLEncoder.encode(YahooHistory.ticker(stock),"UTF-8")
        return parse(PublicHttp.get("https://query1.finance.yahoo.com/v8/finance/chart/$symbol?range=1d&interval=5m"),stock)
    }
}

/** Presentation dates always use the exchange timezone, never the phone timezone. */
object MarketTime {
    private val zone = ZoneId.of("Asia/Kolkata")
    fun quoteLabel(value:String, now:Instant=Instant.now()):String = try {
        val at=Instant.parse(value).atZone(zone)
        val pattern=if(at.toLocalDate()==now.atZone(zone).toLocalDate()) "h:mm a" else "d MMM, h:mm a"
        java.time.format.DateTimeFormatter.ofPattern(pattern, java.util.Locale.ENGLISH).format(at)+" IST · may be delayed"
    } catch(_:Exception) { "Timestamp unavailable · may be delayed" }
    fun barTime(value:String):String = try {
        java.time.format.DateTimeFormatter.ofPattern("HH:mm").format(LocalDateTime.parse(value.replace(' ', 'T')))
    } catch(_:Exception) { value }
    fun sessionLabel(bars:List<Candle>, now:Instant=Instant.now()):String {
        val date=bars.lastOrNull()?.time?.take(10) ?: return "Intraday unavailable"
        return if(date==now.atZone(zone).toLocalDate().toString()) "Today · 5 min" else "Session $date · 5 min"
    }
}
