package com.bigbull.research
import java.time.*
import java.util.zip.GZIPInputStream
import android.util.JsonReader
import android.util.JsonToken

data class UniverseSpec(val id:String,val title:String,val file:String)
data class UniverseSnapshot(val spec:UniverseSpec,val stocks:List<Instrument>,val fetched:String,val url:String)
data class BseSecurity(val stock:Instrument,val isin:String,val code:String)
object BseCatalog {
    const val source="https://upstox.com/developer/api-documentation/instruments/"
    @Volatile private var rows:List<BseSecurity> = emptyList()
    @Volatile private var nse:Set<String> = emptySet()
    @Volatile private var loaded:Instant?=null
    fun code(s:Instrument)=rows.firstOrNull{it.stock.symbol==s.symbol}?.code
    fun parse(input:java.io.Reader,exchange:String):List<BseSecurity>{
        val out=mutableListOf<BseSecurity>();val reader=JsonReader(input)
        reader.use{r->r.beginArray();while(r.hasNext()){
            var segment="";var name="";var isin="";var type="";var symbol="";var code=""
            r.beginObject();while(r.hasNext()){val k=r.nextName();if(k in setOf("segment","name","isin","instrument_type","trading_symbol","exchange_token")&&r.peek()!=JsonToken.NULL){val v=r.nextString();when(k){"segment"->segment=v;"name"->name=v;"isin"->isin=v;"instrument_type"->type=v;"trading_symbol"->symbol=v;"exchange_token"->code=v}}else r.skipValue()};r.endObject()
            val equity=if(exchange=="NSE")true else type in setOf("A","B","T","X","XT","M","MT","Z","ZP","P")&&isin.startsWith("INE")
            if(segment=="${exchange}_EQ"&&equity&&isin.matches(Regex("[A-Z0-9]{12}"))&&symbol.matches(Regex("[A-Z0-9&._-]{1,30}")))out.add(BseSecurity(Instrument(symbol,exchange,name),isin,code))
        };r.endArray()};return out.distinctBy{it.isin}
    }
    @Synchronized fun load(only:Boolean):List<Instrument>{
        if(loaded==null||Duration.between(loaded,Instant.now()).toHours()>=6){
            fun get(ex:String)=GZIPInputStream(ReaderSource.bytes("https://assets.upstox.com/market-quote/instruments/exchange/$ex.json.gz",8_000_000).inputStream()).bufferedReader().use{parse(it,ex)}
            val b=get("BSE");val n=get("NSE");require(b.size>1000&&n.size>1000){"Instrument directory incomplete"};rows=b;nse=n.map{it.isin}.toSet();loaded=Instant.now()
        }
        return rows.filter{!only||it.isin !in nse}.map{it.stock}.sortedBy{it.symbol}
    }
}
object ScreenUniverses {
    val options=listOf(UniverseSpec("500","NIFTY 500","ind_nifty500list.csv"),UniverseSpec("50","NIFTY 50","ind_nifty50list.csv"))+
        listOf("bank" to "Bank","it" to "IT","auto" to "Auto","fmcg" to "FMCG","pharma" to "Pharma","metal" to "Metal","energy" to "Energy","realty" to "Realty","finance" to "Financial Services","psubank" to "PSU Bank").map{UniverseSpec(it.first,"NIFTY ${it.second}","ind_nifty${it.first}list.csv")}+
        listOf(UniverseSpec("nse","All NSE EQ","EQUITY_L.csv"),UniverseSpec("bseonly","BSE only · not on NSE",""),UniverseSpec("bse","BSE equities",""),UniverseSpec("watchlist","My watchlist",""))
    fun url(s:UniverseSpec)=when(s.id){"nse"->"https://nsearchives.nseindia.com/content/equities/EQUITY_L.csv";"bse","bseonly"->BseCatalog.source;else->"https://www.niftyindices.com/IndexConstituent/${s.file}"}
    fun parse(text:String):List<Instrument>{val rows=CsvCandles.rows(text.removePrefix("\uFEFF"));require(rows.size>1){"Empty constituent file"};val h=rows.first().map{it.trim().uppercase()};val si=h.indexOf("SYMBOL");val ni=h.indexOf("COMPANY NAME").takeIf{it>=0}?:h.indexOf("NAME OF COMPANY");val se=h.indexOf("SERIES");require(si>=0&&ni>=0&&se>=0){"Constituent format changed"}
        val stocks=rows.drop(1).mapNotNull{r->require(r.size==h.size){"Malformed constituent row"};if("NAME OF COMPANY" in h&&r[se].trim()!="EQ")null else Instrument(r[si].trim(),"NSE",r[ni].trim())}.distinctBy{it.id};require(stocks.isNotEmpty()&&stocks.size<=10000&&stocks.all{it.symbol.matches(Regex("[A-Z0-9&._-]{1,30}"))}){"Invalid constituent file"};return stocks}
    fun load(s:UniverseSpec):UniverseSnapshot=UniverseSnapshot(s,if(s.id in listOf("bse","bseonly"))BseCatalog.load(s.id=="bseonly")else parse(ReaderSource.bytes(url(s)).toString(Charsets.UTF_8)),Instant.now().toString(),url(s))
}
data class RelativeStrengthResult(val scores:Map<String,Double>,val session:String?,val eligible:Int,val requested:Int,val failures:Int,val excluded:Int){val usable get()=eligible>=300&&failures.toDouble()/requested.coerceAtLeast(1)<=.05}
object RelativeStrength {
    fun annualReturn(c:List<Candle>,date:LocalDate):Double?{val bars=c.filter{it.time.take(10)<=date.toString()}.sortedBy{it.time};val end=bars.lastOrNull()?:return null;if(end.time.take(10)!=date.toString())return null;val target=date.minusYears(1);val start=bars.lastOrNull{it.time.take(10)<=target.toString()}?:return null;val days=java.time.temporal.ChronoUnit.DAYS.between(LocalDate.parse(start.time.take(10)),target);return if(days in 0..7&&start.close>0)end.close/start.close-1 else null}
    fun percentile(v:Double,values:List<Double>):Double{require(v.isFinite()&&values.isNotEmpty()&&values.all{it.isFinite()});return 100.0*(values.count{it<v}+.5*values.count{it==v})/values.size}
    fun rank(benchmark:List<Instrument>,history:Map<String,List<Candle>>,failures:Int):RelativeStrengthResult{
        val loaded=benchmark.mapNotNull{history[it.id]};val common=loaded.mapNotNull{it.lastOrNull()?.time?.take(10)}.groupingBy{it}.eachCount().maxByOrNull{it.value}?.key
        if(common==null)return RelativeStrengthResult(emptyMap(),null,0,benchmark.size,failures,0)
        val date=LocalDate.parse(common);val values=benchmark.mapNotNull{s->history[s.id]?.let{annualReturn(it,date)}}
        val scores=if(values.isEmpty())emptyMap()else history.mapNotNull{(id,c)->annualReturn(c,date)?.let{id to percentile(it,values)}}.toMap()
        return RelativeStrengthResult(scores,common,values.size,benchmark.size,failures,loaded.size-values.size)
    }
}
