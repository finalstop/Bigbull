package com.bigbull.research

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*

@Composable fun WatchlistPage(app:AppState) {
    var query by remember { mutableStateOf("") }; var showAdd by remember { mutableStateOf(false) }; var newList by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).glassClearance().padding(horizontal=20.dp,vertical=22.dp)) {
        PageHeader("Watchlists","Your research universe",action={ TextButton(onClick={ newList=true }) { Text("+ New list") } })
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) { app.lists.forEach { list -> SmallChip(list.name,list.id==app.listId) { app.chooseList(list.id) } } }
        Spacer(Modifier.height(20.dp)); Row(verticalAlignment=Alignment.CenterVertically) {
            OutlinedTextField(query,{query=it},Modifier.weight(1f),label={Text("Search company or symbol")},singleLine=true,shape=RoundedCornerShape(14.dp))
            Spacer(Modifier.width(8.dp)); PrimaryButton("Search",{app.search(query)},enabled=!app.isLoading)
        }
        TextButton(onClick={showAdd=true},contentPadding=PaddingValues(0.dp)) { Text("+ Add an NSE or BSE symbol manually") }
        if(app.searchResults.isNotEmpty()) {
            Spacer(Modifier.height(5.dp)); Kicker("SEARCH RESULTS · NSE FILE / YAHOO"); Spacer(Modifier.height(8.dp))
            Panel { app.searchResults.take(20).forEach { s -> Row(Modifier.fillMaxWidth().padding(vertical=8.dp),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(s.symbol,fontWeight=FontWeight.SemiBold); Muted("${s.exchange} · ${s.name}") }; TextButton(onClick={app.addStock(s);app.searchResults=emptyList();app.message="${s.symbol} added."}) { Text("Add") } } } }
            Spacer(Modifier.height(20.dp))
        }
        SectionTitle(app.lists.firstOrNull{it.id==app.listId}?.name ?: "Watchlist") { Text("${app.stocks.size} stocks",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant) }
        Spacer(Modifier.height(8.dp))
        if(app.stocks.isEmpty()) EmptyPanel("Your list is empty","Search or add a symbol. Prices use free public history. No API key is needed.") else Panel { app.stocks.forEach { s ->
            Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.weight(1f)) { StockRow(app,s) { app.openStock(s) } }; TextButton(onClick={app.removeStock(s)}) { Text("Remove",style=MaterialTheme.typography.labelSmall) } }
        } }
        if(app.lists.size>1) TextButton(onClick={app.removeList()},modifier=Modifier.padding(top=10.dp)) { Text("Delete this list") }
        Spacer(Modifier.height(25.dp)); Muted("Prices are the last loaded daily close. Select a stock to refresh or import OHLCV history.")
    }
    if(showAdd) AddInstrumentDialog(onDismiss={showAdd=false},onAdd={s-> app.addStock(s);showAdd=false;app.message="${s.symbol} added to the list."})
    if(newList) { var name by remember { mutableStateOf("") }; AlertDialog(onDismissRequest={newList=false},title={Text("Create watchlist")},text={OutlinedTextField(name,{name=it},label={Text("List name")},singleLine=true)},confirmButton={TextButton(onClick={if(name.isNotBlank()){ app.addList(name);newList=false }}){Text("Create")}},dismissButton={TextButton(onClick={newList=false}){Text("Cancel")}}) }
}
@Composable fun AddInstrumentDialog(onDismiss:()->Unit,onAdd:(Instrument)->Unit) {
    var symbol by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var exchange by remember { mutableStateOf("NSE") }; var error by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Add a symbol")},text={Column {
        Muted("Enter the provider’s exact ticker. The exchange remains part of its identity."); Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("NSE","BSE").forEach { e -> SmallChip(e,exchange==e){exchange=e} } }
        OutlinedTextField(symbol,{symbol=it.uppercase().trim()},label={Text("Symbol")},singleLine=true)
        OutlinedTextField(name,{name=it},label={Text("Company name (optional)")},singleLine=true)
        if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)
    }},confirmButton={TextButton(onClick={ if(symbol.matches(Regex("[A-Z0-9&._-]{1,30}"))) onAdd(Instrument(symbol,exchange,name.trim())) else error="Enter a valid ticker, without spaces." }){Text("Add")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable fun CustomScreenerPage(app:AppState) {
    var above by remember { mutableStateOf(false) }; var oversold by remember { mutableStateOf(false) }; var volume by remember { mutableStateOf(false) }; var profitable by remember { mutableStateOf(false) }; var peFilter by remember { mutableStateOf(false) }; var maxPe by remember { mutableStateOf("1") }
    val results=app.stocks.mapNotNull { s ->
        val c=app.series(s)?.candles ?: return@mapNotNull null
        val close=c.map{it.close}; val sma=Indicators.sma(close,20).lastOrNull(); val rsi=Indicators.rsi(close).lastOrNull()
        if(above && (sma==null || c.last().close<=sma)) return@mapNotNull null
        if(oversold && (rsi==null || rsi>=30)) return@mapNotNull null
        if(volume && (c.size<21 || c.last().volume<=c.dropLast(1).takeLast(20).map{it.volume}.average()*1.5)) return@mapNotNull null
        if(profitable) {
            val report=app.report(s,"income_statement","annual") ?: return@mapNotNull null
            val income=try { org.json.JSONObject(report.second).optJSONArray("income_statement")?.optJSONObject(0) } catch(_:Exception){null} ?: return@mapNotNull null
            val sales=income.optString("sales").toDoubleOrNull();val net=income.optString("net_income").toDoubleOrNull()
            if(sales==null || sales<=0 || net==null || net<=0) return@mapNotNull null
        }
        if(peFilter) {
            val limit=maxPe.toDoubleOrNull() ?: return@mapNotNull null
            val report=app.report(s,"balance_sheet","annual") ?: return@mapNotNull null
            val pe=try { val row=org.json.JSONObject(report.second).optJSONArray("balance_sheet")?.optJSONObject(0);val debt=row?.optString("total_debt")?.toDoubleOrNull();val equity=row?.optString("stockholders_equity")?.toDoubleOrNull();if(debt!=null&&equity!=null&&equity>0)debt/equity else null } catch(_:Exception){null}
            if(pe==null || !pe.isFinite() || pe<0 || pe>=limit) return@mapNotNull null
        }
        s
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).glassClearance().padding(horizontal=20.dp,vertical=22.dp)) {
        PageHeader("Screener","Combine conditions on your watchlist")
        Panel(Modifier.fillMaxWidth()) {
            Kicker("FILTERS"); Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)){Text("Close above SMA 20");Muted("At least 20 daily candles")}; Switch(above,{above=it}) }
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)){Text("RSI 14 below 30");Muted("Wilder calculation; 15 candles")}; Switch(oversold,{oversold=it}) }
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)){Text("Volume > 1.5× average");Muted("Versus previous 20 daily candles")}; Switch(volume,{volume=it}) }
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)){Text("Positive net margin");Muted("Requires a loaded annual income statement")}; Switch(profitable,{profitable=it}) }
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)){Text("Debt / equity below a limit");Muted("Requires a loaded annual balance sheet")}; Switch(peFilter,{peFilter=it}) }
            if(peFilter) OutlinedTextField(maxPe,{maxPe=it},label={Text("Maximum debt / equity, exclusive")},singleLine=true)

        }
        Spacer(Modifier.height(20.dp)); SectionTitle("Matches") { Muted("${results.size} of ${app.stocks.size}") }; Spacer(Modifier.height(8.dp))
        if(results.isEmpty()) EmptyPanel("No matches","Only stocks with loaded daily data and enough history for the selected conditions are included.")
        else Panel { results.forEach { s -> StockRow(app,s){app.openStock(s)} } }
        Spacer(Modifier.height(18.dp)); Muted("This screens the current watchlist, not the whole exchange. Missing prices, reports or history are excluded. Each result uses its own last available dates; open Financials to load statements. No filter is an investment recommendation.")
    }
}
