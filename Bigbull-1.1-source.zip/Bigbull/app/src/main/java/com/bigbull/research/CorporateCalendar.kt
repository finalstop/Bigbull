package com.bigbull.research
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.json.JSONArray
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale

data class CorporateEvent(val stock:Instrument,val date:LocalDate,val kind:String,val description:String,val recordDate:LocalDate?=null,val announced:String="",val link:String=""){val id get()="${stock.id}:$kind:$date:$description"}
object CorporateCalendar {
    val zone=ZoneId.of("Asia/Kolkata")
    fun date(s:String):LocalDate?=runCatching{LocalDate.parse(s.trim(),DateTimeFormatter.ofPattern("dd-MMM-uuuu",Locale.ENGLISH))}.getOrNull()
    fun url(kind:String,today:LocalDate=LocalDate.now(zone)):String{val f=DateTimeFormatter.ofPattern("dd-MM-uuuu");val from=if(kind=="dividend")today.minusDays(7)else today;val endpoint=if(kind=="dividend")"corporates-corporateActions"else"corporate-board-meetings";return "https://www.nseindia.com/api/$endpoint?index=equities&from_date=${from.format(f)}&to_date=${today.plusDays(90).format(f)}"}
    fun parse(body:String,kind:String,today:LocalDate=LocalDate.now(zone)):List<CorporateEvent>{val rows=JSONArray(body);val events=mutableListOf<CorporateEvent>();val superseded=mutableSetOf<String>()
        for(i in 0 until rows.length()){val j=rows.getJSONObject(i)
            if(kind=="dividend"){
                val subject=j.optString("subject");if(!subject.contains("dividend",true)||j.optString("series")!="EQ")continue
                val ex=date(j.optString("exDate"))?:continue;if(ex<today.minusDays(7)||ex>today.plusDays(90))continue
                val symbol=j.optString("symbol");if(symbol.isBlank())continue
                events.add(CorporateEvent(Instrument(symbol,"NSE",j.optString("comp")),ex,kind,subject,date(j.optString("recDate")),link="https://www.nseindia.com/companies-listing/corporate-filings-actions"))
            }else{
                val purpose=j.optString("bm_purpose");val desc=j.optString("bm_desc");if(!Regex("financial\\s+results?|cancelled|canceled|withdrawn",RegexOption.IGNORE_CASE).containsMatchIn("$purpose $desc"))continue
                val whenDate=date(j.optString("proposedMeetingDate"))?:date(j.optString("bm_date"))?:continue;val symbol=j.optString("bm_symbol");if(symbol.isBlank())continue
                val old=date(j.optString("oriiginalMeetingDate"))?:date(j.optString("originalMeetingDate"));if(old!=null&&old!=whenDate)superseded.add("$symbol:$old")
                if(whenDate<today||whenDate>today.plusDays(90))continue
                val link=j.optString("attachment").takeIf{ReaderPolicy.safe(it)&&java.net.URI(it).host.let{h->h=="nseindia.com"||h.endsWith(".nseindia.com")}}?:"https://www.nseindia.com/companies-listing/corporate-filings-board-meetings"
                events.add(CorporateEvent(Instrument(symbol,"NSE",j.optString("sm_name")),whenDate,kind,desc.ifBlank{purpose},announced=j.optString("bm_timestamp"),link=link))
            }
        }
        return events.filterNot{kind!="dividend"&&"${it.stock.symbol}:${it.date}" in superseded}.groupBy{it.stock.id+it.date+if(kind=="dividend")it.description else ""}.values.mapNotNull{g->
            val latest=g.maxByOrNull{runCatching{LocalDateTime.parse(it.announced,DateTimeFormatter.ofPattern("dd-MMM-uuuu HH:mm:ss",Locale.ENGLISH))}.getOrDefault(LocalDateTime.MIN)}!!
            if(kind!="dividend"&&Regex("cancelled|canceled|withdrawn",RegexOption.IGNORE_CASE).containsMatchIn(latest.description))null else latest
        }.sortedWith(compareBy<CorporateEvent>{it.date}.thenBy{it.stock.symbol})
    }
    fun label(d:LocalDate)=d.format(DateTimeFormatter.ofPattern("d MMM yyyy",Locale.ENGLISH))
}
@Composable fun EventsPage(app:AppState,initial:Int=0){
    var tab by remember{mutableIntStateOf(initial)};var query by remember{mutableStateOf("")};LaunchedEffect(Unit){app.loadEvents()}
    val kind=if(tab==0)"results"else"dividend";val rows=app.events[kind].orEmpty().filter{it.stock.symbol.contains(query,true)||it.stock.name.contains(query,true)}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(start=20.dp,end=20.dp,top=18.dp,bottom=LocalGlassInset.current+20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{SectionTitle("Company calendar"){TextButton(onClick={app.loadEvents(true)},enabled=!app.eventsLoading){Text("Refresh")}};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){SmallChip("Upcoming results",tab==0){tab=0};SmallChip("Dividends",tab==1){tab=1}}
            Spacer(Modifier.height(12.dp));Muted(if(tab==0)"Announced meetings to consider financial results, within 90 days. Dates can change; check the filing."else"Announced cash dividends. Ex-dates: past 7 days through next 90 days. Record dates are separate.")
            Spacer(Modifier.height(12.dp));OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Find a company")})
            app.eventFetched[kind]?.let{Muted("NSE · retrieved ${CheckpointFacts.stamp(it)}")};app.eventErrors[kind]?.let{Text(it,color=MaterialTheme.colorScheme.error)}
        }
        if(rows.isEmpty())item{EmptyPanel(if(app.eventsLoading)"Loading announcements…"else"No available events","No matching source announcements in this date window.")}
        items(rows,key={it.id}){e->Panel(Modifier.fillMaxWidth()){
            Row(Modifier.fillMaxWidth().clickable{app.openStock(e.stock)},verticalAlignment=Alignment.CenterVertically){CompanyLogo(e.stock);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(e.stock.symbol,fontWeight=FontWeight.SemiBold);Muted(e.stock.name)};Text("›")}
            Spacer(Modifier.height(12.dp));Text((if(tab==0)"Results meeting · "else"Ex-dividend · ")+CorporateCalendar.label(e.date),color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Medium)
            Spacer(Modifier.height(6.dp));Text(e.description,style=MaterialTheme.typography.bodySmall,maxLines=5)
            if(tab==1)Muted("Record date: "+(e.recordDate?.let{CorporateCalendar.label(it)}?:"Not supplied"));SourceLink("Original NSE filing",e.link)
        }}
    }
}
@Composable fun CalendarPreview(app:AppState,onSelect:(Int)->Unit){
    Column(verticalArrangement=Arrangement.spacedBy(14.dp)){listOf("results" to "Upcoming results","dividend" to "Announced dividends").forEachIndexed{i,(kind,title)->Panel(Modifier.fillMaxWidth()){
        SectionTitle(title){TextButton(onClick={onSelect(i)}){Text("View all")}}
        val rows=app.events[kind].orEmpty().filter{it.date>=LocalDate.now(CorporateCalendar.zone)}.take(3)
        if(rows.isEmpty())Muted(if(app.eventsLoading)"Loading announcements…"else app.eventErrors[kind]?:"No upcoming announcements available.")
        rows.forEach{e->Row(Modifier.fillMaxWidth().clickable{app.openStock(e.stock)}.padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically){CompanyLogo(e.stock,28.dp);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(e.stock.symbol,fontSize=13.sp);if(i==1)Muted(e.description)};Text(e.date.format(DateTimeFormatter.ofPattern("d MMM",Locale.ENGLISH)),fontSize=12.sp,color=MaterialTheme.colorScheme.primary)}}
    }}}
}
