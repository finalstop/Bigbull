package com.bigbull.research

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import dev.chrisbanes.haze.*
import kotlin.math.*

val LocalGlassInset=staticCompositionLocalOf { 0.dp }
@Composable fun Modifier.glassClearance()=this.padding(bottom=LocalGlassInset.current)
@Composable fun BrandMark(modifier:Modifier=Modifier){
    Text("BB",modifier.semantics{contentDescription="Bigbull"},fontFamily=FontFamily(Font(R.font.bb_serif,FontWeight.Bold,FontStyle.Italic)),fontWeight=FontWeight.Bold,fontStyle=FontStyle.Italic,fontSize=38.sp,letterSpacing=(-3).sp,lineHeight=44.sp)
}
@Composable private fun glassStyle():HazeStyle {
    val c=MaterialTheme.colorScheme
    return HazeStyle(backgroundColor=c.background,tints=listOf(HazeTint(c.surface.copy(alpha=.64f))),blurRadius=24.dp,noiseFactor=.025f,fallbackTint=HazeTint(c.surface.copy(alpha=.97f)))
}
@Composable fun GlassNavigation(page:Int,onPage:(Int)->Unit,haze:HazeState,modifier:Modifier=Modifier){
    val shape=RoundedCornerShape(32.dp);val c=MaterialTheme.colorScheme
    Box(modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal=12.dp,vertical=8.dp)){
        BoxWithConstraints(Modifier.fillMaxWidth().height(66.dp).clip(shape).hazeChild(haze,glassStyle())
            .border(1.dp,Brush.linearGradient(listOf(Color.White.copy(alpha=.26f),c.outline.copy(alpha=.22f),Color.White.copy(alpha=.08f))),shape).testTag("bottomNavigation")){
            val cell=(maxWidth-12.dp)/5
            val offset by animateDpAsState(6.dp+cell*page,tween(300,easing=FastOutSlowInEasing),label="Glass selection position")
            Box(Modifier.offset(x=offset,y=6.dp).width(cell).height(54.dp).clip(RoundedCornerShape(27.dp))
                .background(Brush.verticalGradient(listOf(c.primary.copy(alpha=.20f),c.primary.copy(alpha=.08f))))
                .border(.75.dp,c.primary.copy(alpha=.21f),RoundedCornerShape(27.dp)))
            Row(Modifier.fillMaxSize().padding(horizontal=6.dp),verticalAlignment=Alignment.CenterVertically){
                val icons=listOf(Icons.Outlined.Home,Icons.Outlined.Star,Icons.Outlined.List,Icons.Outlined.Person,Icons.Outlined.MoreVert)
                listOf("Markets","Watchlist","News","Portfolio","More").forEachIndexed{i,label->
                    val tone=if(page==i)c.primary else c.onSurfaceVariant
                    Column(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(27.dp)).selectable(selected=page==i,interactionSource=remember{MutableInteractionSource()},indication=null,role=Role.Tab,onClick={onPage(i)}).padding(vertical=12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(4.dp)){
                        if(i==3)Icon(painterResource(R.drawable.ic_portfolio),null,Modifier.size(21.dp),tint=tone)else Icon(icons[i],null,Modifier.size(21.dp),tint=tone)
                        Text(label,color=tone,style=MaterialTheme.typography.labelSmall,maxLines=1)
                    }
                }
            }
        }
    }
}
@Composable fun AnimatedMoodGauge(m:MoodReading){
    val motion=remember { Animatable(50f) };var replay by remember {mutableIntStateOf(0)}
    LaunchedEffect(m.score,replay){motion.snapTo(50f);motion.animateTo(m.score.toFloat().coerceIn(0f,100f),tween(1100,easing=FastOutSlowInEasing))}
    val colors=listOf(Color(0xFF52B391),Color(0xFFECA747),Color(0xFFE17B4B),Color(0xFFDF6676))
    val tone=colors[when{m.score<30->0;m.score<50->1;m.score<70->2;else->3}]
    val fg=MaterialTheme.colorScheme.onSurface;val haze=remember{HazeState()}
    Column(horizontalAlignment=Alignment.CenterHorizontally){
        Text(m.zone,fontSize=23.sp,fontWeight=FontWeight.SemiBold,color=tone)
        Box(Modifier.fillMaxWidth().height(270.dp),contentAlignment=Alignment.Center){
            Canvas(Modifier.fillMaxSize().haze(haze).semantics { contentDescription="Market mood ${num(m.score,1)} out of 100, ${m.zone}" }.testTag("moodGauge")){
                val radius=min(size.width*.40f,size.height*.40f);val center=Offset(size.width/2,size.height*.47f)
                val bounds=Offset(center.x-radius,center.y-radius);val arcSize=Size(radius*2,radius*2)
                val zones=listOf(0f,30f,50f,70f,100f)
                colors.forEachIndexed{i,color->drawArc(color.copy(alpha=.85f),153.5f+zones[i]*2.4f,(zones[i+1]-zones[i])*2.4f-7,false,bounds,arcSize,style=Stroke(11.dp.toPx(),cap=StrokeCap.Round))}
                for(t in 0..20){
                    val a=Math.toRadians(150.0+t*12)
                    fun point(r:Float)=Offset(center.x+cos(a).toFloat()*r,center.y+sin(a).toFloat()*r)
                    drawLine(fg.copy(alpha=.17f),point(radius-18.dp.toPx()),point(radius-(if(t%5==0)26 else 22).dp.toPx()),1.dp.toPx())
                }
                val angle=Math.toRadians(150.0+motion.value*2.4)
                val end=Offset(center.x+cos(angle).toFloat()*radius*.68f,center.y+sin(angle).toFloat()*radius*.68f)
                drawLine(tone.copy(alpha=.12f),center,end,12.dp.toPx(),cap=StrokeCap.Round)
                drawLine(tone,center,end,3.dp.toPx(),cap=StrokeCap.Round)
                drawCircle(fg,5.dp.toPx(),center)
            }
            Column(Modifier.align(Alignment.BottomCenter).padding(bottom=8.dp).clip(RoundedCornerShape(22.dp)).hazeChild(haze,glassStyle()).border(.7.dp,fg.copy(alpha=.12f),RoundedCornerShape(22.dp)).padding(horizontal=28.dp,vertical=9.dp),horizontalAlignment=Alignment.CenterHorizontally){
                Text(num(m.score,1),fontSize=34.sp,fontWeight=FontWeight.SemiBold,letterSpacing=(-1).sp,color=tone)
                Text("OUT OF 100",fontSize=9.sp,letterSpacing=1.7.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Muted("Extreme fear");Muted("Extreme greed")}
        TextButton(onClick={replay++}){Text("Replay movement",fontSize=11.sp)}
    }
}

@Composable fun BrandHeader(app:AppState){
    Row(Modifier.fillMaxWidth().padding(horizontal=20.dp).height(54.dp),verticalAlignment=Alignment.CenterVertically){
        BrandMark(Modifier.weight(1f))
        TextButton(onClick={app.changeDark(!app.dark)}){Text(if(app.dark)"Light mode" else "Dark mode",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}
    }
}
