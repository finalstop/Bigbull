package com.bigbull.research

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.max

@Composable fun PriceChart(series:Series) {
    val candles=series.candles; var visible by remember(series.stock.id,series.interval) { mutableIntStateOf(minOf(60,candles.size)) }; var end by remember(series.stock.id,series.interval) { mutableIntStateOf(candles.size) }
    var selectedIndex by remember(series.stock.id,series.interval) { mutableIntStateOf(candles.lastIndex) }; var line by remember { mutableStateOf(true) }; var overlay by remember { mutableStateOf(false) }; var details by remember { mutableStateOf(false) }
    LaunchedEffect(candles) { visible=minOf(60,candles.size);end=candles.size;selectedIndex=candles.lastIndex }
    val count=visible.coerceIn(1,candles.size); val safeEnd=end.coerceIn(count,candles.size); val start=safeEnd-count; val visibleCandles=candles.subList(start,safeEnd)
    val sma=remember(candles) { Indicators.sma(candles.map{it.close},20) }; val ema=remember(candles) { Indicators.ema(candles.map{it.close},20) }
    val overlays=if(overlay)(sma.subList(start,safeEnd)+ema.subList(start,safeEnd)).filterNotNull() else emptyList()
    val hi=max(visibleCandles.maxOf { it.high },overlays.maxOrNull() ?: 0.0); val lo=minOf(visibleCandles.minOf { it.low },overlays.minOrNull() ?: Double.MAX_VALUE); val pad=max((hi-lo)*.08,hi*.005); val top=hi+pad; val bottom=max(0.0,lo-pad); val span=(top-bottom).coerceAtLeast(0.00001)
    val up=Positive; val down=Negative; val grid=MaterialTheme.colorScheme.outline.copy(alpha=.25f); val accent=MaterialTheme.colorScheme.secondary
    val chosen=candles.getOrNull(selectedIndex) ?: candles.last()
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Price chart",fontWeight=FontWeight.SemiBold); }; TextButton(onClick={line=!line}){Text(if(line) "Line" else "Candles")} }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Muted("${num(top)}"); Muted("${count} bars") }
        Canvas(Modifier.fillMaxWidth().height(180.dp)
            .pointerInput(start,count,candles) { detectTapGestures { p -> selectedIndex=(start+(p.x/size.width*count).toInt()).coerceIn(start,safeEnd-1) } }
            .pointerInput(candles.size,visible,end) { detectTransformGestures { _,pan,zoom,_ ->
                val newCount=(visible/zoom).toInt().coerceIn(minOf(20,candles.size),candles.size); val shift=(-pan.x/(size.width.toFloat()/newCount)).toInt()
                visible=newCount; end=(end+shift).coerceIn(newCount,candles.size)
            } }) {
            val w=size.width
            val h=size.height
            fun y(p:Double)=((top-p)/span*h).toFloat()
            val step=w/count
            for(i in 0..4) drawLine(grid,Offset(0f,h*i/4f),Offset(w,h*i/4f),1.dp.toPx())
            if(line) { val path=Path(); visibleCandles.forEachIndexed { i,c -> val x=(i+.5f)*step; if(i==0) path.moveTo(x,y(c.close)) else path.lineTo(x,y(c.close)) };val tone=if(visibleCandles.last().close>=visibleCandles.first().close)up else down;val area=Path().apply{addPath(path);lineTo((count-.5f)*step,h);lineTo(.5f*step,h);close()};drawPath(area,Brush.verticalGradient(listOf(tone.copy(alpha=.16f),tone.copy(alpha=0f))));drawPath(path,tone,style=Stroke(2.dp.toPx())) }
            else visibleCandles.forEachIndexed { i,c -> val x=(i+.5f)*step; val color=if(c.close>=c.open) up else down;drawLine(color,Offset(x,y(c.high)),Offset(x,y(c.low)),1.dp.toPx());val a=y(max(c.open,c.close));val b=y(minOf(c.open,c.close));drawRect(color,Offset(x-step*.28f,a),Size((step*.56f).coerceAtLeast(1.dp.toPx()),(b-a).coerceAtLeast(1.dp.toPx()))) }
            if(overlay) {
                fun trace(vals:List<Double?>,color:Color) { val path=Path();var begun=false; for(i in start until safeEnd) { val v=vals[i]; if(v!=null) { val x=(i-start+.5f)*step; if(!begun){path.moveTo(x,y(v));begun=true}else path.lineTo(x,y(v)) } };drawPath(path,color,style=Stroke(1.5.dp.toPx())) }
                trace(sma,accent);trace(ema,Color(0xFF7DAFE5))
            }
            if(selectedIndex in start until safeEnd) { val x=(selectedIndex-start+.5f)*step;drawLine(grid.copy(alpha=.8f),Offset(x,0f),Offset(x,h),1.dp.toPx()) }
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) { Muted(num(bottom)); Muted("${if(series.interval=="5min")MarketTime.barTime(visibleCandles.first().time)else visibleCandles.first().time.take(10)} → ${if(series.interval=="5min")MarketTime.barTime(visibleCandles.last().time)else visibleCandles.last().time.take(10)}") }
        Spacer(Modifier.height(8.dp))
        val maxVolume=visibleCandles.maxOf{it.volume}.coerceAtLeast(1.0)
        Canvas(Modifier.fillMaxWidth().height(24.dp)){val step=size.width/count;visibleCandles.forEachIndexed{i,c->val height=(c.volume/maxVolume*size.height).toFloat();drawRect((if(c.close>=c.open)up else down).copy(alpha=.45f),Offset(step*i,size.height-height),Size((step-1).coerceAtLeast(1f),height))}}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Muted("Volume");Muted("${count} source bars")}
        Spacer(Modifier.height(6.dp))
        TextButton(onClick={details=!details},contentPadding=PaddingValues(0.dp)){Text(if(details)"Hide candle details" else "Candle details",fontSize=12.sp)}
        if(details){
            Muted(if(series.interval=="5min") "${MarketTime.barTime(chosen.time)} IST · bar may be forming" else chosen.time)
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                listOf("Open" to chosen.open,"High" to chosen.high,"Low" to chosen.low,"Close" to chosen.close).forEach{(label,value)->Column{Muted(label);Text(num(value),fontSize=12.sp,fontWeight=FontWeight.Medium)}}
            }
            Muted("Volume ${num(chosen.volume,0)}")
            Muted("Tap to inspect · pinch to zoom · drag to pan")
        }
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
            TextButton(onClick={overlay=!overlay},contentPadding=PaddingValues(0.dp)) {Text(if(overlay) "SMA 20 / EMA 20: on" else "SMA / EMA")}
            Row { TextButton(onClick={visible=(visible+30).coerceAtMost(candles.size);end=end.coerceAtLeast(visible)}){Text("−")};TextButton(onClick={visible=(visible-30).coerceAtLeast(minOf(20,candles.size))}){Text("+")} }
        }
    }
}
@Composable fun TechnicalPanel(series:Series) {
    val c=series.candles; val closes=c.map{it.close}; val sma=Indicators.sma(closes,20).lastOrNull();val ema=Indicators.ema(closes,20).lastOrNull();val rsi=Indicators.rsi(closes).lastOrNull();val macd=Indicators.macd(closes).lastOrNull();val bands=Indicators.bands(closes).lastOrNull();val atr=Indicators.atr(c).lastOrNull();val mfi=Indicators.mfi(c).lastOrNull();val obv=Indicators.obv(c).lastOrNull(); val pivots=c.getOrNull(c.lastIndex-1)?.let { Indicators.classicPivots(it) }; val highLow=if(series.interval=="1day") Indicators.highLow52Weeks(c) else null
    Panel(Modifier.fillMaxWidth()) {
        Kicker("TECHNICAL SNAPSHOT"); Spacer(Modifier.height(8.dp)); Text("Calculated from loaded candles",fontWeight=FontWeight.SemiBold); Muted("${series.interval} · as of ${c.last().time}")
        Spacer(Modifier.height(14.dp))
        fun show(x:Double?)=x?.let{num(it)} ?: "Not enough data"
        listOf("SMA 20" to show(sma),"EMA 20" to show(ema),"RSI 14 (Wilder)" to show(rsi),"MACD 12/26" to show(macd?.line),"MACD signal 9" to show(macd?.signal),"ATR 14 (Wilder)" to show(atr),"Bollinger upper / lower" to (if(bands==null) "Not enough data" else "${num(bands.upper)} / ${num(bands.lower)}"),"MFI 14" to show(mfi),"OBV" to show(obv),"Previous-bar pivot" to show(pivots?.pivot),"Previous-bar R1 / S1" to (if(pivots==null) "Not enough data" else "${num(pivots.resistance1)} / ${num(pivots.support1)}"),"52-week high / low" to (if(highLow==null) "Not enough daily data" else "${num(highLow.first)} / ${num(highLow.second)}")).forEach { (label,value)->
            Row(Modifier.fillMaxWidth().padding(vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween) { Muted(label); Text(value,style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold) }
        }
        Spacer(Modifier.height(10.dp)); Muted("SMA and EMA use closes; EMA is SMA-seeded. Bollinger bands use 20 bars and two population standard deviations. OBV starts at zero for the loaded window. Classic pivots use the prior candle. 52-week high/low requires daily data covering the full window.")
    }
}

@Composable fun FinancialsPanel(app:AppState,stock:Instrument) {
    var period by remember {mutableStateOf("annual")}; var endpoint by remember {mutableStateOf("income_statement")}
    val report=app.report(stock,endpoint,period)
    Column {
        Kicker("COMPANY RESEARCH");Spacer(Modifier.height(6.dp));Text("Financial reports",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp));Muted("Free public statements, where available. Reporting currency can differ from INR. Missing fields stay unavailable; check figures against original filings.")
        Spacer(Modifier.height(16.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("annual","quarterly").forEach { SmallChip(it.replaceFirstChar{c->c.uppercase()},period==it){period=it} } }
        Spacer(Modifier.height(10.dp)); Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            listOf("income_statement" to "Income", "balance_sheet" to "Balance sheet", "cash_flow" to "Cash flow").forEach { (e,label)->SmallChip(label,endpoint==e){endpoint=e} }
        }
        Spacer(Modifier.height(14.dp)); PrimaryButton("Load ${when(endpoint){"income_statement"->"income statement";"balance_sheet"->"balance sheet";"cash_flow"->"cash flow";else->endpoint}}",{app.loadReport(stock,endpoint,period)},enabled=!app.isLoading)
        Spacer(Modifier.height(8.dp)); Muted("Source: Yahoo Finance public financial timeseries · No API key. Statements can be partial or unavailable.")
        Spacer(Modifier.height(15.dp))
        if(report==null) EmptyPanel("No report loaded","Load the selected statement for free. If the source has no coverage, use the original website links below.") else {
            val parsed=remember(report.second){ JSONObject(report.second) }
            if(endpoint=="income_statement") IncomeSummary(parsed,period) else FinancialHighlights(parsed,endpoint)
            SourceLink("View on Yahoo Finance","https://finance.yahoo.com/quote/${stock.symbol}${if(stock.exchange=="NSE")".NS" else ".BO"}/financials/")
            Spacer(Modifier.height(10.dp)); Panel(Modifier.fillMaxWidth()) {
                Kicker("SOURCE DATA"); Spacer(Modifier.height(6.dp)); Muted("Fetched ${report.first} · ${if(app.cache) "offline cache enabled" else "session only unless previously saved"}")
                var expanded by remember {mutableStateOf(false)}
                TextButton(onClick={expanded=!expanded}){Text(if(expanded)"Hide reported figures" else "Show reported figures")}
                if(expanded)JsonRows(parsed,0)
            }
        }
        Spacer(Modifier.height(12.dp));SourceLink("Open company research on Screener","https://www.screener.in/company/${stock.symbol}/")
        SourceLink("Browse official NSE filings","https://www.nseindia.com/companies-listing/corporate-filings-financial-results")
    }
}
@Composable fun FinancialHighlights(j:JSONObject,endpoint:String) {
    val latest=j.optJSONArray(endpoint)?.optJSONObject(0) ?: return
    fun value(k:String)=latest.optString(k).toDoubleOrNull()?.takeIf{it.isFinite()}
    fun ratio(a:Double?,b:Double?)=if(a!=null && b!=null && b>0)num(a/b)+"×" else "Unavailable"
    Panel(Modifier.fillMaxWidth()) {
        Kicker(if(endpoint=="balance_sheet")"FINANCIAL POSITION" else "CASH GENERATION")
        Spacer(Modifier.height(7.dp));Muted("Period ending ${latest.optString("fiscal_date")} · ${j.optJSONObject("meta")?.optString("currency","Unspecified currency")} · full currency units")
        val rows=if(endpoint=="balance_sheet")listOf("Total assets" to value("total_assets")?.let{num(it,0)},"Total debt" to value("total_debt")?.let{num(it,0)},"Equity" to value("stockholders_equity")?.let{num(it,0)},"Debt / equity" to ratio(value("total_debt"),value("stockholders_equity")),"Current ratio" to ratio(value("current_assets"),value("current_liabilities"))) else listOf("Operating cash flow" to value("operating_cash_flow")?.let{num(it,0)},"Free cash flow" to value("free_cash_flow")?.let{num(it,0)},"Capital expenditure" to value("capital_expenditure")?.let{num(it,0)})
        Spacer(Modifier.height(10.dp));rows.forEach{(label,v)->Row(Modifier.fillMaxWidth().padding(vertical=6.dp)){Muted(label,Modifier.weight(1f));Text(v?:"Unavailable",style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)}}
        Spacer(Modifier.height(8.dp));Muted(if(endpoint=="balance_sheet")"Debt/equity = total debt ÷ equity; current ratio = current assets ÷ current liabilities. Ratios require positive denominators and are not comparable across all sectors, especially banks." else "Cash flow is different from accounting profit. Free cash flow is the source’s reported value; it is not a forecast or a dividend commitment.")
    }
}
@Composable fun IncomeSummary(j:JSONObject,period:String) {
    val arr=j.optJSONArray("income_statement") ?: return; if(arr.length()==0) return; val latest=arr.optJSONObject(0) ?: return
    fun value(o:JSONObject,key:String):Double?=if(o.has(key)&&!o.isNull(key)) o.optString(key).toDoubleOrNull()?.takeIf{it.isFinite()} else null
    val sales=value(latest,"sales"); val gross=value(latest,"gross_profit"); val net=value(latest,"net_income");val op=value(latest,"operating_income"); val currency=j.optJSONObject("meta")?.optString("currency") ?: "Currency unspecified"
    fun pct(n:Double?,d:Double?):String = if(n!=null&&d!=null&&d>0) "${num(n/d*100)}%" else "Unavailable"
    val date=latest.optString("fiscal_date","Date unavailable"); var growth:String="Unavailable"
    val compareIndex=if(period=="annual") 1 else 4
    if(arr.length()>compareIndex) { val old=arr.optJSONObject(compareIndex); if(old!=null) try {
        val days=ChronoUnit.DAYS.between(LocalDate.parse(old.getString("fiscal_date")),LocalDate.parse(date));val prev=value(old,"sales")
        if(days in 330..400 && prev!=null && prev>0 && sales!=null) growth="${relative((sales/prev-1)*100)} YoY"
    } catch(_:Exception) {} }
    Panel(Modifier.fillMaxWidth()) {
        Kicker("DERIVED FROM INCOME STATEMENT");Spacer(Modifier.height(5.dp));Muted("Period ending $date · reported currency $currency")
        Spacer(Modifier.height(10.dp)); listOf("Revenue" to (sales?.let{num(it,0)}?:"Unavailable"),"Revenue growth" to growth,"Gross margin" to pct(gross,sales),"Operating margin" to pct(op,sales),"Net margin" to pct(net,sales)).forEach { (label,v)->Row(Modifier.fillMaxWidth().padding(vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween){Muted(label);Text(v,style=MaterialTheme.typography.bodySmall,fontWeight=FontWeight.SemiBold)} }
        Spacer(Modifier.height(6.dp));Muted("Margins = stated profit ÷ sales. Growth compares the matching period one year earlier only when available.")
    }
}
@Composable fun JsonRows(value:Any?,depth:Int) {
    when(value) {
        is JSONObject -> value.keys().asSequence().toList().sortedWith(compareBy<String>{ if(it=="fiscal_date") 0 else 1 }.thenBy{it}).forEach { k ->
            val v=value.opt(k); if(v is JSONObject || v is JSONArray) {
                Spacer(Modifier.height(9.dp)); Text(k.replace('_',' ').replaceFirstChar{it.uppercase()},fontWeight=FontWeight.SemiBold,style=MaterialTheme.typography.labelLarge,color=MaterialTheme.colorScheme.primary); JsonRows(v,depth+1)
            } else Row(Modifier.fillMaxWidth().padding(vertical=3.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                Text(k.replace('_',' '),Modifier.weight(.5f),style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if(v==JSONObject.NULL) "—" else v?.toString() ?: "—",Modifier.weight(.5f),style=MaterialTheme.typography.bodySmall)
            }
        }
        is JSONArray -> for(i in 0 until minOf(value.length(),6)) { if(i>0) HorizontalDivider(Modifier.padding(vertical=7.dp));JsonRows(value.opt(i),depth+1) }
        else -> Text(value?.toString() ?: "—",style=MaterialTheme.typography.bodySmall)
    }
}
