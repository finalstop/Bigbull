package com.bigbull.research

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.*

private val researchUniverse=listOf(Instrument("RELIANCE","NSE","Reliance Industries"),Instrument("INFY","NSE","Infosys"),Instrument("SWIGGY","NSE","Swiggy"),Instrument("TCS","NSE","Tata Consultancy Services"))
@Composable fun PremiumMarkets(app:AppState){
    var section by remember{mutableIntStateOf(0)};var query by remember{mutableStateOf("")};var losers by remember{mutableStateOf(false)};var eventTab by remember{mutableIntStateOf(0)}
    LaunchedEffect(Unit){app.loadEvents();if(app.snapshot==null)app.loadMarket();if(app.mood==null)app.loadMood();if(app.headlines.isEmpty())app.loadNews();researchUniverse.forEach{if(app.quotes[it.id]==null)app.loadQuote(it)}}
    Column(Modifier.fillMaxSize()){
        TerminalTabs(listOf("Markets","Fear & Greed","Screener","Events"),section){section=it}
        if(section==2){ScreenerPage(app);return@Column}
        if(section==3){EventsPage(app,eventTab);return@Column}
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).glassClearance().padding(horizontal=20.dp,vertical=18.dp),verticalArrangement=Arrangement.spacedBy(22.dp)){
            if(section==1){MoodPanel(app);return@Column}
            TextField(query,{query=it},Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp),singleLine=true,textStyle=MaterialTheme.typography.bodyMedium,
                placeholder={Text("Search companies or symbols",style=MaterialTheme.typography.bodyMedium)},
                leadingIcon={Icon(Icons.Outlined.Search,null,Modifier.size(20.dp))},
                trailingIcon={TextButton(onClick={app.search(query)},enabled=query.trim().length>=2){Text("Search",fontSize=12.sp)}},
                keyboardOptions=KeyboardOptions(imeAction=ImeAction.Search),keyboardActions=KeyboardActions(onSearch={if(query.trim().length>=2)app.search(query)}),
                colors=TextFieldDefaults.colors(focusedContainerColor=MaterialTheme.colorScheme.surface,unfocusedContainerColor=MaterialTheme.colorScheme.surface,focusedIndicatorColor=androidx.compose.ui.graphics.Color.Transparent,unfocusedIndicatorColor=androidx.compose.ui.graphics.Color.Transparent))
            if(app.searchResults.isNotEmpty())Column{app.searchResults.take(6).forEach{s->StockRow(app,s){app.searchResults=emptyList();app.openStock(s)}}}
            Panel(Modifier.fillMaxWidth()){
                Row(verticalAlignment=Alignment.CenterVertically){Text("Market breadth",Modifier.weight(1f),style=MaterialTheme.typography.titleMedium);TextButton(onClick={app.loadMarket()},contentPadding=PaddingValues(0.dp)){Text("Refresh",fontSize=12.sp)}}
                val market=app.snapshot
                if(market==null){Muted(app.marketError?:"Loading NSE closing data…")}else{
                    val date=runCatching{market.date.format(java.time.format.DateTimeFormatter.ofPattern("d MMM yyyy",java.util.Locale.ENGLISH))}.getOrDefault(market.date.toString())
                    Text("$date · NSE closing file",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
                        BreadthNumber("Advances",market.advances,Positive);BreadthNumber("Declines",market.declines,Negative);BreadthNumber("Unchanged",market.unchanged,MaterialTheme.colorScheme.onSurface)
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),horizontalArrangement=Arrangement.spacedBy(2.dp)){
                        if(market.advances>0)Box(Modifier.weight(market.advances.toFloat()).fillMaxHeight().background(Positive))
                        if(market.declines>0)Box(Modifier.weight(market.declines.toFloat()).fillMaxHeight().background(Negative))
                        if(market.unchanged>0)Box(Modifier.weight(market.unchanged.toFloat()).fillMaxHeight().background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha=.35f)))
                    }
                }
            }
            Column{
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Market movers",Modifier.weight(1f),style=MaterialTheme.typography.titleMedium)
                    SmallChip("Gainers",!losers){losers=false};Spacer(Modifier.width(6.dp));SmallChip("Losers",losers){losers=true}
                }
                Spacer(Modifier.height(8.dp))
                val rows=app.snapshot?.entries?.let{if(losers)it.sortedBy{it.change}else it.sortedByDescending{it.change}}?.take(3).orEmpty()
                if(rows.isEmpty())Muted("Movers appear when the NSE file is available.")
                rows.forEach{e->Row(Modifier.fillMaxWidth().clickable{app.openStock(e.stock)}.padding(vertical=14.dp),verticalAlignment=Alignment.CenterVertically){
                    CompanyLogo(e.stock,28.dp);Spacer(Modifier.width(10.dp));Text(e.symbol,Modifier.weight(1f),fontSize=14.sp,fontWeight=FontWeight.Medium,maxLines=1)
                    Text(money(e.close),Modifier.width(98.dp),fontSize=14.sp,textAlign=androidx.compose.ui.text.style.TextAlign.End)
                    Text(relative(e.change),Modifier.width(84.dp),fontSize=13.sp,fontWeight=FontWeight.Medium,textAlign=androidx.compose.ui.text.style.TextAlign.End,color=if(e.change>=0)Positive else Negative)
                };HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.35f))}
            }
            Column{SectionTitle("Research a stock");Spacer(Modifier.height(8.dp));researchUniverse.forEach{s->StockRow(app,s){app.openStock(s)}}}
            Panel(Modifier.fillMaxWidth()){
                Row(Modifier.fillMaxWidth().clickable{section=1},verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){Text("Market mood",style=MaterialTheme.typography.titleMedium);app.mood?.let{Muted(it.zone)}?:Muted(app.moodError?:"Loading sentiment…")}
                    app.mood?.let{Text(num(it.score,1),fontSize=28.sp,fontWeight=FontWeight.Medium,color=MaterialTheme.colorScheme.primary)}
                    Spacer(Modifier.width(12.dp));Text("›",fontSize=24.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
                app.mood?.let{Spacer(Modifier.height(10.dp));Muted("Tickertape · ${it.date} · published MMI")}
            }
            CalendarPreview(app){eventTab=it;section=3}
            Column{SectionTitle("Latest headlines");Spacer(Modifier.height(8.dp));app.headlines.take(3).forEach{h->Column(Modifier.fillMaxWidth().clickable{app.article=h}.padding(vertical=14.dp)){
                Text(h.source.uppercase(),fontSize=10.sp,letterSpacing=.8.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(5.dp));Text(h.title,fontSize=15.sp,lineHeight=22.sp,fontWeight=FontWeight.Medium,maxLines=3)
            };HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.35f))};if(app.headlines.isEmpty())Muted(app.newsError?:"Loading headlines…")}
            Spacer(Modifier.height(8.dp))
        }
    }
}
@Composable private fun BreadthNumber(label:String,value:Int,tone:androidx.compose.ui.graphics.Color){Column{Text(num(value.toDouble(),0),fontSize=23.sp,fontWeight=FontWeight.Medium,color=tone);Spacer(Modifier.height(3.dp));Text(label,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
