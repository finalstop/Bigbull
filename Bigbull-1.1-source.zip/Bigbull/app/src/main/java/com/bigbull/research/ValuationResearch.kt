package com.bigbull.research

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.pow
import kotlin.math.sqrt

/** Values always retain their original reporting currency and fiscal period. */
data class ValuationFacts(val price:Double?,val priceDate:String,val income:JSONObject?,val balance:JSONObject?,val cash:JSONObject?){
    fun rows(j:JSONObject?,endpoint:String):List<JSONObject>{val a=j?.optJSONArray(endpoint)?:return emptyList();return (0 until a.length()).map{a.getJSONObject(it)}.sortedByDescending{it.optString("fiscal_date")}}
    val incomes get()=rows(income,"income_statement")
    val i get()=incomes.firstOrNull()
    val b get()=rows(balance,"balance_sheet").firstOrNull()
    val f get()=rows(cash,"cash_flow").firstOrNull()
    fun number(j:JSONObject?,key:String)=j?.optString(key)?.toDoubleOrNull()?.takeIf{it.isFinite()}
    fun currency(j:JSONObject?)=j?.optJSONObject("meta")?.optString("currency")
    fun date(j:JSONObject?)=j?.optString("fiscal_date").orEmpty()
    fun aligned(a:JSONObject?,ar:JSONObject?,b:JSONObject?,br:JSONObject?)=a!=null&&b!=null&&ar!=null&&br!=null&&currency(a)==currency(b)&&!currency(a).isNullOrBlank()&&date(ar)==date(br)
    val eps get()=number(i,"diluted_eps")
    val pe get()=if(currency(income)=="INR"&&price!=null&&price>0&&eps!=null&&eps!!>0)price/eps!! else null
    val shares get()=number(b,"ordinary_shares")?.takeIf{it>0}
    val bookPerShare get()=number(b,"stockholders_equity")?.takeIf{it>0}?.let{e->shares?.let{e/it}}
    val pb get()=if(currency(balance)=="INR"&&price!=null&&price>0)bookPerShare?.let{price/it} else null
    val debtEquity get()=PeerFacts.debtEquity(b)
    val currentRatio get()=number(b,"current_assets")?.let{a->number(b,"current_liabilities")?.takeIf{it>0}?.let{a/it}}
    val roe:Double? get(){
        val bs=rows(balance,"balance_sheet");val prev=bs.getOrNull(1)
        if(!aligned(income,i,balance,b)||prev==null||!yearApart(date(prev),date(b)))return null
        val e=number(b,"stockholders_equity")?.takeIf{it>0}?:return null;val old=number(prev,"stockholders_equity")?.takeIf{it>0}?:return null
        return number(i,"net_income")?.div((e+old)/2)?.times(100)
    }
    val epsGrowth:Double? get(){
        val latest=i?:return null
        val old=incomes.lastOrNull{r->val years=runCatching{ChronoUnit.DAYS.between(LocalDate.parse(date(r)),LocalDate.parse(date(latest)))/365.25}.getOrDefault(0.0);years in 2.8..5.2}?:return null
        val end=eps?.takeIf{it>0}?:return null;val start=number(old,"diluted_eps")?.takeIf{it>0}?:return null
        val years=ChronoUnit.DAYS.between(LocalDate.parse(date(old)),LocalDate.parse(date(latest)))/365.25
        return ((end/start).pow(1/years)-1)*100
    }
    val peg get()=epsGrowth?.takeIf{it>0}?.let{g->pe?.div(g)}
    val graham get()=if(aligned(income,i,balance,b)&&currency(income)=="INR")eps?.takeIf{it>0}?.let{e->bookPerShare?.let{sqrt(22.5*e*it)}} else null
    val fcf get()=number(f,"free_cash_flow")
    val fcfPerShare get()=if(aligned(cash,f,balance,b)&&currency(cash)=="INR")fcf?.takeIf{it>0}?.let{v->shares?.let{v/it}} else null
    fun earningsToCash():Double?=if(aligned(income,i,cash,f))number(i,"net_income")?.takeIf{it>0}?.let{net->number(f,"operating_cash_flow")?.div(net)} else null
    companion object {
        fun from(app:AppState,s:Instrument):ValuationFacts{
            val q=app.quotes[s.id];val c=app.series(s)?.candles?.lastOrNull()
            return ValuationFacts(q?.price?:c?.close,q?.asOf?:c?.time?:"Unavailable",PeerFacts.report(app,s,"income_statement"),PeerFacts.report(app,s,"balance_sheet"),PeerFacts.report(app,s,"cash_flow"))
        }
        fun yearApart(a:String,b:String)=runCatching{ChronoUnit.DAYS.between(LocalDate.parse(a),LocalDate.parse(b)) in 330..400}.getOrDefault(false)
    }
}
object EquityScenario {
    data class Assumptions(val title:String,val growth:Double,val discount:Double,val terminal:Double)
    val presets=listOf(Assumptions("Cautious",0.0,.13,.025),Assumptions("Central",.05,.12,.03),Assumptions("Optimistic",.10,.11,.035))
    // Reported CFO minus capex already reflects interest. Zero net new borrowing and constant shares are explicit assumptions.
    fun value(fcfPerShare:Double,a:Assumptions):Double{
        require(fcfPerShare>0&&fcfPerShare.isFinite())
        require(listOf(a.growth,a.discount,a.terminal).all{it.isFinite()}&&a.discount>a.terminal&&a.discount>0&&a.growth> -1&&a.terminal> -1)
        val v=(1..5).sumOf{year->fcfPerShare*(1+a.growth).pow(year)/(1+a.discount).pow(year)}+
            fcfPerShare*(1+a.growth).pow(5)*(1+a.terminal)/(a.discount-a.terminal)/(1+a.discount).pow(5)
        require(v.isFinite());return v
    }
}
@Composable fun ValuationQuickFacts(app:AppState,stock:Instrument){
    val v=ValuationFacts.from(app,stock)
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){
        Panel(Modifier.weight(1f)){Muted("P/E · annual");Text(v.pe?.let{num(it,1)+"×"}?:"—",fontSize=23.sp,fontWeight=FontWeight.SemiBold);Muted(v.date(v.i).ifBlank{"Awaiting earnings"})}
        Panel(Modifier.weight(1f)){Muted("Price / book");Text(v.pb?.let{num(it,1)+"×"}?:"—",fontSize=23.sp,fontWeight=FontWeight.SemiBold);Muted(v.date(v.b).ifBlank{"Awaiting balance sheet"})}
    }
}
@Composable fun IntrinsicValuePanel(app:AppState,stock:Instrument){
    val v=ValuationFacts.from(app,stock)
    SectionTitle("Valuation"){TextButton(onClick={app.refreshResearch(listOf(stock))},enabled=!app.researchLoading){Text(if(app.researchLoading)"Updating…" else "Refresh")}}
    Muted("Company figures, visible assumptions.")
    Spacer(Modifier.height(16.dp));ValuationQuickFacts(app,stock)
    Spacer(Modifier.height(12.dp));Muted("Price: ${v.price?.let{money(it)}?:"unavailable"} · ${CheckpointFacts.stamp(v.priceDate)}. Annual EPS: ${v.eps?.let{num(it)}?:"unavailable"} ${v.currency(v.income).orEmpty()}. P/E = price ÷ annual diluted EPS; not TTM or forward P/E. Losses and currency mismatches show —.")
    Spacer(Modifier.height(24.dp));Text("Intrinsic value scenarios",style=MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(6.dp));Muted("Five-year discounted equity cash flow · model estimates")
    val base=v.fcfPerShare
    // Finance businesses need regulatory-capital/dividend models; this FCF tool must not imply suitability.
    var suitable by remember(stock.id){mutableStateOf(false)}
    Row(verticalAlignment=Alignment.CenterVertically){Checkbox(suitable,{suitable=it});Text("Use a cash-flow model for this non-financial business",style=MaterialTheme.typography.bodySmall)}
    if(base==null){EmptyPanel("Cash-flow inputs unavailable","Needs positive annual INR free cash flow and reported ordinary shares from the same fiscal date. Refresh to fetch the expanded report. No financial values need to be typed in.")}
    else if(suitable){
        EquityScenario.presets.forEach{a->
            val value=EquityScenario.value(base,a)
            Row(Modifier.fillMaxWidth().padding(vertical=13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(a.title,fontWeight=FontWeight.SemiBold);Muted("Growth ${num(a.growth*100,1)}% · discount ${num(a.discount*100,1)}%")};Text(money(value),fontSize=23.sp,fontWeight=FontWeight.SemiBold)}
            HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.3f))
        }
        Spacer(Modifier.height(10.dp));Muted("Starting FCF/share ${money(base)} · ${v.date(v.f)}. Scenario assumptions are Bigbull presets, not analyst forecasts or a buy/sell signal. Estimates can differ substantially from realizable value.")
    }else Muted("Confirm model suitability to view scenarios. Banks, insurers and lenders require different valuation models.")
    Spacer(Modifier.height(14.dp));AnalysisRow("Formula & assumptions","View","Value/share = Σ [FCF/share × (1+g)^t ÷ (1+r)^t], t=1…5, plus year-5 FCF/share × (1+terminal growth) ÷ (r−terminal growth) ÷ (1+r)^5. Starting cash flow is reported operating cash flow less capital expenditure, after interest, used as an equity-cash-flow proxy. Assumes no net new debt, no dilution and constant shares; debt is not subtracted again. Terminal growth: cautious 2.5%, central 3%, optimistic 3.5%. Maintenance capex and future financing are not independently verified. Check share splits and source statements before interpreting.")
    AnalysisRow("Graham value reference",v.graham?.let{money(it)}?:"Unavailable","√(22.5 × positive EPS × positive book value/share), using annual diluted EPS and same-date ordinary shares/equity. A valuation reference inspired by Graham's earnings/book-price limit, not a complete defensive-investor screen. Latest annual EPS is used here instead of his three-year average. Intangible assets and business quality still need review.")
    AnalysisRow("Debt / equity",v.debtEquity?.let{num(it)+"×"}?:"Unavailable","Reported total debt ÷ stockholders' equity. Fiscal date ${v.date(v.b)}. Equity must be positive.")
    AnalysisRow("Historical PEG",v.peg?.let{num(it)+"×"}?:"Unavailable","Annual P/E ÷ positive diluted-EPS CAGR expressed in percentage points. Uses the longest supplied span around 3–5 years, not a growth forecast. EPS CAGR: ${v.epsGrowth?.let{num(it)+"%"}?:"unavailable"}.")
    AnalysisRow("Source figures","View","Income: ${v.date(v.i)} ${v.currency(v.income)}. Cash flow: ${v.date(v.f)} ${v.currency(v.cash)}. Balance: ${v.date(v.b)} ${v.currency(v.balance)}. Reported ordinary shares: ${v.shares?.let{num(it,0)}?:"missing"}; annual FCF: ${v.fcf?.let{num(it,0)}?:"missing"}. Same-period and same-currency checks prevent incompatible calculations. Older reports remain dated; they may not describe today's business.")
    SourceLink("Original company financials","https://finance.yahoo.com/quote/${YahooHistory.ticker(stock)}/financials/")
    SourceLink("Buffett on intrinsic value","https://www.berkshirehathaway.com/2001ar/ownersmanual.html")
}
