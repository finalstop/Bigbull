package com.bigbull.research

import android.content.Context
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import java.time.Instant

class AppState(context: Context) {
    val vault=Vault(context); val db=Storage(context); private val free=FreeMarketData()
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main)
    var lists by mutableStateOf(db.lists()); var listId by mutableLongStateOf(lists.first().id)
    var stocks by mutableStateOf(db.stocks(listId)); var trades by mutableStateOf(db.trades())
    var selected by mutableStateOf<Instrument?>(null); var interval by mutableStateOf("1day")
    var isLoading by mutableStateOf(false); var message by mutableStateOf<String?>(null)
    var searchResults by mutableStateOf<List<Instrument>>(emptyList())
    var dark by mutableStateOf(vault.dark); var cache by mutableStateOf(vault.cacheProvider)
    val quotes=mutableStateMapOf<String,SessionQuote>()
    val quoteErrors=mutableStateMapOf<String,String>()
    private val quoteJobs=mutableSetOf<String>()
    var article by mutableStateOf<Headline?>(null)
    var headlines by mutableStateOf<List<Headline>>(emptyList())
    var newsLoading by mutableStateOf(false);var newsError by mutableStateOf<String?>(null);var newsFetched by mutableStateOf<String?>(null)
    var mood by mutableStateOf<MoodReading?>(null);var moodLoading by mutableStateOf(false);var moodError by mutableStateOf<String?>(null)
    var snapshot by mutableStateOf(db.snapshot())
    var marketError by mutableStateOf<String?>(null)
    private val session=mutableStateMapOf<String,Series>(); private val reports=mutableStateMapOf<String,Pair<String,String>>()
    private fun key(s: Instrument,i: String)=s.id+":"+i
    fun series(s: Instrument,i: String="1day"): Series? = session[key(s,i)] ?: db.series(s,i)
    fun addStock(s: Instrument) { db.addStock(listId,s); stocks=db.stocks(listId) }
    fun removeStock(s: Instrument) { db.removeStock(listId,s); stocks=db.stocks(listId) }
    fun chooseList(id: Long) { listId=id; stocks=db.stocks(id) }
    fun addList(name: String) = safely { db.addList(name); lists=db.lists(); chooseList(lists.last().id) }
    fun removeList() = safely { db.removeList(listId); lists=db.lists(); chooseList(lists.first().id) }
    fun addTrade(t: Trade) = safely { db.addTrade(t); trades=db.trades(); message="Transaction saved on this device." }
    fun deleteTrade(id: Long) = safely { db.removeTrade(id); trades=db.trades(); message="Transaction removed." }
    fun changeDark(v: Boolean) { dark=v; vault.dark=v }
    fun changeCache(v: Boolean) { cache=v; vault.cacheProvider=v; if(!v) { db.clearProviderCache(); session.entries.removeAll { it.value.source!="User CSV" }; reports.clear(); snapshot=null } }
    fun search(q: String) {
        searchResults=emptyList()
        val local=snapshot?.entries?.filter{it.symbol.contains(q.trim(),true)}?.take(30)?.map{it.stock}.orEmpty()
        if(q.trim().length>=2 && local.isNotEmpty()) {searchResults=local;return}
        runAsync({free.search(q)}, { searchResults=it; if(it.isEmpty()) message="No NSE or BSE matches. Try the NSE ticker or add a symbol manually." })
    }
    fun openStock(s:Instrument) {
        selected=s;interval="1day";loadQuote(s)
        scope.launch {isLoading=true;try {
            if(series(s)==null)try{val raw=withContext(Dispatchers.IO){free.candles(s,"1day")};session[key(s,"1day")]=raw.copy(persisted=cache);if(cache)db.saveSeries(raw)}catch(e:Exception){message=e.message}
            for(endpoint in listOf("income_statement","balance_sheet","cash_flow")) if(report(s,endpoint,"annual")==null)try{val r=withContext(Dispatchers.IO){free.report(s,endpoint,"annual")};reports[reportKey(s,endpoint,"annual")]=r;if(cache)db.saveStatement(s,endpoint,"annual",r.first,r.second)}catch(e:Exception){message="Some financial statements are unavailable: ${e.message}"}
        }finally{isLoading=false}}
    }
    fun loadQuote(s:Instrument){if(!quoteJobs.add(s.id))return;quoteErrors.remove(s.id);scope.launch{try{quotes[s.id]=withContext(Dispatchers.IO){SameDaySource.load(s)}}catch(e:Exception){quoteErrors[s.id]=e.message ?: "Quote unavailable."}finally{quoteJobs.remove(s.id)}}}
    fun loadNews(){if(newsLoading)return;newsLoading=true;newsError=null;scope.launch{try{val batch=withContext(Dispatchers.IO){NewsFeed.loadAll()};headlines=batch.items;newsError=batch.errors.takeIf{it.isNotEmpty()}?.joinToString(" · ");newsFetched=Instant.now().toString()}catch(e:Exception){newsError=e.message ?: "News feed unavailable."}finally{newsLoading=false}}}
    fun loadMood(){if(moodLoading)return;moodLoading=true;moodError=null;scope.launch{try{mood=withContext(Dispatchers.IO){MoodSource.load()}}catch(e:Exception){moodError=e.message ?: "Market inputs unavailable."}finally{moodLoading=false}}}
    fun loadMarket() {
        if(isLoading) return
        marketError=null;isLoading=true
        scope.launch {try{val result=withContext(Dispatchers.IO){free.snapshot()};snapshot=result;if(cache)db.saveSnapshot(result)}
            catch(e:Exception){marketError=e.message ?: "NSE daily file is unavailable."}
            finally{isLoading=false}}
    }
    fun sync(s: Instrument,i: String) { runAsync({free.candles(s,i)}, { raw ->
        val value=raw.copy(persisted=cache); if(cache) db.saveSeries(value); session[key(s,i)]=value
        message="${s.symbol}: ${value.candles.size} candles loaded. Latest ${value.candles.last().time}."
    }) }
    fun imported(s: Instrument,contents: String) = safely {
        val data=CsvCandles.parse(contents); val series=Series(s,"1day",data,"User CSV",Instant.now().toString(),true)
        db.saveSeries(series); session[key(s,"1day")]=series; interval="1day"; message="Imported ${data.size} candles for ${s.symbol}."
    }
    private fun reportKey(s: Instrument,endpoint: String,period: String)="${s.id}:$endpoint:$period"
    fun report(s: Instrument,endpoint: String,period: String): Pair<String,String>? = reports[reportKey(s,endpoint,period)] ?: db.statement(s,endpoint,period)
    fun loadReport(s: Instrument,endpoint: String,period: String) { runAsync({free.report(s,endpoint,period)}, {
        reports[reportKey(s,endpoint,period)]=it; if(cache) db.saveStatement(s,endpoint,period,it.first,it.second); message="Public financial report loaded. Check the reporting currency and fiscal date."
    }) }
    private fun safely(block: () -> Unit) { try { block() } catch(e: Exception) { message=e.message ?: "Something went wrong." } }
    private fun <T> runAsync(work: () -> T,done:(T)->Unit) { if(isLoading) return; isLoading=true; scope.launch {
        try { val result=withContext(Dispatchers.IO) { work() }; done(result) }
        catch(e: Exception) { message=e.message ?: "Network request failed. Check your connection or try again later." }
        finally { isLoading=false }
    } }
    val peerLoading=mutableStateMapOf<String,Boolean>()
    val peerErrors=mutableStateMapOf<String,String>()
    fun loadPeer(s:Instrument){
        loadQuote(s);if(peerLoading[s.id]==true)return;peerLoading[s.id]=true;peerErrors.remove(s.id)
        scope.launch{try{for(e in listOf("income_statement","balance_sheet")){val r=withContext(Dispatchers.IO){free.report(s,e,"annual")};reports[reportKey(s,e,"annual")]=r;if(cache)db.saveStatement(s,e,"annual",r.first,r.second)}}catch(e:Exception){peerErrors[s.id]=e.message?:"Peer data unavailable"}finally{peerLoading[s.id]=false}}
    }
    var researchLoading by mutableStateOf(false)
    var researchProgress by mutableStateOf("")
    val researchErrors=mutableStateMapOf<String,String>()
    fun refreshResearch(universe:List<Instrument>){
        if(researchLoading)return
        val targets=universe.distinctBy{it.id}.take(20)
        researchLoading=true;researchErrors.clear()
        scope.launch {try{targets.forEachIndexed{index,s->
            researchProgress="${index+1}/${targets.size} · ${s.symbol}"
            loadQuote(s)
            try{val raw=withContext(Dispatchers.IO){free.candles(s,"1day")};session[key(s,"1day")]=raw.copy(persisted=cache);if(cache)db.saveSeries(raw)}catch(e:Exception){researchErrors[s.id]=e.message?:"History unavailable"}
            for(endpoint in listOf("income_statement","balance_sheet","cash_flow"))try{val r=withContext(Dispatchers.IO){free.report(s,endpoint,"annual")};reports[reportKey(s,endpoint,"annual")]=r;if(cache)db.saveStatement(s,endpoint,"annual",r.first,r.second)}catch(e:Exception){researchErrors[s.id]=e.message?:"Report unavailable"}
        }}finally{researchLoading=false;researchProgress="Research updated · ${targets.size} companies"}}
    }
    val scanner=UniverseScanner(this,scope)
    private val scanSeriesOrder=java.util.ArrayDeque<String>();private val scanReportOrder=java.util.ArrayDeque<String>()
    fun acceptSeries(s:Series){session[key(s.stock,s.interval)]=s.copy(persisted=cache);if(cache)db.saveSeries(s);val id=key(s.stock,s.interval);scanSeriesOrder.remove(id);scanSeriesOrder.addLast(id);while(scanSeriesOrder.size>160){val old=scanSeriesOrder.removeFirst();if(session[old]?.source!="User CSV")session.remove(old)}}
    fun acceptReport(s:Instrument,e:String,p:String,r:Pair<String,String>){reports[reportKey(s,e,p)]=r;if(cache)db.saveStatement(s,e,p,r.first,r.second);val id=reportKey(s,e,p);scanReportOrder.remove(id);scanReportOrder.addLast(id);while(scanReportOrder.size>360)reports.remove(scanReportOrder.removeFirst())}
    val events=mutableStateMapOf<String,List<CorporateEvent>>()
    val eventErrors=mutableStateMapOf<String,String>();val eventFetched=mutableStateMapOf<String,String>()
    var eventsLoading by mutableStateOf(false)
    fun loadEvents(force:Boolean=false){if(eventsLoading||(!force&&events.size==2))return;eventsLoading=true
        scope.launch{try{coroutineScope{listOf("results","dividend").map{kind->launch{
            if(cache&&events[kind]==null)db.publicCache("events:"+kind)?.let{saved->runCatching{events[kind]=CorporateCalendar.parse(saved.second,kind);eventFetched[kind]=saved.first}}
            try{val body=withContext(Dispatchers.IO){ReaderSource.bytes(CorporateCalendar.url(kind)).toString(Charsets.UTF_8)};events[kind]=CorporateCalendar.parse(body,kind);val stamp=Instant.now().toString();eventFetched[kind]=stamp;eventErrors.remove(kind);if(cache)db.savePublic("events:"+kind,stamp,body)}catch(e:CancellationException){throw e}catch(e:Exception){eventErrors[kind]=e.message?:"Announcements unavailable"}
        }}.joinAll()}}finally{eventsLoading=false}}
    }
    var annualDocument by mutableStateOf<AnnualDocument?>(null)
    fun dispose() { scope.cancel(); db.close() }
}
