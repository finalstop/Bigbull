package com.bigbull.research

import android.content.Context
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
import java.security.KeyStore
import java.time.LocalDate
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class Vault(private val context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun checkpoint(id:String):String?=prefs.getString("checkpoint:"+id,null)
    fun saveCheckpoint(id:String,value:String){prefs.edit().putString("checkpoint:"+id,value).apply()}
    var cacheProvider: Boolean
        get()=prefs.getBoolean("cacheProvider",false)
        set(v){ prefs.edit().putBoolean("cacheProvider",v).apply() }
    var dark: Boolean
        get()=prefs.getBoolean("dark",true)
        set(v){ prefs.edit().putBoolean("dark",v).apply() }
}

data class Watchlist(val id: Long, val name: String)
class Storage(context: Context): SQLiteOpenHelper(context,"bigbull.db",null,3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE lists(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE)")
        db.execSQL("CREATE TABLE items(list_id INTEGER NOT NULL, symbol TEXT NOT NULL, exchange TEXT NOT NULL, name TEXT NOT NULL, PRIMARY KEY(list_id,symbol,exchange), FOREIGN KEY(list_id) REFERENCES lists(id) ON DELETE CASCADE)")
        db.execSQL("CREATE TABLE series(symbol TEXT NOT NULL, exchange TEXT NOT NULL, name TEXT NOT NULL, interval TEXT NOT NULL, source TEXT NOT NULL, fetched TEXT NOT NULL, json TEXT NOT NULL, PRIMARY KEY(symbol,exchange,interval,source))")
        db.execSQL("CREATE TABLE statements(symbol TEXT NOT NULL, exchange TEXT NOT NULL, endpoint TEXT NOT NULL, period TEXT NOT NULL, fetched TEXT NOT NULL, json TEXT NOT NULL, PRIMARY KEY(symbol,exchange,endpoint,period))")
        db.execSQL("CREATE TABLE trades(id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, exchange TEXT NOT NULL, name TEXT NOT NULL, type TEXT NOT NULL, date TEXT NOT NULL, qty TEXT NOT NULL, price TEXT NOT NULL, fees TEXT NOT NULL)")
        db.execSQL("INSERT INTO lists(name) VALUES('Watchlist')")
        createSnapshot(db);createPublicCache(db)
    }
    override fun onConfigure(db: SQLiteDatabase) { super.onConfigure(db); db.setForeignKeyConstraintsEnabled(true) }
    private fun createSnapshot(db:SQLiteDatabase) {db.execSQL("CREATE TABLE IF NOT EXISTS market_snapshot(id INTEGER PRIMARY KEY, date TEXT NOT NULL, fetched TEXT NOT NULL, url TEXT NOT NULL, json TEXT NOT NULL)")}
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {if(oldVersion<2){createSnapshot(db);db.delete("statements",null,null)};if(oldVersion<3)createPublicCache(db)}
    private fun createPublicCache(db:SQLiteDatabase){db.execSQL("CREATE TABLE IF NOT EXISTS public_cache(id TEXT PRIMARY KEY, fetched TEXT NOT NULL, payload TEXT NOT NULL)")}
    fun savePublic(id:String,fetched:String,payload:String){writableDatabase.insertWithOnConflict("public_cache",null,ContentValues().apply{put("id",id);put("fetched",fetched);put("payload",payload)},SQLiteDatabase.CONFLICT_REPLACE)}
    fun publicCache(id:String):Pair<String,String>?=readableDatabase.rawQuery("SELECT fetched,payload FROM public_cache WHERE id=?",arrayOf(id)).use{c->if(c.moveToFirst())c.getString(0) to c.getString(1)else null}
    fun saveSnapshot(s:MarketSnapshot) {
        val rows=JSONArray();s.entries.forEach{rows.put(JSONArray().put(it.symbol).put(it.close).put(it.previous).put(it.volume))}
        writableDatabase.insertWithOnConflict("market_snapshot",null,ContentValues().apply{put("id",1);put("date",s.date.toString());put("fetched",s.fetchedAt);put("url",s.sourceUrl);put("json",rows.toString())},SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun snapshot():MarketSnapshot?=readableDatabase.rawQuery("SELECT date,fetched,url,json FROM market_snapshot WHERE id=1",null).use {c->
        if(!c.moveToFirst())null else {val a=JSONArray(c.getString(3));MarketSnapshot(LocalDate.parse(c.getString(0)),buildList{for(i in 0 until a.length()){val r=a.getJSONArray(i);add(MarketEntry(r.getString(0),r.getDouble(1),r.getDouble(2),r.getDouble(3))) }},c.getString(1),c.getString(2))}
    }
    fun lists(): List<Watchlist> = readableDatabase.rawQuery("SELECT id,name FROM lists ORDER BY id",null).use { c -> buildList { while(c.moveToNext()) add(Watchlist(c.getLong(0),c.getString(1))) } }
    fun addList(name: String) { require(name.trim().isNotEmpty()); writableDatabase.insertOrThrow("lists",null,ContentValues().apply{put("name",name.trim())}) }
    fun removeList(id: Long) { require(lists().size>1) { "Keep at least one watchlist." }; writableDatabase.delete("lists","id=?", arrayOf(id.toString())) }
    fun stocks(listId: Long): List<Instrument> = readableDatabase.rawQuery("SELECT symbol,exchange,name FROM items WHERE list_id=? ORDER BY symbol",arrayOf(listId.toString())).use { c -> buildList { while(c.moveToNext()) add(Instrument(c.getString(0),c.getString(1),c.getString(2))) } }
    fun addStock(listId: Long,s: Instrument) { writableDatabase.insertWithOnConflict("items",null,ContentValues().apply{put("list_id",listId);put("symbol",s.symbol);put("exchange",s.exchange);put("name",s.name)},SQLiteDatabase.CONFLICT_REPLACE) }
    fun removeStock(listId: Long,s: Instrument) { writableDatabase.delete("items","list_id=? AND symbol=? AND exchange=?",arrayOf(listId.toString(),s.symbol,s.exchange)) }
    fun saveSeries(s: Series) {
        val arr=JSONArray(); s.candles.forEach { c -> arr.put(JSONArray().put(c.time).put(c.open).put(c.high).put(c.low).put(c.close).put(c.volume)) }
        writableDatabase.insertWithOnConflict("series",null,ContentValues().apply { put("symbol",s.stock.symbol);put("exchange",s.stock.exchange);put("name",s.stock.name);put("interval",s.interval);put("source",s.source);put("fetched",s.fetchedAt);put("json",arr.toString()) },SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun series(s: Instrument,interval: String): Series? = readableDatabase.rawQuery("SELECT name,source,fetched,json FROM series WHERE symbol=? AND exchange=? AND interval=? ORDER BY fetched DESC LIMIT 1",arrayOf(s.symbol,s.exchange,interval)).use { c ->
        if(!c.moveToFirst()) null else { val arr=JSONArray(c.getString(3)); val candles=buildList { for(i in 0 until arr.length()) { val a=arr.getJSONArray(i); add(Candle(a.getString(0),a.getDouble(1),a.getDouble(2),a.getDouble(3),a.getDouble(4),a.getDouble(5))) } }; Series(s.copy(name=c.getString(0)),interval,candles,c.getString(1),c.getString(2),true) }
    }
    fun clearProviderCache() { writableDatabase.delete("series","source<>?",arrayOf("User CSV")); writableDatabase.delete("statements",null,null);writableDatabase.delete("market_snapshot",null,null);writableDatabase.delete("public_cache",null,null) }
    fun saveStatement(stock: Instrument,endpoint: String,period: String,fetched: String,json: String) { writableDatabase.insertWithOnConflict("statements",null,ContentValues().apply { put("symbol",stock.symbol);put("exchange",stock.exchange);put("endpoint",endpoint);put("period",period);put("fetched",fetched);put("json",json) },SQLiteDatabase.CONFLICT_REPLACE) }
    fun statement(stock: Instrument,endpoint: String,period: String): Pair<String,String>? = readableDatabase.rawQuery("SELECT fetched,json FROM statements WHERE symbol=? AND exchange=? AND endpoint=? AND period=?",arrayOf(stock.symbol,stock.exchange,endpoint,period)).use { c -> if(c.moveToFirst()) c.getString(0) to c.getString(1) else null }
    fun trades(): List<Trade> = readableDatabase.rawQuery("SELECT id,symbol,exchange,name,type,date,qty,price,fees FROM trades ORDER BY date,id",null).use { c -> buildList { while(c.moveToNext()) add(Trade(c.getLong(0),Instrument(c.getString(1),c.getString(2),c.getString(3)),TradeType.valueOf(c.getString(4)),LocalDate.parse(c.getString(5)),BigDecimal(c.getString(6)),BigDecimal(c.getString(7)),BigDecimal(c.getString(8)))) } }
    fun addTrade(t: Trade) {
        val existing=trades(); PortfolioMath.positions(existing + t.copy(id=(existing.maxOfOrNull{it.id} ?: 0)+1))
        writableDatabase.insertOrThrow("trades",null,ContentValues().apply { put("symbol",t.instrument.symbol);put("exchange",t.instrument.exchange);put("name",t.instrument.name);put("type",t.type.name);put("date",t.date.toString());put("qty",t.quantity.toPlainString());put("price",t.price.toPlainString());put("fees",t.fees.toPlainString()) })
    }
    fun removeTrade(id: Long) { val left=trades().filterNot{it.id==id}; PortfolioMath.positions(left); writableDatabase.delete("trades","id=?",arrayOf(id.toString())) }
}
