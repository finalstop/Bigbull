package com.bigbull.research

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class ResearchSignal(val title:String,val reading:String,val explanation:String,val positive:Boolean?=null)
object ResearchBrief {
    fun signals(c:List<Candle>):List<ResearchSignal> {
        if(c.isEmpty())return emptyList()
        val closes=c.map{it.close};val last=c.last();val sma=Indicators.sma(closes,50).last();val rsi=Indicators.rsi(closes).last();val atr=Indicators.atr(c).last()
        val average=if(c.size>=21)c.dropLast(1).takeLast(20).map{it.volume}.average() else null
        fun f(n:Double)=String.format(java.util.Locale.ROOT,"%.2f",n)
        return listOf(
            if(sma==null)ResearchSignal("Price trend","Needs more history","50 completed bars are needed for this trend comparison.") else ResearchSignal("Price trend",if(last.close>sma)"Above its recent average" else if(last.close<sma)"Below its recent average" else "At its recent average","The close (${f(last.close)}) is ${f(kotlin.math.abs(last.close/sma-1)*100)}% ${if(last.close>=sma)"above" else "below"} the average of 50 closes (${f(sma)}). This describes the past, not the next price move.",last.close>=sma),
            if(rsi==null)ResearchSignal("Momentum","Needs more history","RSI needs at least 15 completed closes.") else ResearchSignal("Momentum",when{rsi>=70->"Strong, potentially stretched";rsi<=30->"Weak, potentially stretched";else->"Within its usual RSI range"},"Wilder RSI (14) is ${f(rsi)} out of 100. Above 70 or below 30 flags stretched recent momentum. It does not predict a reversal; extremes can persist."),
            if(average==null || average<=0)ResearchSignal("Trading activity","No usable baseline","A positive average volume across the previous 20 bars is needed.") else ResearchSignal("Trading activity",if(last.volume/average>=1.5)"More activity than usual" else "No unusual volume spike","${f(last.volume/average)}× the previous 20-bar average. The latest bar is excluded from that baseline. The spike threshold is 1.5×; volume alone does not reveal buyer or seller intent."),
            if(atr==null)ResearchSignal("Price swings","Needs more history","ATR needs at least 14 completed bars.") else ResearchSignal("Price swings","${f(atr/last.close*100)}% of the latest close","Wilder ATR (14) is ${f(atr)}. It averages true ranges, including gaps. This describes recent movement size, not a forecast range or maximum loss.")
        )
    }
}
@Composable fun BriefPanel(app:AppState,stock:Instrument,series:Series?) {
    if(series==null){EmptyPanel("A useful brief starts with real data","Tap Load history to calculate trend, momentum and volume signals from this stock’s actual prices.");return}
    val c=series.candles;val age=ChronoUnit.DAYS.between(LocalDate.parse(c.last().time.take(10)),LocalDate.now(ZoneId.of("Asia/Kolkata")))
    Kicker("YOUR TWO-MINUTE BRIEF");Spacer(Modifier.height(8.dp));Text("What the numbers say",fontSize=23.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Muted("${series.interval} bars · ${c.last().time}. Tap any card to see why.")
    Spacer(Modifier.height(15.dp))
    ResearchBrief.signals(c).forEach{signal->SignalCard(signal);Spacer(Modifier.height(10.dp))}
    Spacer(Modifier.height(8.dp));Panel(Modifier.fillMaxWidth()){
        Kicker("EVIDENCE CHECK");Spacer(Modifier.height(8.dp));Text(if(age>5)"This history needs refreshing" else "Dates and sources, in view",fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(5.dp))
        Muted("${c.size} completed bars from ${c.first().time} to ${c.last().time}. Latest bar: $age calendar days old. Weekends and holidays are not separately classified.")
        Spacer(Modifier.height(7.dp));Muted("Source: ${series.source}. Retrieved ${series.fetchedAt}. ${if(series.persisted)"Saved for offline use." else "Available for this session."}")
        Spacer(Modifier.height(7.dp));Muted("These rules explain price behaviour. They do not score management, business quality or fair value. Explore Financials before drawing those conclusions.")
    }
    Spacer(Modifier.height(16.dp));SourceLink("Open original price history","https://finance.yahoo.com/quote/${stock.symbol}${if(stock.exchange=="NSE")".NS" else ".BO"}/history/")
}
@Composable private fun SignalCard(signal:ResearchSignal) {
    var expanded by remember(signal){mutableStateOf(false)}
    Panel(Modifier.fillMaxWidth().clickable{expanded=!expanded}){
        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Muted(signal.title);Spacer(Modifier.height(5.dp));Text(signal.reading,fontWeight=FontWeight.SemiBold,color=when(signal.positive){true->Positive;false->Negative;null->MaterialTheme.colorScheme.onSurface})};Text(if(expanded)"−" else "+",fontSize=22.sp,color=MaterialTheme.colorScheme.primary)}
        if(expanded){Spacer(Modifier.height(12.dp));Muted(signal.explanation)}
    }
}
