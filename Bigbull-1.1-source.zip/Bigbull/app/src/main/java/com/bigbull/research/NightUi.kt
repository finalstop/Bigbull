package com.bigbull.research

import androidx.compose.foundation.*
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

/** Values are source-backed readings, not subjective investment grades. */
@Composable fun ResearchReading(title:String,period:String,value:String,explanation:String){
    var expanded by remember(title){mutableStateOf(false)}
    val tone=when{value.startsWith("-")->Negative;value.startsWith("+")->Positive;else->MaterialTheme.colorScheme.onSurfaceVariant}
    Column(Modifier.fillMaxWidth().animateContentSize().clickable{expanded=!expanded}.padding(vertical=14.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){
            Box(Modifier.width(3.dp).height(30.dp).background(tone.copy(alpha=.7f)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)){Text(title,fontSize=15.sp,fontWeight=FontWeight.SemiBold);Text(period,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}
            Text(if(value=="Unavailable")"—" else value,color=tone,fontSize=18.sp,fontWeight=FontWeight.SemiBold)
            Spacer(Modifier.width(12.dp));Text(if(expanded)"−" else "⌄",color=MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if(expanded){Spacer(Modifier.height(10.dp));Text(explanation,fontSize=13.sp,lineHeight=19.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}
    }
    HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.22f))
}
