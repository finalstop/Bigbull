package com.bigbull.research

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.*
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.json.JSONObject

data class MarketEntry(val symbol:String,val close:Double,val previous:Double,val volume:Double) {
    val change get()=(close/previous-1)*100
    val stock get()=Instrument(symbol,"NSE")
}
data class MarketSnapshot(val date:LocalDate,val entries:List<MarketEntry>,val fetchedAt:String,val sourceUrl:String) {
    val advances get()=entries.count{it.close>it.previous}
    val declines get()=entries.count{it.close<it.previous}
    val unchanged get()=entries.size-advances-declines
}

object NseCsv {
    fun parse(text:String,expectedDate:LocalDate):List<MarketEntry> {
        val rows=CsvCandles.rows(text.removePrefix("\uFEFF")); require(rows.size>1){"NSE report is empty."}
        val header=rows.first().map{it.trim().uppercase()}
        fun col(s:String)=header.indexOf(s).also{require(it>=0){"NSE report format changed: missing $s."}}
        val sym=col("SYMBOL");val series=col("SERIES");val date=col("DATE1");val close=col("CLOSE_PRICE");val prev=col("PREV_CLOSE");val vol=col("TTL_TRD_QNTY")
        val format=DateTimeFormatter.ofPattern("dd-MMM-uuuu",Locale.ENGLISH)
        val result=rows.drop(1).mapNotNull { row ->
            require(row.size==header.size){"Malformed NSE report row."}
            if(row[series].trim()!="EQ") return@mapNotNull null
            require(LocalDate.parse(row[date].trim(),format)==expectedDate){"NSE report date did not match the requested date."}
            fun number(i:Int)=row[i].trim().toDoubleOrNull()?.takeIf{it.isFinite()} ?: error("Invalid NSE numeric value.")
            val c=number(close);val p=number(prev);val v=number(vol)
            require(c>0 && p>=0 && v>=0){"Invalid NSE price or volume."}
            // New listings without a comparable previous close cannot enter breadth/rankings.
            if(p==0.0) return@mapNotNull null
            MarketEntry(row[sym].trim(),c,p,v)
        }
        require(result.isNotEmpty() && result.map{it.symbol}.distinct().size==result.size){"NSE report has no eligible rows or duplicate symbols."}
        return result
    }
}

class PublicHttpError(val status:Int):Exception("Public data source returned HTTP $status. Try again later or import a CSV.")
object PublicHttp {
    fun get(url:String):String {
        val c=(URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout=12000;readTimeout=15000;instanceFollowRedirects=false
            setRequestProperty("User-Agent","Bigbull/1.0 (personal research)")
            setRequestProperty("Accept","application/json,text/csv;q=0.9,*/*;q=0.5")
        }
        try {
            if(c.responseCode !in 200..299) throw PublicHttpError(c.responseCode)
            return c.inputStream.bufferedReader().use { r ->
                val out=StringBuilder(); val buf=CharArray(8192)
                while(true){val n=r.read(buf);if(n<0)break;out.append(buf,0,n);require(out.length<=5_000_000){"Public response exceeded the 5 MB limit."}}
                out.toString()
            }
        } finally {c.disconnect()}
    }
}

object YahooHistory {
    fun ticker(s:Instrument):String {
        require(s.exchange in listOf("NSE","BSE")){"Only NSE and BSE are supported."}
        val suffix=if(s.exchange=="NSE") ".NS" else ".BO"
        require(!s.symbol.endsWith(".NS") && !s.symbol.endsWith(".BO")){"Enter the ticker without .NS or .BO; select its exchange separately."}
        return s.symbol+suffix
    }
    fun parse(json:String,stock:Instrument,interval:String,today:LocalDate):List<Candle> {
        require(interval in listOf("1day","1week","1month"))
        val chart=JSONObject(json).getJSONObject("chart")
        require(chart.isNull("error")){"Yahoo could not provide this symbol. Check its ticker or use CSV import."}
        val result=chart.getJSONArray("result").getJSONObject(0);val meta=result.getJSONObject("meta")
        require(meta.optString("symbol").equals(ticker(stock),true) && meta.optString("currency")=="INR"){"Source returned a different instrument or currency; response rejected."}
        val accepted=if(stock.exchange=="NSE") listOf("NSI","NSE") else listOf("BSE","BOM")
        require(meta.optString("exchangeName") in accepted){"Source exchange does not match; response rejected."}
        val times=result.getJSONArray("timestamp"); val q=result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0)
        val cutoff=when(interval){"1week"->today.with(java.time.DayOfWeek.MONDAY);"1month"->today.withDayOfMonth(1);else->today}
        val candles=buildList {
            for(i in 0 until times.length()) {
                if(times.isNull(i)) continue
                val date=Instant.ofEpochSecond(times.getLong(i)).atZone(ZoneId.of("Asia/Kolkata")).toLocalDate()
                // Never label today's still-changing bar or the current week/month as a completed close.
                if(!date.isBefore(cutoff)) continue
                val fields=listOf("open","high","low","close","volume")
                if(fields.any{q.getJSONArray(it).isNull(i)}) continue
                fun n(k:String)=q.getJSONArray(k).getDouble(i)
                add(Candle(date.toString(),n("open"),n("high"),n("low"),n("close"),n("volume")).also{it.validate()})
            }
        }.sortedBy{it.time}
        require(candles.isNotEmpty()){ "No completed price bars available. Try CSV import." }
        require(candles.map{it.time}.distinct().size==candles.size){"Duplicate source timestamps; response rejected."}
        return candles
    }
}

class FreeMarketData {
    fun report(stock:Instrument,endpoint:String,period:String):Pair<String,String> {
        require(period in listOf("annual","quarterly"))
        val fields=FreeFinancials.fields(endpoint)
        val ticker=URLEncoder.encode(YahooHistory.ticker(stock),"UTF-8")
        val types=fields.keys.joinToString(","){period+it}
        val now=Instant.now()
        val from=LocalDate.now(ZoneId.of("Asia/Kolkata")).minusYears(6).atStartOfDay(ZoneId.of("Asia/Kolkata")).toEpochSecond()
        val url="https://query1.finance.yahoo.com/ws/fundamentals-timeseries/v1/finance/timeseries/$ticker?type=$types&merge=false&period1=$from&period2=${now.epochSecond}"
        val parsed=FreeFinancials.parse(PublicHttp.get(url),stock,endpoint,period)
        return now.toString() to parsed.toString()
    }
    fun search(query:String):List<Instrument> {
        require(query.trim().length>=2){"Enter at least two characters."}
        val q=URLEncoder.encode(query.trim(),"UTF-8")
        val rows=JSONObject(PublicHttp.get("https://query1.finance.yahoo.com/v1/finance/search?q=$q&quotesCount=30&newsCount=0")).getJSONArray("quotes")
        return buildList {
            for(i in 0 until rows.length()) {
                val j=rows.getJSONObject(i);val symbol=j.optString("symbol")
                val ex=when {symbol.endsWith(".NS") && j.optString("exchange") in listOf("NSI","NSE")->"NSE";symbol.endsWith(".BO") && j.optString("exchange") in listOf("BSE","BOM")->"BSE";else->continue}
                if(j.optString("quoteType") !in listOf("EQUITY","ETF")) continue
                add(Instrument(symbol.dropLast(3),ex,j.optString("longname",j.optString("shortname"))))
            }
        }.distinctBy{it.id}
    }
    fun candles(stock:Instrument,interval:String,range:String="5y"):Series {
        require(range in listOf("2y","5y"))
        val mapped=mapOf("1day" to "1d","1week" to "1wk","1month" to "1mo")[interval] ?: error("Unsupported interval")
        val symbol=URLEncoder.encode(YahooHistory.ticker(stock),"UTF-8")
        val body=PublicHttp.get("https://query1.finance.yahoo.com/v8/finance/chart/$symbol?range=$range&interval=$mapped")
        val candles=YahooHistory.parse(body,stock,interval,LocalDate.now(ZoneId.of("Asia/Kolkata")))
        return Series(stock,interval,candles,"Yahoo Finance · public history",Instant.now().toString(),false)
    }
    fun snapshot():MarketSnapshot {
        val today=LocalDate.now(ZoneId.of("Asia/Kolkata")); val format=DateTimeFormatter.ofPattern("ddMMyyyy")
        for(back in 0L..9L) {
            val date=today.minusDays(back)
            val url="https://nsearchives.nseindia.com/products/content/sec_bhavdata_full_${date.format(format)}.csv"
            try {return MarketSnapshot(date,NseCsv.parse(PublicHttp.get(url),date),Instant.now().toString(),url)}
            catch(e:PublicHttpError){if(e.status!=404) throw e}
        }
        error("No NSE daily file was available in the last 10 calendar days. Previous data remains available; try later.")
    }
}

object FreeFinancials {
    fun fields(endpoint:String):Map<String,String> = when(endpoint) {
        "income_statement"->linkedMapOf("TotalRevenue" to "sales","GrossProfit" to "gross_profit","OperatingIncome" to "operating_income","NetIncome" to "net_income","DilutedEPS" to "diluted_eps","DilutedAverageShares" to "diluted_average_shares")
        "balance_sheet"->linkedMapOf("TotalAssets" to "total_assets","TotalDebt" to "total_debt","StockholdersEquity" to "stockholders_equity","CurrentAssets" to "current_assets","CurrentLiabilities" to "current_liabilities","CashAndCashEquivalents" to "cash_and_cash_equivalents","OrdinarySharesNumber" to "ordinary_shares")
        "cash_flow"->linkedMapOf("OperatingCashFlow" to "operating_cash_flow","FreeCashFlow" to "free_cash_flow","CapitalExpenditure" to "capital_expenditure","InvestingCashFlow" to "investing_cash_flow","FinancingCashFlow" to "financing_cash_flow")
        else->error("This report is not available from the free source.")
    }
    fun parse(body:String,stock:Instrument,endpoint:String,period:String):JSONObject {
        require(period in listOf("annual","quarterly"))
        val root=JSONObject(body).getJSONObject("timeseries")
        require(root.isNull("error")){"Financial data is unavailable for this symbol."}
        val result=root.optJSONArray("result") ?: error("No financial statements returned.")
        val rows=sortedMapOf<String,JSONObject>(reverseOrder());val currencies=mutableSetOf<String>();val fields=fields(endpoint)
        for(i in 0 until result.length()) {
            val item=result.getJSONObject(i);val meta=item.getJSONObject("meta")
            require(meta.getJSONArray("symbol").getString(0).equals(YahooHistory.ticker(stock),true)){"Financial response belongs to another instrument."}
            val type=meta.getJSONArray("type").getString(0)
            val metric=fields.entries.firstOrNull{period+it.key==type} ?: continue
            val values=item.optJSONArray(type) ?: continue
            for(n in 0 until values.length()) {
                if(values.isNull(n))continue
                val point=values.getJSONObject(n)
                require(point.optString("periodType")==if(period=="annual")"12M" else "3M"){"Financial period does not match the requested report."}
                val date=LocalDate.parse(point.getString("asOfDate")).toString()
                val currency=point.getString("currencyCode");require(currency.matches(Regex("[A-Z]{3}"))){"Report currency is missing."};currencies.add(currency)
                val value=point.getJSONObject("reportedValue").getDouble("raw");require(value.isFinite()){"Non-finite financial value."}
                val row=rows.getOrPut(date){JSONObject().put("fiscal_date",date)}
                require(!row.has(metric.value)){"Duplicate financial value in source."};row.put(metric.value,value)
            }
        }
        require(rows.isNotEmpty()){ "No financial figures were returned. Open the source website or try another period." }
        require(currencies.size==1){"Source mixes reporting currencies. Values were rejected to avoid incorrect comparisons."}
        return JSONObject().put("meta",JSONObject().put("symbol",stock.symbol).put("exchange",stock.exchange).put("currency",currencies.single()).put("source","Yahoo Finance public financial timeseries").put("source_url","https://finance.yahoo.com/quote/${YahooHistory.ticker(stock)}/financials/").put("period",period)).put(endpoint,org.json.JSONArray(rows.values.toList()))
    }
}
