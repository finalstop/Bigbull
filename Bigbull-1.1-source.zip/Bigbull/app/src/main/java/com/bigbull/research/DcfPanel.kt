package com.bigbull.research

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*

@Composable fun DcfPanel() {
    var fcf by remember {mutableStateOf("")}; var growth by remember {mutableStateOf("")}; var discount by remember {mutableStateOf("")}; var terminal by remember {mutableStateOf("")}; var debt by remember {mutableStateOf("")};var shares by remember {mutableStateOf("")};var result by remember {mutableStateOf<DcfCalculator.Result?>(null)};var error by remember {mutableStateOf("")}
    Column {
        Kicker("SCENARIO TOOL");Spacer(Modifier.height(6.dp));Text("Discounted cash flow",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp));Muted("Enter your own verified starting figures and assumptions. Bigbull does not generate forecasts. Use actual rupees, not crore, consistently in all monetary fields.")
        Spacer(Modifier.height(15.dp)); Panel(Modifier.fillMaxWidth()) {
            @Composable fun Field(label:String,value:String,change:(String)->Unit) { OutlinedTextField(value,{change(it);result=null;error=""},Modifier.fillMaxWidth().padding(vertical=4.dp),label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal)) }
            Field("Annual free cash flow (₹)",fcf){fcf=it}; Field("Annual FCF growth for 5 years (%)",growth){growth=it};Field("Discount rate (%)",discount){discount=it};Field("Terminal growth rate (%)",terminal){terminal=it};Field("Net debt (₹; negative if net cash)",debt){debt=it};Field("Diluted shares outstanding",shares){shares=it}
            Spacer(Modifier.height(8.dp)); PrimaryButton("Calculate scenario",{ try { result=DcfCalculator.calculate(fcf.toDouble(),growth.toDouble()/100,discount.toDouble()/100,terminal.toDouble()/100,debt.toDouble(),shares.toDouble());error="" } catch(e:Exception){result=null;error=e.message ?: "Check the inputs."} })
            if(error.isNotBlank()) {Spacer(Modifier.height(8.dp));Text(error,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)}
        }
        result?.let { r-> Spacer(Modifier.height(14.dp));Panel(Modifier.fillMaxWidth()) {
            Kicker("YOUR SCENARIO");Spacer(Modifier.height(8.dp));Text("${money(r.perShare)} per share",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(8.dp))
            Muted("Five-year forecast PV ${money(r.forecastPresentValue)}");Muted("Terminal value PV ${money(r.terminalPresentValue)}");Muted("Implied equity value ${money(r.equityValue)}")
            Spacer(Modifier.height(8.dp));Muted("Formula: discounted five-year cash flows + discounted perpetuity terminal value − net debt, divided by diluted shares. This is a scenario, not a price target or recommendation.")
        } }
    }
}
