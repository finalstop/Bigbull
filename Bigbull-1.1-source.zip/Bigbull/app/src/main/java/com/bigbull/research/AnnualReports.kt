package com.bigbull.research
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File
import java.net.URI
import java.net.URL
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.time.Instant
import kotlinx.coroutines.*
import org.json.JSONObject
import org.jsoup.Jsoup

data class AnnualDocument(val stock:Instrument,val label:String,val url:String,val source:String,val published:String="",val size:String="")
object AnnualReports {
    fun nseUrl(s:Instrument)="https://www.nseindia.com/api/annual-reports?index=equities&symbol="+URLEncoder.encode(s.symbol,"UTF-8")
    fun parseNse(body:String,s:Instrument):List<AnnualDocument>{val a=JSONObject(body).getJSONArray("data");return (0 until a.length()).mapNotNull{i->val j=a.getJSONObject(i);val url=j.optString("fileName");val from=j.optString("fromYr");val to=j.optString("toYr");if(!ReaderPolicy.safe(url)||!from.matches(Regex("[0-9]{4}"))||!to.matches(Regex("[0-9]{4}")))null else AnnualDocument(s,"Annual report $from–$to",url,"NSE filing",j.optString("broadcast_dttm").takeUnless{it=="-"}.orEmpty(),j.optString("attFileSize").takeUnless{it=="null"}.orEmpty())}.distinctBy{it.url}.sortedByDescending{it.label}}
    fun parseIndex(html:String,url:String,s:Instrument):List<AnnualDocument>{
        val doc=Jsoup.parse(html,url);val section=doc.selectFirst("#documents")?:return emptyList()
        val heading=section.select("h3").firstOrNull{it.text().contains("Annual reports",true)}?:return emptyList();val group=heading.parent()?:return emptyList()
        return group.select("a[href]").mapNotNull{a->val link=a.absUrl("href");val year=Regex("20[0-9]{2}").find(a.text())?.value;val host=runCatching{URI(link).host.orEmpty()}.getOrDefault("")
            if(year==null||!ReaderPolicy.safe(link)||!(host=="bseindia.com"||host.endsWith(".bseindia.com")||host=="nseindia.com"||host.endsWith(".nseindia.com")))null else AnnualDocument(s,"Annual report · ${a.text()}",link,"Exchange filing · indexed by Screener")
        }.distinctBy{it.url}
    }
    fun load(s:Instrument):List<AnnualDocument>{
        if(s.exchange=="NSE"){val rows=parseNse(ReaderSource.bytes(nseUrl(s)).toString(Charsets.UTF_8),s);if(rows.isNotEmpty())return rows}
        val code=if(s.exchange=="BSE"){if(s.symbol.matches(Regex("[0-9]{6}")))s.symbol else{BseCatalog.load(false);BseCatalog.code(s)?:s.symbol}}else s.symbol
        val url="https://www.screener.in/company/"+URLEncoder.encode(code,"UTF-8")+"/"
        val rows=parseIndex(ReaderSource.bytes(url).toString(Charsets.UTF_8),url,s)
        require(rows.isNotEmpty()){"No accessible annual-report links were supplied for this company."};return rows
    }
    /** Bounded temporary download. No provider PDFs are retained after closing the reader. */
    fun download(doc:AnnualDocument,cacheDir:File):File{
        val file=File.createTempFile("bigbull-report-",".pdf",cacheDir);var current=doc.url
        try{
            for(attempt in 0..5){require(ReaderPolicy.safe(current)){"Unsupported report URL"};val c=(URL(current).openConnection() as HttpURLConnection).apply{instanceFollowRedirects=false;connectTimeout=12000;readTimeout=20000;setRequestProperty("User-Agent","Mozilla/5.0 Bigbull/1.0")}
                try{val code=c.responseCode;if(code in 300..399){current=URL(URL(current),c.getHeaderField("Location")?:error("Missing report redirect")).toString();continue};require(code in 200..299){"Report source returned HTTP $code"}
                    c.inputStream.buffered().use{input->file.outputStream().use{out->val b=ByteArray(16384);var total=0L;while(true){val n=input.read(b);if(n<0)break;total+=n;require(total<=64_000_000){"Report exceeds 64 MB. Open the original source."};out.write(b,0,n)}}}
                    val prefix=file.inputStream().use{ByteArray(5).also{b->it.read(b)}.toString(Charsets.US_ASCII)}
                    require(prefix=="%PDF-"){"This attachment is not a PDF. Open the original source for ZIP or other formats."};return file
                }finally{c.disconnect()}
            };error("Too many report redirects")
        }catch(e:Exception){file.delete();throw e}
    }
}
@Composable fun AnnualReportsPage(app:AppState,stock:Instrument){
    var docs by remember(stock.id){mutableStateOf<List<AnnualDocument>>(emptyList())};var loading by remember{mutableStateOf(true)};var error by remember{mutableStateOf<String?>(null)};var retry by remember{mutableIntStateOf(0)};var fetched by remember{mutableStateOf("")}
    LaunchedEffect(stock.id,retry){loading=true;error=null;try{docs=withContext(Dispatchers.IO){AnnualReports.load(stock)};fetched=Instant.now().toString()}catch(e:CancellationException){throw e}catch(e:Exception){error=e.message?:"Reports unavailable"}finally{loading=false}}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{SectionTitle("Annual reports"){TextButton(onClick={retry++},enabled=!loading){Text("Refresh")}};Muted("Original company filings. Tap a report to read its PDF inside Bigbull.");if(fetched.isNotBlank())Muted("Retrieved ${CheckpointFacts.stamp(fetched)}")}
        if(loading)item{LinearProgressIndicator(Modifier.fillMaxWidth());Muted("Finding original filings…")}
        error?.let{item{EmptyPanel("Reports unavailable",it);SourceLink("Exchange annual-report page",if(stock.exchange=="NSE")"https://www.nseindia.com/companies-listing/corporate-filings-annual-reports"else"https://www.bseindia.com/corporates/ann.html")}}
        items(docs,key={it.url}){d->Panel(Modifier.fillMaxWidth().clickable{app.annualDocument=d}){Text(d.label,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(6.dp));Muted(d.source);if(d.published.isNotBlank())Muted(d.published);if(d.size.isNotBlank())Muted(d.size);Spacer(Modifier.height(8.dp));Text("Read PDF →",color=MaterialTheme.colorScheme.primary)}}
    }
}
private data class PdfPageImage(val image:Bitmap,val count:Int)
@Composable fun AnnualPdfReader(app:AppState,doc:AnnualDocument){
    val context=LocalContext.current;var file by remember(doc.url){mutableStateOf<File?>(null)};var error by remember{mutableStateOf<String?>(null)};var page by remember{mutableIntStateOf(0)};var count by remember{mutableIntStateOf(0)};var zoom by remember{mutableFloatStateOf(1f)};var retry by remember{mutableIntStateOf(0)};var jump by remember{mutableStateOf("")}
    BackHandler{app.annualDocument=null}
    LaunchedEffect(doc.url,retry){error=null;file=null;var downloaded:File?=null;try{downloaded=withContext(Dispatchers.IO){AnnualReports.download(doc,context.cacheDir)};ensureActive();file=downloaded;awaitCancellation()}catch(e:CancellationException){throw e}catch(e:Exception){error=e.message?:"Could not load report"}finally{downloaded?.delete()}}
    var rendered by remember{mutableStateOf<PdfPageImage?>(null)}
    LaunchedEffect(file,page){rendered=null;val f=file?:return@LaunchedEffect;try{rendered=withContext(Dispatchers.IO){ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY).use{fd->PdfRenderer(fd).use{pdf->val pages=pdf.pageCount;pdf.openPage(page.coerceIn(0,pages-1)).use{p->val w=1400;val h=(w.toDouble()*p.height/p.width).toInt().coerceIn(1,6000);val b=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);b.eraseColor(android.graphics.Color.WHITE);p.render(b,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);PdfPageImage(b,pages)}}}};count=rendered!!.count}catch(e:CancellationException){throw e}catch(e:Exception){error=e.message?:"PDF rendering failed"}}
    Surface{Column(Modifier.fillMaxSize()){
        Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){TextButton(onClick={app.annualDocument=null}){Text("‹ Reports")};Text(doc.stock.symbol,Modifier.weight(1f),fontWeight=FontWeight.SemiBold);SourceLink("Original",doc.url)}
        Text(doc.label,Modifier.padding(horizontal=20.dp),style=MaterialTheme.typography.titleMedium)
        if(error!=null)Column(Modifier.padding(20.dp)){Text(error!!,color=MaterialTheme.colorScheme.error);Button(onClick={retry++}){Text("Retry report")}}
        else if(rendered==null)Column(Modifier.padding(20.dp)){LinearProgressIndicator(Modifier.fillMaxWidth());Muted(if(file==null)"Downloading original PDF…"else"Rendering page…")}
        else{
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically){TextButton(onClick={page--;zoom=1f},enabled=page>0){Text("Previous")};Text("${page+1} / $count",fontSize=12.sp);TextButton(onClick={page++;zoom=1f},enabled=page<count-1){Text("Next")};TextButton(onClick={zoom=if(zoom>=2f)1f else zoom+.5f}){Text("${num(zoom.toDouble(),1)}×")}}
            Row(Modifier.fillMaxWidth().padding(horizontal=20.dp),verticalAlignment=Alignment.CenterVertically){OutlinedTextField(jump,{jump=it.filter{c->c.isDigit()}.take(5)},Modifier.weight(1f),singleLine=true,placeholder={Text("Page number")},keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=androidx.compose.ui.text.input.KeyboardType.Number));TextButton(onClick={jump.toIntOrNull()?.takeIf{it in 1..count}?.let{page=it-1;zoom=1f;jump=""}},enabled=jump.toIntOrNull()?.let{it in 1..count}==true){Text("Go")}}
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()){val width=maxWidth*zoom;Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState())){Image(rendered!!.image.asImageBitmap(),"Annual report page ${page+1}",Modifier.width(width).aspectRatio(rendered!!.image.width.toFloat()/rendered!!.image.height),contentScale=ContentScale.Fit)}}
        }
    }}
}
