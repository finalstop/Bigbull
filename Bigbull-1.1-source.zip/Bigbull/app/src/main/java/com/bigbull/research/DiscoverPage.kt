package com.bigbull.research

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

@Composable fun MarketPage(app:AppState,openWatch:()->Unit,openSettings:()->Unit) {
    var query by remember{mutableStateOf("")};var movers by remember{mutableIntStateOf(0)}
    val market=app.snapshot
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).glassClearance().padding(20.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Image(painterResource(R.drawable.ic_bigbull),"Bigbull",Modifier.size(40.dp))
            Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text("bigbull",fontWeight=FontWeight.Bold,fontSize=25.sp,letterSpacing=(-.9).sp);Muted("A little clarity. A better question.")}
            Surface(shape=RoundedCornerShape(8.dp),color=MaterialTheme.colorScheme.surfaceVariant){Text("FREE",Modifier.padding(9.dp),style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.primary)}
        }
        Spacer(Modifier.height(26.dp));Text("Make sense of the market.",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,letterSpacing=(-.7).sp)
        Spacer(Modifier.height(14.dp));OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),placeholder={Text("Search stocks, e.g. Infosys")},singleLine=true,shape=RoundedCornerShape(14.dp),trailingIcon={TextButton(onClick={app.search(query)},enabled=query.trim().length>=2&&!app.isLoading){Text("Find →")}})
        if(app.searchResults.isNotEmpty()) {
            Spacer(Modifier.height(10.dp));Panel {
                app.searchResults.take(6).forEach{s->Row(Modifier.fillMaxWidth().clickable{app.searchResults=emptyList();app.openStock(s)}.padding(vertical=9.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(s.symbol,fontWeight=FontWeight.SemiBold);Muted("${s.exchange} · ${s.name}")};Text("→",color=MaterialTheme.colorScheme.primary)}}
                TextButton(onClick={app.searchResults=emptyList()}){Text("Dismiss results")}
            }
        }
        Spacer(Modifier.height(26.dp));SectionTitle("Market pulse") {TextButton(onClick={app.loadMarket()},enabled=!app.isLoading){Text(if(market==null)"Load free data" else "Refresh")}}
        if(market==null) EmptyPanel("The whole picture, after the close","Load NSE’s public daily file to see advances, declines and market movers. No sign-up or API key.")
        else Panel(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Kicker("NSE · END OF DAY");Muted(market.date.toString())}
            Spacer(Modifier.height(13.dp));Text(when{market.advances>market.declines->"More stocks finished higher";market.advances<market.declines->"More stocks finished lower";else->"An evenly split session"},fontWeight=FontWeight.SemiBold,fontSize=20.sp)
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){PulseNumber("Advanced",market.advances,Positive);PulseNumber("Declined",market.declines,Negative);PulseNumber("Unchanged",market.unchanged,MaterialTheme.colorScheme.onSurfaceVariant)}
            Spacer(Modifier.height(13.dp));Row(Modifier.fillMaxWidth().height(7.dp)){if(market.advances>0)Box(Modifier.weight(market.advances.toFloat()).fillMaxHeight().background(Positive));if(market.declines>0)Box(Modifier.weight(market.declines.toFloat()).fillMaxHeight().background(Negative));if(market.unchanged>0)Box(Modifier.weight(market.unchanged.toFloat()).fillMaxHeight().background(MaterialTheme.colorScheme.outline))}
            Spacer(Modifier.height(12.dp));Muted("${market.entries.size} NSE EQ-series securities with a valid previous close. This is breadth, not an index return.")
            SourceLink("View original NSE file",market.sourceUrl)
        }
        app.marketError?.let{Spacer(Modifier.height(8.dp));Text(it,color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)}
        if(market!=null) {
            Spacer(Modifier.height(24.dp));SectionTitle("Session movers");Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Gainers","Losers","Volume").forEachIndexed{i,t->SmallChip(t,movers==i){movers=i}}}
            Spacer(Modifier.height(10.dp));Panel(Modifier.fillMaxWidth()){
                val entries=when(movers){0->market.entries.filter{it.change>0}.sortedByDescending{it.change};1->market.entries.filter{it.change<0}.sortedBy{it.change};else->market.entries.sortedByDescending{it.volume}}
                entries.take(5).forEachIndexed{i,e->
                    Row(Modifier.fillMaxWidth().clickable{app.openStock(e.stock)}.padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically){Text((i+1).toString().padStart(2,'0'),color=MaterialTheme.colorScheme.onSurfaceVariant,style=MaterialTheme.typography.labelSmall);Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(e.symbol,fontWeight=FontWeight.SemiBold);Muted(if(movers==2)"${num(e.volume,0)} shares traded" else "NSE · ${market.date}")};Column(horizontalAlignment=Alignment.End){Text(money(e.close),fontWeight=FontWeight.Medium);Text(relative(e.change),color=if(e.change>=0)Positive else Negative,style=MaterialTheme.typography.labelMedium)}}
                    if(i<4)HorizontalDivider(color=MaterialTheme.colorScheme.outline.copy(alpha=.12f))
                }
                if(entries.isEmpty())Muted("No securities in this category for this session.")
            }
        }
        Spacer(Modifier.height(24.dp));SectionTitle("Start a closer look");Spacer(Modifier.height(7.dp));Muted("A starting set to explore, not recommendations.")
        Spacer(Modifier.height(10.dp));Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(10.dp)){
            listOf(Instrument("RELIANCE","NSE","Reliance Industries"),Instrument("INFY","NSE","Infosys"),Instrument("TCS","NSE","Tata Consultancy Services"),Instrument("HDFCBANK","NSE","HDFC Bank")).forEach{s->
                Panel(Modifier.width(178.dp).clickable{app.openStock(s)}){Text(s.symbol,fontWeight=FontWeight.Bold);Spacer(Modifier.height(5.dp));Muted(s.name);Spacer(Modifier.height(16.dp));Text("Explore stock →",style=MaterialTheme.typography.labelMedium,color=MaterialTheme.colorScheme.primary)}
            }
        }
        Spacer(Modifier.height(24.dp));SectionTitle("Your watchlist"){TextButton(onClick=openWatch){Text("Manage →")}}
        if(app.stocks.isEmpty())EmptyPanel("Keep your research together","Add stocks to a watchlist from any company page. Prices and signals use the data you load.")
        else Panel{app.stocks.take(5).forEach{s->StockRow(app,s){app.openStock(s)}}}
        Spacer(Modifier.height(24.dp));Panel(Modifier.fillMaxWidth()) {Kicker("THE BIGBULL DIFFERENCE");Spacer(Modifier.height(8.dp));Text("Every signal has a reason.",fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(5.dp));Muted("Open a stock’s Brief to understand trend, momentum and trading activity in everyday language. Tap a card to see the calculation and its limits.");TextButton(onClick=openSettings,contentPadding=PaddingValues(0.dp)){Text("How our free data works →")}}
        Spacer(Modifier.height(14.dp));Muted("Historical research · no live feed. Public website access may be unavailable. No prices are invented.")
    }
}
@Composable private fun PulseNumber(label:String,value:Int,color:androidx.compose.ui.graphics.Color){Column{Text(num(value.toDouble(),0),fontWeight=FontWeight.Bold,fontSize=22.sp,color=color);Muted(label)}}
@Composable fun SourceLink(label:String,url:String) {
    val context=LocalContext.current
    TextButton(onClick={try{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(_:Exception){android.widget.Toast.makeText(context,"No browser is available.",android.widget.Toast.LENGTH_SHORT).show()}},contentPadding=PaddingValues(0.dp)){Text("$label ↗")}
}

@Composable fun SettingsPage(app:AppState) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).glassClearance().padding(20.dp)){
        PageHeader("Settings","Simple, transparent and free to use")
        Panel(Modifier.fillMaxWidth()){
            Kicker("NO SUBSCRIPTION NEEDED");Spacer(Modifier.height(8.dp));Text("Public website data",fontWeight=FontWeight.Bold,fontSize=21.sp);Spacer(Modifier.height(9.dp))
            Muted("Market pulse: NSE’s published end-of-day CSV. Charts and symbol search: Yahoo Finance’s public endpoints. All requests go directly from your device. No Bigbull server or paid API key is required.")
            Spacer(Modifier.height(8.dp));Muted("These are best-effort sources, not a licensed commercial feed. Availability and permitted use depend on each website’s terms. Bigbull does not bypass logins or access restrictions. If a request fails, import an authorized CSV or open the original website.")
            Muted("Constituents: NSE / Nifty Indices and Upstox public instrument files. BSE-only membership is matched by ISIN. News: Economic Times, Mint, India Today and NDTV.com / NDTV Profit. Logos: Groww image CDN; trademarks belong to their respective owners. Annual reports link original exchange filings.")
            SourceLink("NSE daily reports","https://www.nseindia.com/all-reports");SourceLink("NSE data usage policy","https://www.nseindia.com/static/market-data/nse-data-policy");SourceLink("Yahoo terms","https://legal.yahoo.com/us/en/yahoo/terms/otos/index.html")
        }
        Spacer(Modifier.height(14.dp));Panel(Modifier.fillMaxWidth()){
            Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Keep data for offline use",fontWeight=FontWeight.SemiBold);Muted("Enable where your source’s terms allow local retention.")};Switch(app.cache,{app.changeCache(it)})}
            Muted("Off by default. Disabling clears downloaded data. Your imported CSV files, watchlists and ledger remain on this device.")
        }
        Spacer(Modifier.height(14.dp));Panel(Modifier.fillMaxWidth()){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Dark mode",fontWeight=FontWeight.SemiBold);Muted("A quieter workspace after hours.")};Switch(app.dark,{app.changeDark(it)})}}
        Spacer(Modifier.height(14.dp));Panel(Modifier.fillMaxWidth()){
            BrandMark(); Spacer(Modifier.height(8.dp)); Text("Created by Harsh Prashant Gattani",fontWeight=FontWeight.SemiBold); Spacer(Modifier.height(6.dp)); Kicker("BIGBULL 1.1");Spacer(Modifier.height(8.dp));Muted("Working research build. Daily charts exclude today’s incomplete bar; weekly and monthly charts exclude the current period. Same-day quotes may be delayed. No exchange holiday calendar or automatic corporate-action adjustment.")
            Spacer(Modifier.height(8.dp));Muted("Annual and quarterly financial statements use Yahoo’s public timeseries where available; coverage can be incomplete. Original research and filings are linked. In-app article reading, same-day quotes and published MMI with six factor groups are included without ads or subscriptions. Options, alerts, AI and broker trading are not implemented.")
        }
    }
}
