package com.bigbull.research
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

@Composable fun InvestorScreenPage(app:AppState){
    val scan=app.scanner;var selected by remember{mutableIntStateOf(scan.method)};var universeId by remember{mutableStateOf(scan.universe?.spec?.id?:"500")}
    var details by remember(selected){mutableStateOf(false)};var menu by remember{mutableStateOf(false)};var passing by remember{mutableStateOf(true)};var sepa by remember{mutableStateOf(scan.includesSepa)};var browse by remember{mutableStateOf(false)};var query by remember{mutableStateOf("")}
    val method=InvestorScreens.methods[selected];val spec=ScreenUniverses.options.first{it.id==universeId};val same=scan.method==selected&&scan.universe?.spec?.id==universeId&&(selected!=0||scan.includesSepa==sepa)
    val rows=if(same&&!browse)scan.result.filter{(!passing||it.qualifies)&&(it.stock.symbol.contains(query,true)||it.stock.name.contains(query,true))}else emptyList()
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(start=20.dp,end=20.dp,top=16.dp,bottom=LocalGlassInset.current+20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{
            SectionTitle("Investor playbooks");Muted("A defined universe. Every rule explained.")
            Spacer(Modifier.height(14.dp));Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)){InvestorScreens.methods.forEachIndexed{i,m->SmallChip(m.name.substringAfterLast(" "),selected==i){if(!scan.running){selected=i;browse=false}}}}
            Spacer(Modifier.height(18.dp));Text(method.name,style=MaterialTheme.typography.headlineMedium);Text(method.subtitle,color=MaterialTheme.colorScheme.primary,style=MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp));Muted(if(selected==0)"All eight rules must pass. One failure or missing input excludes the stock. Completed daily sessions only."else"A disclosed quantitative interpretation of the investor's approach.")
            TextButton(onClick={details=!details},contentPadding=PaddingValues(0.dp)){Text(if(details)"Hide formula & criteria"else"Formula & criteria +")}
            if(details){Muted(method.note);SourceLink("Method reference",method.url);if(selected==0)Muted("RS = 100 × (lower returns + half of tied returns) / eligible NIFTY 500 stocks. One-year price returns, not dividend total return. Partial coverage can change the percentile. Optional SEPA checks EPS ≥25%, revenue ≥20%, margin expansion and ROE ≥17%; not earnings surprises, sponsorship or VCP.")}
            Box{OutlinedButton(onClick={menu=true},enabled=!scan.running,modifier=Modifier.fillMaxWidth()){Text(spec.title,Modifier.weight(1f));Text("⌄")};DropdownMenu(menu,{menu=false}){ScreenUniverses.options.forEach{u->DropdownMenuItem(text={Text(u.title)},onClick={universeId=u.id;menu=false;browse=false})}}}
            if(selected==0)Row(verticalAlignment=Alignment.CenterVertically){Switch(sepa,{sepa=it},enabled=!scan.running);Spacer(Modifier.width(8.dp));Text("Add SEPA financial filters",fontSize=13.sp)}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){PrimaryButton(if(scan.running)"Loading…"else"Run screen",{browse=false;scan.run(spec,selected,sepa)},enabled=!scan.running,modifier=Modifier.weight(1f));if(scan.running)OutlinedButton(onClick={scan.cancel()}){Text("Stop")}}
            TextButton(onClick={browse=true;scan.browse(spec)},enabled=!scan.running,contentPadding=PaddingValues(0.dp)){Text("Browse companies in this universe →")}
            Muted(if(scan.running||same)scan.progress else"Large scans take several minutes. Keep the app open. Downloads are reused on retry.")
            if(scan.running)LinearProgressIndicator(progress={scan.done.toFloat()/scan.total.coerceAtLeast(1)},modifier=Modifier.fillMaxWidth())
            if(scan.universe?.spec?.id==universeId)scan.universe?.let{Muted("${it.stocks.size} constituents · retrieved ${CheckpointFacts.stamp(it.fetched)}");if(it.url.isNotBlank())SourceLink("Universe source",it.url)}
            if(same)scan.rank?.let{Muted("RS: ${it.eligible}/${it.requested} eligible · ${it.failures} fetch failures · ${it.excluded} short/out-of-session histories. Session ${it.session}. Coverage excludes unavailable history.")}
            scan.error?.let{Text(it,color=MaterialTheme.colorScheme.error,fontSize=12.sp)}
            OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Find company in results")})
            if(!browse)Row(verticalAlignment=Alignment.CenterVertically){Switch(passing,{passing=it});Spacer(Modifier.width(8.dp));Text("Matches only")}
            if(same&&!browse&&scan.result.isNotEmpty())Muted("${scan.result.count{it.qualifies}} matches · ${scan.result.size} evaluated · ${scan.failures.size} refresh issues")
        }
        if(browse&&scan.universe?.spec?.id==universeId){items(scan.universe!!.stocks.filter{it.symbol.contains(query,true)||it.name.contains(query,true)},key={it.id}){s->Row(Modifier.fillMaxWidth().clickable{app.openStock(s)}.padding(vertical=10.dp),verticalAlignment=Alignment.CenterVertically){CompanyLogo(s);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(s.symbol,fontWeight=FontWeight.Medium);Muted(s.name);Muted(s.exchange)};Text("›")}}}
        else{
            if(rows.isEmpty())item{EmptyPanel(if(scan.running)"Evaluating the universe…"else"No verified matches",if(scan.running)"Results appear after the complete run."else"Run a screen or turn off Matches only to inspect failed and missing criteria.")}
            items(rows,key={it.stock.id}){x->var expanded by remember(x.stock.id,selected){mutableStateOf(false)};Panel(Modifier.fillMaxWidth()){
                Row(Modifier.fillMaxWidth().clickable{expanded=!expanded},verticalAlignment=Alignment.CenterVertically){CompanyLogo(x.stock);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(x.stock.symbol,fontWeight=FontWeight.SemiBold);Muted(x.stock.name);Muted(if(x.qualifies)"All required rules pass"else"${x.rules.count{it.passed==true}} / ${x.rules.size} core rules pass")};Text(if(expanded)"−"else"+")}
                if(expanded){Muted("${x.date} · ${x.price?.let{money(it)}?:"Unavailable"}");(x.rules+x.extra).forEach{r->Spacer(Modifier.height(12.dp));Row{Text(r.title,Modifier.weight(1f),fontSize=13.sp);Text(when(r.passed){true->"Pass";false->"Fail";null->"Missing"},fontSize=12.sp,color=when(r.passed){true->Positive;false->Negative;null->MaterialTheme.colorScheme.onSurfaceVariant})};Muted(r.formula);Muted(r.reading)};scan.failures[x.stock.id]?.let{Muted(it)};TextButton(onClick={app.openStock(x.stock)}){Text("Open company research →")}}
            }}
        }
        item{Muted("BSE-only means an equity's ISIN is absent from the NSE cash-market directory in Upstox's public instrument files. This covers its supported securities, not every exchange listing. Some BSE stocks have little or no free price/financial history. Missing data never passes a rule. No investor endorsement or recommendation is implied.")}
    }
}
