Bigbull mark: original, simple geometric bull outline and rising arrow. `bigbull-mark.svg` is the editable vector source; `app/src/main/res/drawable/ic_bigbull.xml` is the Android vector equivalent.


0.9 identity: BB is a typographic monogram using a static weight-700 instance of Cormorant Garamond Italic. Font and licence are bundled in app resources/assets. BB-monogram.svg and ic_bigbull.xml contain matching glyph outlines; this is code-native vector artwork. Creator credit: Harsh Prashant Gattani.
